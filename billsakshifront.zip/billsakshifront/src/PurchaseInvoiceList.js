import React, { useState } from "react";

import { IoMdEye } from "react-icons/io";
import { FaWindowClose } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import DataTable from "./components/DataTable";
import Popup from "./components/Popup";

const PurchaseInvoiceList = () => {
  const [warn, setWarn] = useState(false);
  const navigate = useNavigate();
  const columns = [
    { field: "id", headerName: "Sl No.", width: 80 },
    { field: "invoiceNumber", headerName: "Invoice Number", flex: 1 },
    { field: "issueDate", headerName: "Issue Date", flex: 1 },
    { field: "finalAmount", headerName: "Final Amount ₹", flex: 1 },
    { field: "paidAmount", headerName: "Paid Amount ₹", flex: 1 },
    { field: "dueAmount", headerName: "Due Amount ₹", flex: 1 },
    { field: "paymentOption", headerName: "Payment Option", flex: 1 },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
      minWidth: 150,
      renderCell: (params) => (
        <button
          className={`${
            params.value ? "bg-red-500" : "bg-[#3b82f6]"
          } text-white leading-normal w-[100px] py-2 rounded-md`}
          onClick={() => alert(params.value)}
        >
          {params.value ? "Deactivate" : "Activate"}
        </button>
      ),
    },
    {
      field: "action",
      headerName: "Action",
      renderCell: (params) => (
        <div className="flex gap-2 h-full items-center text-[rgba(0,0,0,0.7)]">
          <IoMdEye
            size={35}
            className="cursor-pointer"
            onClick={() => handlepurchaseInvEdit(params)}
          />
          <FaWindowClose
            className="cursor-pointer"
            size={35}
            onClick={() => setWarn(true)}
          />
        </div>
      ),
    },
  ];
  const handlepurchaseInvEdit = (invoice) => {
    console.log("invoice", invoice);
  };

  const handleWarn = (e) => {
    e.preventDefault();
    console.log("Submission");
    setWarn(false);
  };

  return (
    <div className="w-full">
              <Popup
        isOpen={warn}
        setIsOpen={setWarn}
        handleSubmit={handleWarn}
        heading="Are you sure ?"
        submitText="OK"
      ></Popup>
      <DataTable
        columns={columns}
        endpoint={"/invoices"}
        type={"purchase Invoice"}
        redirect="/purchase-invoice/add"
      />
    </div>
  );
};


export default PurchaseInvoiceList