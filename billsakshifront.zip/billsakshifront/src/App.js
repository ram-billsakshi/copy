//App.js
import React from 'react'
import { RouterProvider, createBrowserRouter } from 'react-router-dom'
import privateRoute from './routes/privateRoute'
import publicRoute from './routes/publicRoute'
import useCheckAuth from './hooks/useCheckAuth'



const App = () => {
    const isAUthenticated = useCheckAuth()
    const router = createBrowserRouter([
        isAUthenticated?privateRoute(isAUthenticated):{},
        ...publicRoute(isAUthenticated)
        ])

    return <div className='bg-[#f4f6f9]'><RouterProvider router={router}/></div>
}

export default App






