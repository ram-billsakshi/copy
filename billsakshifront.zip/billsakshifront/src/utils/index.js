import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

const exportArrayToExcel = (data, fileName) => {
  // Create a worksheet from the data
  const worksheet = XLSX.utils.json_to_sheet(data);

  // Create a new workbook and append the worksheet
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

  // Write the workbook to a binary string
  const excelBuffer = XLSX.write(workbook, {
    bookType: 'xlsx',
    type: 'array',
  });

  // Create a Blob from the binary string
  const blob = new Blob([excelBuffer], {
    type: 'application/octet-stream',
  });

  // Save the Blob as a file
  saveAs(blob, `${fileName}.xlsx`);
};

const exportArrayToCSV = (data, fileName) => {
  // Convert the array of objects to a CSV string
  const csvRows = [];

  // Extract the headers
  const headers = Object.keys(data[0]);
  csvRows.push(headers.join(','));

  // Extract the rows
  for (const row of data) {
    const values = headers.map(header => JSON.stringify(row[header], (key, value) => value || ""));
    csvRows.push(values.join(','));
  }

  // Create a CSV string
  const csvString = csvRows.join('\n');

  // Create a Blob from the CSV string
  const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });

  // Save the Blob as a file
  saveAs(blob, `${fileName}.csv`);
};

const copyArrayToText = (data) => {
    // Convert the array of objects to a plain text string (CSV format)
    const textRows = [];
  
    // Extract the headers
    const headers = Object.keys(data[0]);
    textRows.push(headers.join('\t'));
  
    // Extract the rows
    for (const row of data) {
      const values = headers.map(header => row[header] || "");
      textRows.push(values.join('\t'));
    }
  
    // Create a plain text string
    const textString = textRows.join('\n');
  
    // Copy the plain text string to the clipboard
    navigator.clipboard.writeText(textString).then(() => {
      alert('Data copied to clipboard');
    }).catch(err => {
      console.error('Failed to copy text: ', err);
    });
  };


const exportArrayToPDF = (data, fileName) => {
  // Create a new jsPDF instance
  const doc = new jsPDF();

  // Extract headers from the data
  const headers = Object.keys(data[0]);

  // Extract rows from the data
  const rows = data.map(row => headers.map(header => row[header]));

  // Add autoTable to the jsPDF document
  doc.autoTable({
    head: [headers],
    body: rows,
  });

  // Save the PDF
  doc.save(`${fileName}.pdf`);
};

const printTable = (data) => {
    // Create a new window or iframe for printing
    const printWindow = window.open('', '', 'height=600,width=800');
  
    // Create a table in the new window
    let tableHtml = '<table border="1" style="border-collapse: collapse; width: 100%;">';
  
    // Extract headers
    const headers = Object.keys(data[0]);
    tableHtml += '<thead><tr>';
    headers.forEach(header => {
      tableHtml += `<th style="padding: 8px; text-align: left;">${header}</th>`;
    });
    tableHtml += '</tr></thead>';
  
    // Extract rows
    tableHtml += '<tbody>';
    data.forEach(row => {
      tableHtml += '<tr>';
      headers.forEach(header => {
        tableHtml += `<td style="padding: 8px;">${row[header]}</td>`;
      });
      tableHtml += '</tr>';
    });
    tableHtml += '</tbody></table>';
  
    // Write the HTML to the print window
    printWindow.document.write('<html><head><title>Print Table</title>');
    printWindow.document.write('</head><body>');
    printWindow.document.write(tableHtml);
    printWindow.document.write('</body></html>');
  
    // Print the window content
    printWindow.document.close();
    printWindow.print();
  };

  const handleChange = (e, setData) => {
    const { name, value, type, checked } = e.target;
    console.log('in handle change')
    console.log(e.target.value)
    setData(prevData => ({
        ...prevData,
        [name]: type === 'checkbox' ? checked : value
    }));
  };

function stateData(rows) {
    return rows.reduce((acc, row) => {
        acc[row.name] = '';
        return acc;
    }, {});
}

const formatDateToDisplay = (date) => {
  const [year, month, day] = date.split('-');
  return `${day}-${month}-${year}`;
};

const formatDateToISO = (date) => {
  const [day, month, year] = date.split('-');
  return `${year}-${month}-${day}`;
};


  


export {exportArrayToExcel,exportArrayToCSV,copyArrayToText,exportArrayToPDF,printTable,handleChange,stateData,formatDateToDisplay,formatDateToISO}