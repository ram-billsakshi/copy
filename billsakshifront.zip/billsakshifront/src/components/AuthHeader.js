import React, { useEffect, useState } from "react";
import { IoIosMenu } from "react-icons/io";
import userPlaceholder from "../../src/images/billsakshi/user-placeholder.svg";
import {Link} from "react-router-dom"
import { IoPersonSharp } from "react-icons/io5";
import { RiLockPasswordFill } from "react-icons/ri";
import { IoLogOut } from "react-icons/io5";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../redux/authSlice";

const AuthHeader = ({ sidebarOpen, setSidebarOpen }) => {
  const [popover,setPopover] = useState(false)
  const dispatch = useDispatch()
  const {user} = useSelector(state => state.auth)

  useEffect(() => {
    const handleClick = (e) => {
      const id1Container = document.getElementById('popover');
      const id2Container = document.getElementById('profile');
      
      if (
        id1Container && id1Container.contains(e.target) ||
        id2Container && id2Container.contains(e.target)
      ) {
        return;
      }
      
      setPopover(false);
    };

    document.body.addEventListener('click', handleClick);

    return () => {
      document.body.removeEventListener('click', handleClick);
    };
  }, []);

  const handleLogout = () => {
    const baseUrl = process.env.REACT_APP_API_BASE_URL;
    fetch(`${baseUrl}/profile/${user.id}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json'
      }
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(data => {
      console.log("Success logout", data);
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      dispatch(logout());
    })
    .catch((error) => {
      console.error("Error during logout:", error);
    });
  }
  
  return (
    <>
      <div
        className="w-full sticky top-0 bg-white flex items-center justify-between z-10 px-3 min-h-[82px]"
        style={{
          boxShadow: "0 2px 3px -1px rgba(0, 0, 0, 0.3)",
        }}
      >
        <div>
          <IoIosMenu
            size={30}
            className="cursor-pointer"
            onClick={() => {
              setSidebarOpen(!sidebarOpen);
            }}
          />
        </div>
        <div id="profile" className="flex flex-col items-center justify-center cursor-pointer" onClick={()=>{setPopover(!popover)}}>
          <div className="border-2 border-[#3056D3] h-12 w-12 rounded-full flex items-center justify-center">
            <img src={user.image || userPlaceholder} className="w-12 rounded-full" alt="" />
          </div>
          <span className="text-sm text-[#3056D3] font-medium">
            {user?.name}
          </span>
        </div>
      </div>
      <div id="popover" className={`z-10 bg-white border border-[rgba(48,86,211,0.17)] py-4 fixed top-22 right-5 rounded-md transition-all duration-100 ${popover?'scale-1':'scale-0'}`}>
            <ul className="">
              <li className="border-b border-[rgba(0,0,0,0.1)] text-[#121416]"><Link to={'#'} className="flex gap-2 items-center px-7 pb-2 "><IoPersonSharp size={20}/> Profile</Link></li>
              <li className="border-b border-[rgba(0,0,0,0.1)] text-[#121416]"><Link to={'#'} className="flex gap-2 items-center px-7 py-2 "><RiLockPasswordFill size={20}/>Change Password</Link></li>
              <li className="border-b border-[rgba(0,0,0,0.1)] text-[#121416]"><Link to={'#'} onClick={handleLogout} className="flex gap-2 items-center px-7 py-2 "><IoLogOut size={25}/>Logout</Link></li>
            </ul>
      </div>
    </>
  );
};

export default AuthHeader;
