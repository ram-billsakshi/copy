import React, { ReactNode } from "react";
import { FaArrowRightLong } from "react-icons/fa6";
import { IoIosArrowRoundDown } from "react-icons/io";
import { IoIosArrowRoundUp } from "react-icons/io";
const bg = {
  background:
    "linear-gradient(90deg, rgba(9, 47, 241, 1) 26%, rgba(238, 7, 133, 1) 77%)",
};

const CardDataStats = ({
  title,
  total,
  rate,
  levelUp,
  totalIcon,
}) => {
  return (
    <div className="rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark p-2 cursor-pointer hover:bg-blue-100 text-[#1c2434]">
      <div className="flex flex-row-reverse">
        <FaArrowRightLong color="#80a4e8" />
      </div>
      <div className="flex items-end justify-between m-3">
        <div>
          <h4 className="text-[1rem] md:text-[1.3rem]  font-semibold  flex items-center">
            {totalIcon}
            {total}
          </h4>
          <span className="text-sm font-medium">{title}</span>
        </div>
        <span className={`flex items-center gap-1 text-sm font-medium ${levelUp?'text-green-500':'text-red-500'}`}>
          {rate}
          {levelUp ? <IoIosArrowRoundUp size={18} /> : <IoIosArrowRoundDown size={18} />}
        </span>
      </div>
      {/* <div style={bg} className='w-full min-h-[50px] flex gap-2 justify-center items-center text-white'>
        <span className='text-sm font-medium'>More info</span><FaCircleArrowRight size={20} />
      </div> */}
    </div>
  );
};

export default CardDataStats;
