import React from 'react'
import { FaFacebookF } from "react-icons/fa";
import { AiOutlineTwitter } from "react-icons/ai";
import { FaLinkedinIn } from "react-icons/fa";
import { FaYoutube } from "react-icons/fa";
import { FaInstagram } from "react-icons/fa";
import Circle from './Circle';
import startUpIndia from "../images/billsakshi/startup-india.png"
import vocal from "../images/billsakshi/vocal.png"

const Footer = () => {
  return (
    <div className='w-full bg-[#1034F1]'>
    <div className='w-full pt-10 max-w-[1500px] flex flex-wrap gap-3 sm:gap-5 lg:gap-10 text-white m-auto'>
      <div className='w-[90%] sm:w-[45%] lg:w-[22%] p-5 grow'>
        <h1 className='text-3xl font-bold mb-3'>BILLSAKSHI</h1>
        <p className='text-sm leading-6'>We at BILLSAKSHI build and develop solutions for the retailers, wholesale distributors and service providers besides guaranting business reports for everyone.</p>
      </div>
      <div className='w-[90%] sm:w-[45%] lg:w-[22%] p-5 grow'>
      <h2 className='text-lg font-bold mb-3'>Useful Links</h2>
      <ul className='list-disc ml-6'>
        <li className='font-semi-bold mt-3 text-'>Home</li>
        <li className='font-semi-bold mt-3 text-'>About us</li>
        <li className='font-semi-bold mt-3 text-'>Features</li>
        <li className='font-semi-bold mt-3 text-'>Terms & conditions</li>
        <li className='font-semi-bold mt-3 text-'>Privacy policy</li>
      </ul>
      </div>
      <div className='w-[90%] sm:w-[45%] lg:w-[22%] p-5 grow'>
        <h2 className='text-lg font-bold mb-3'>Contact Us</h2>
        <div>BILLSAKSHI</div>
        <br />
        <br />
        <br />
        <div className='font-bold text-sm'>Phone: +91 8000611500</div>
        <div className='font-bold text-sm my-3'>Email: +91 support@billsakshi.com</div>
        <div className='flex gap-3'>
          <Circle Icon={FaFacebookF}/> 
          <Circle Icon={AiOutlineTwitter}/>
          <Circle Icon={FaLinkedinIn}/>
          <Circle Icon={FaYoutube}/>
          <Circle Icon={FaInstagram}/>
          </div>
      </div>
      <div className='w-[90%] sm:w-[45%] lg:w-[22%] p-5 grow'>
        <br />
        <img src={startUpIndia} alt="" className='w-60' />
        <img src={vocal} alt="" className='w-40' />
      </div>
    </div>
    <div className='w-full bg-[#333333] flex flex-wrap p-4 lg:p-5 gap-2 lg:gap-5 text-white'>
        <div className='w-[90%] lg:w-[45%] grow  text-center text-sm'>© Copyright BILLSAKSHI. All Rights Reserved</div>
        <div className='w-[90%] lg:w-[45%] grow  text-center text-sm'>Designed & Developed by Billsakshi</div>
      </div>
    </div>
  )
}

export default Footer