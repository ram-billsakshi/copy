import React from "react";

const InputForm = ({ rows, onChange, data }) => {
  return (
    <div className="flex justify-center">
      <div className="w-full max-w-lg">
        {rows?.map((row, index) => {
          let inputField;
          const value = data[row.name] || "";
          if (row.type === "textArea") {
            inputField = (
              <textarea
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id={row.name}
                name={row.name}
                value={value}
                placeholder={row.placeholder}
                required={row.isRequired}
                maxLength={row.maxChar}
                readOnly={row.readOnly}
                onChange={onChange}
              />
            );
          } else if (row.type === "checkbox") {
            inputField = (
              <div className="flex">
                {row.fields.map((fieldName, index) => (
                  <div key={index}>
                    <input
                      type="checkbox"
                      id={fieldName}
                      name={fieldName}
                      value={fieldName}
                      className="mx-1"
                      required={row.isRequired}
                      readOnly={row.readOnly}
                      onChange={onChange}
                    />
                    <label htmlFor={fieldName} className="mx-1">
                      {fieldName}
                    </label>
                  </div>
                ))}
              </div>
            );
          } 
          else if (row.type === "radio") {
            inputField = (
              <div className="flex items-center">
                {row.fields.map((fieldName, index) => (
                  <div key={index} className="mr-2">
                    <input
                      type="radio"
                      id={fieldName.value}
                      className="mr-1"
                      required={row.isRequired}
                      maxLength={row.maxChar}
                      readOnly={row.readOnly}
                      onChange={onChange}
                      checked={value === fieldName.value}
                      value={fieldName.value}
                      name={row.name}
                    />
                    <label htmlFor={fieldName.value}>{fieldName.label}</label>
                  </div>
                ))}
              </div>
            );
          } 
           else if (row.type === "dropdown") {
            inputField = (
              <div className="flex items-center">
                <select
                  className="shadow border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  name={row.name}
                  value={value}
                  onChange={onChange}
                >
                  {row.fields.map((fieldName, index) => (
                    <option value={fieldName} key={index}>
                      {fieldName}
                    </option>
                  ))}
                </select>
              </div>
            );
          } else {
            inputField = (
              <input
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id={row.name}
                name={row.name}
                type={row.type}
                value={value}
                placeholder={row.placeholder}
                required={row.isRequired}
                maxLength={row.maxChar}
                readOnly={row.readOnly}
                onChange={onChange}
              />
            );
          }

          return (
            <div className="mb-4" key={index}>
              <label
                className="block text-gray-700 text-sm font-bold mb-2"
                htmlFor={row.label}
              >
                {row.label}
              </label>
              {inputField}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default InputForm;
