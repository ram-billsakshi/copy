import React from "react";

const InputFormTwoColumn = ({ rows, onChange, data }) => {
  return (
    <div className="w-full">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {rows.map((row, index) => {
          let inputField;
          const value = data[row?.name] || "";
          console.log('value for image', data[row.name])

          if (row.type === "textArea") {
            inputField = (
              <textarea
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id={row.name}
                placeholder={row.placeholder}
                required={row.isRequired}
                maxLength={row.maxChar}
                readOnly={row.readOnly}
                onChange={onChange}
                value={value}
                name={row.name}
              />
            );
          } else if (row.type === "dropdown") {
            inputField = (
              <div className="flex items-center">
                <select
                  className="shadow border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  id={row.name}
                  required={row.isRequired}
                  readOnly={row.readOnly}
                  onChange={onChange}
                  value={value}
                  name={row.name}
                >
                  {row.fields.map((fieldName, index) => (
                    <option value={fieldName} key={index}>
                      {fieldName}
                    </option>
                  ))}
                </select>
              </div>
            );
          } else if (row.type === "checkbox") {
            inputField = (
              <div className="flex items-center">
                {row.fields.map((fieldName, index) => (
                  <div key={index} className="mr-2">
                    <input
                      type="checkbox"
                      id={fieldName}
                      className="mr-1"
                      required={row.isRequired}
                      maxLength={row.maxChar}
                      readOnly={row.readOnly}
                      onChange={onChange}
                      checked={data[row.name]?.includes(fieldName) || false}
                      name={row.name}
                      value={fieldName}
                    />
                    <label htmlFor={fieldName}>{fieldName}</label>
                  </div>
                ))}
              </div>
            );
          }
           else if (row.type === "radio") {
            inputField = (
              <div className="flex items-center">
                {row.fields.map((fieldName, index) => (
                  <div key={index} className="mr-2">
                    <input
                      type="radio"
                      id={fieldName.value}
                      className="mr-1"
                      required={row.isRequired}
                      maxLength={row.maxChar}
                      readOnly={row.readOnly}
                      onChange={onChange}
                      checked={value === fieldName.value}
                      value={fieldName.value}
                      name={row.name}
                    />
                    <label htmlFor={fieldName.value}>{fieldName.label}</label>
                  </div>
                ))}
              </div>
            );
          } 
          else {
            inputField = (
              <input
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id={row.name}
                type={row.type}
                placeholder={row.placeholder}
                required={row.isRequired}
                maxLength={row.maxChar}
                readOnly={row.readOnly}
                onChange={onChange}
                value={value}
                name={row.name}
              />
            );
          }

          return (
            <div className="mb-4" key={index}>
              <label
                className="block text-gray-700 text-sm font-bold mb-2"
                htmlFor={row.name}
              >
                {row.label}
              </label>
              {inputField}
            </div>
          );
        })}
      </div>
      {/* <button className='text-white bg-blue-600 px-4 py-2 mx-auto block'>Add</button> */}
    </div>
  );
};

export default InputFormTwoColumn;

// import React from "react";

// const InputFormTwoColumn = ({ rows, onChange, data }) => {
//   return (
//     <div className="w-full p-4 bg-white rounded-lg">
//       <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
//         {rows.map((row, index) => {
//           let inputField;
//           const value = data[row?.name] || "";
//           console.log('value for image', data[row.name]);

//           if (row.type === "textArea") {
//             inputField = (
//               <textarea
//                 className="block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-200 focus:outline-none"
//                 id={row.name}
//                 placeholder={row.placeholder}
//                 required={row.isRequired}
//                 maxLength={row.maxChar}
//                 readOnly={row.readOnly}
//                 onChange={onChange}
//                 value={value}
//                 name={row.name}
//               />
//             );
//           } else if (row.type === "dropdown") {
//             inputField = (
//               <select
//                 className="block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-200 focus:outline-none"
//                 id={row.name}
//                 required={row.isRequired}
//                 readOnly={row.readOnly}
//                 onChange={onChange}
//                 value={value}
//                 name={row.name}
//               >
//                 {row.fields.map((fieldName, index) => (
//                   <option value={fieldName} key={index}>
//                     {fieldName}
//                   </option>
//                 ))}
//               </select>
//             );
//           } else if (row.type === "checkbox") {
//             inputField = (
//               <div className="flex items-center space-x-4">
//                 {row.fields.map((fieldName, index) => (
//                   <div key={index} className="flex items-center">
//                     <input
//                       type="checkbox"
//                       id={fieldName}
//                       className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
//                       required={row.isRequired}
//                       readOnly={row.readOnly}
//                       onChange={onChange}
//                       checked={data[row.name]?.includes(fieldName) || false}
//                       name={row.name}
//                       value={fieldName}
//                     />
//                     <label htmlFor={fieldName} className="ml-2 block text-sm text-gray-700">
//                       {fieldName}
//                     </label>
//                   </div>
//                 ))}
//               </div>
//             );
//           } else if (row.type === "radio") {
//             inputField = (
//               <div className="flex items-center space-x-4">
//                 {row.fields.map((fieldName, index) => (
//                   <div key={index} className="flex items-center">
//                     <input
//                       type="radio"
//                       id={fieldName.value}
//                       className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
//                       required={row.isRequired}
//                       readOnly={row.readOnly}
//                       onChange={onChange}
//                       checked={value === fieldName.value}
//                       value={fieldName.value}
//                       name={row.name}
//                     />
//                     <label htmlFor={fieldName.value} className="ml-2 block text-sm text-gray-700">
//                       {fieldName.label}
//                     </label>
//                   </div>
//                 ))}
//               </div>
//             );
//           } else {
//             inputField = (
//               <input
//                 className="block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-200 focus:outline-none"
//                 id={row.name}
//                 type={row.type}
//                 placeholder={row.placeholder}
//                 required={row.isRequired}
//                 maxLength={row.maxChar}
//                 readOnly={row.readOnly}
//                 onChange={onChange}
//                 value={value}
//                 name={row.name}
//               />
//             );
//           }

//           return (
//             <div className="mb-6" key={index}>
//               <label
//                 className="block text-gray-700 text-sm font-medium mb-2"
//                 htmlFor={row.name}
//               >
//                 {row.label}
//               </label>
//               {inputField}
//             </div>
//           );
//         })}
//       </div>
//       {/* <button className="mt-4 w-full py-2 bg-blue-600 text-white rounded-md shadow-md hover:bg-blue-700 transition duration-300">
//         Submit
//       </button> */}
//     </div>
//   );
// };

// export default InputFormTwoColumn;


