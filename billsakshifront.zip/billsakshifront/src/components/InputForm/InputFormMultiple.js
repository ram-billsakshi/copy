import React, {useState, useEffect} from 'react'

const onFormSubmit = (e) => {
    e.preventDefault();
    console.log("Form Submitted", e);
}


const InputFormMultiple = ({rows, itemsRow, addProductThroughBarCode= false, paymentTypeOptions= false, typeInvoice= false}) => {

    const [listName, setListNames] = useState([])
    const [selectedName, setSelectedName] = useState('')
    const [selectedPersonData, setSelectedPersonData] = useState([])
    const [selectedItems, setSelectedItems] = useState([])
    const [quantity, setQuantity] = useState('')
    const [item, setItem] = useState('')
    const [rate, setRate] = useState('')
    const [sgst, setSgst] = useState('')
    const [cgst, setCgst] = useState('')
    const [totalAmount, setTotalAmount] = useState('')
    const [itemsArray, setItemsArray] = useState([])
    const [ifShowDetails, setIfShowDetails] = useState(false)
    const [itemsListArray, setItemsListArray] = useState([])
    const [totalSubTotal, settotalSubTotal] = useState(0)
    const [sgstTotal, setsgstTotal] = useState(0)
    const [cgstTotal, setcgstTotal] = useState(0)
    const [total, settotal] = useState(0)
    const [customers, setCustomers] = useState([])
    const [rowsToDelete, setRowsToDelete] = useState([])

    useEffect(()=>{
        getItemsArray()
        getCustomerArray()
    }, [])

    const getItemsArray = async() => {
        const apiBaseUrl = process.env.REACT_APP_API_BASE_URL;
        const response = await fetch(`${apiBaseUrl}${'/getItems'}`);
        console.log(response)
        const data = await response.json()
        console.log(data)
        setItemsArray(data)
    }

    const getCustomerArray = async() => {
        const apiBaseUrl = process.env.REACT_APP_API_BASE_URL;
        const response = await fetch(`${apiBaseUrl}${'/getCustomers'}`);
        const data = await response.json()
        console.log('customers', data)
        setCustomers(data)
        // setItemsArray(data)
    }

    const handleItemChange = (e) => {
        console.log(e)
        const item = e.target.value
        // const getItemsInfo = fetch()
        console.log(item)
        setItem(item)
        const itemDetail = itemsArray.find((itemNew) =>{return itemNew.name === item})
        
        // setRate(itemDetail.rate)
        // setSgst(itemDetail.sgst)
        // setCgst(itemDetail.cgst)
        // const totalAmount = rate + sgst + cgst 
        // setTotalAmount(totalAmount)
    }

    const fetchUserNames = async () => {
        // const data = await fetch()
        const data = []
        // const values = await data.json()
        const values = []
        setListNames(values)
    }
    const handleSelectedName = async (e) => {
        const name = e.target.value
        setSelectedName(name)
        const data = customers.find((customer) => customer.name === name)
        console.log('customer data', data)
        setSelectedPersonData(data)
    }

    const handleSelectedItems = async(e)=>{
        const name = e.target.value
        selectedItems.push(name)
        setSelectedItems(selectedItems)
    }

    const onFormSubmitItems = (e) => {
        e.preventDefault();
        console.log("Form Submitted", e);

    }

    const addItemsToDelete = (index) => {
        console.log(index)
        setRowsToDelete(prevSelectedRows =>
            prevSelectedRows.includes(index)
                ? prevSelectedRows.filter(i => i !== index) // Uncheck
                : [...prevSelectedRows, index] // Check
        )
    }

    const addRowHandle = () => {
        console.log('trueueu')
        let itemList 
        if(typeInvoice){
            itemList = {
                name: 'Nescafe',
                quantity: 2,
                rate: 100,
                sgst: 15,
                cgst: 2,
                stocks: 5,
                igst: 5,
                total: 234  
            }
        } else{
            itemList = {
                name: 'Nescafe',
                quantity: 2,
                rate: 100,
                sgst: 15,
                cgst: 2,
                total: 234   
            }
        }

        setItemsListArray([...itemsListArray, itemList])
        setIfShowDetails(true)
        settotalSubTotal(totalSubTotal + rate)
        const sgstNow = rate * sgst/100
        setsgstTotal(sgstTotal + sgstNow)
        const cgstNow = rate * cgst/100
        setcgstTotal(cgstTotal + cgstNow)
        const totalNow = rate + sgst + cgst
        settotal(total + totalNow)
    }

    const deleteRowHandle = () => {
        setItemsListArray(prevItems => prevItems.filter((_, index) => !rowsToDelete.includes(index)));
        setRowsToDelete([]); 
    }

    useEffect(()=>{
        fetchUserNames()
    }, [])

  return (
    <div>
        <div className='flex'>
            <div className='w-1/2'>
                <form onSubmit={onFormSubmit} className="w-full max-w-lg">
                    {rows?.map((row, index) => {
                        let inputField;
                        if (row?.type === 'textArea') {
                            inputField = (
                                <textarea
                                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                    id={row.name}
                                    placeholder={row.name}
                                />
                            );
                        } else if (row?.type === 'checkbox') {
                            inputField = <div className='flex'>
                                {row?.fields?.map((fieldName, index) => (
                                <div key={index}>
                                    <input type="checkbox" id={fieldName} name={fieldName} value={fieldName} className='mx-1' />
                                    <label htmlFor={fieldName} className='mx-1'>{fieldName}</label>
                                </div>
                            ))};
                            </div> 
                            
                        } else if (row?.type === 'dropdown') {
                            inputField = (
                                <div className="flex items-center">
                                    <select 
                                    className="shadow border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                    value={selectedName}
                                    onChange={handleSelectedName}
                                    >
                                    {customers?.map((fieldName, index) => (
                                        <option value={fieldName.name} key={index}>{fieldName.name}</option>
                                        
                                    ))}
                                    </select>
                                </div>
                            );
                        }  else {
                            inputField = (
                                <input
                                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                    id={row.name}
                                    type={row.type}
                                    placeholder={row.name}
                                />
                            );
                        }
                        
                        return (
                            <div className="mb-4" key={index}>
                                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor={row.name}>
                                    {row.name}
                                </label>
                                {inputField}
                            </div>
                        );
                    })}
                </form>
            </div>
            {
                selectedName && selectedPersonData ? 
                <div className='w-1/2 border border-body-2 '>
                    <table className='w-full h-full border-s-1 border-black'>
                        <tr>
                            <th>Customer Details Preview</th>
                        </tr>
                        <tr>
                            <th>Name</th>
                            <th>{selectedPersonData.name}</th>     
                        </tr>
                        <tr>
                            <th>Phone</th>
                            <th>{selectedPersonData.contact}</th>     
                        </tr>
                        <tr>
                            <th>Email</th>
                            <th>{selectedPersonData.email}</th>     
                        </tr>
                        <tr>
                            <th>Address</th>
                            <th>{selectedPersonData.address}</th>     
                        </tr>
                        <tr>
                            <th>Customer Type</th>
                            <th>{selectedPersonData.customer_type}</th>     
                        </tr>
                    </table>
                </div> : ''
            }
        </div>
        <div className='mt-8 border-t-2 p-4 '>
            <form className='flex w-full' onSubmit={onFormSubmitItems}>

            {itemsRow?.map((row, index) => {
                        let inputField;
                        if (row?.type === 'textArea') {
                            inputField = (
                                <textarea
                                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                    id={row.name}
                                    placeholder={row.name}
                                    required={row.isRequired} 
                                    maxLength={row.maxChar}
                                    readOnly={row.readOnly}
                                />
                            );
                        } else if (row?.type === 'checkbox') {
                            inputField = <div className='flex'>
                                {row?.fields?.map((fieldName, index) => (
                                <div key={index}>
                                    <input type="checkbox" id={fieldName} name={fieldName} value={fieldName} className='mx-1' required={row.isRequired} 
                                maxLength={row.maxChar}
                                readOnly={row.readOnly}/>
                                    <label htmlFor={fieldName} className='mx-1'>{fieldName}</label>
                                </div>
                            ))};
                            </div> 
                            
                        } else if (row?.type === 'dropdown') {
                            inputField = (
                                <select 
                                    className="shadow border rounded w-full py-1.5 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                    value={item}
                                    onChange={handleItemChange}
                                >
                                {itemsArray?.map((fieldName, index) => (
                                    <option value={fieldName.name} key={index}>{fieldName.name}</option>
                                ))}
                                </select>
                            );
                        }  else {
                            inputField = (
                                <input
                                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                    id={row.name}
                                    type={row.type}
                                    placeholder={row.name}
                                    required={row.isRequired} 
                                    maxLength={row.maxChar}
                                    readOnly={row.readOnly}
                                />
                            );
                        }
                        
                        return (
                            <div className="mx-3 grow-1 w-full md:w-[14%] lg:grow-1" key={index}>
                                <label className="font-bold" htmlFor={row.name}>
                                    {row.name}
                                </label>
                                <div  className='mt-3'>
                                    {inputField}
                                </div>
                            </div>
                        );
                    })}
            </form>
            <div className='flex w-full justify-between'>
                    <div>
                        <button className='bg-green-500 text-white p-3 m-3 rounded' onClick={addRowHandle}>Add Row</button>
                        <button className='bg-red-500 text-white p-3 m-3 rounded' onClick={deleteRowHandle}>Delete Row</button>
                    </div>

                    {addProductThroughBarCode ? <div>
                        <button className='bg-blue-500 text-white p-3 m-3 rounded'>Add Product Through Bar Code</button>
                    </div> : ''}
                </div>
         <div className=''>
            <table className='w-full mb-10 mt-5'>
                <thead>
                    <tr className=''>
                    <th className="border-b border-blue-gray-100 bg-blue-gray-50 p-4"></th>
                        {itemsRow.map((row) => (
                            <th
                                key={row.name}
                                className="border-b border-blue-gray-100 bg-blue-gray-50 p-4 text-left"
                            >
                                {row.name}
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {ifShowDetails && itemsListArray.map((row, index) => (
                        <tr
                            key={index}
                            className="border-b border-blue-gray-100 bg-blue-gray-50 p-4"
                        >
                            <td className='p-4'>
                                    <input 
                                    type="checkbox" 
                                    checked={rowsToDelete.includes(index)}
                                    className="form-checkbox h-5 w-5 text-blue-600" 
                                    required={row.isRequired} 
                                    maxLength={row.maxChar}
                                    readOnly={row.readOnly}
                                    onChange={() => addItemsToDelete(index)}/>
                            </td>
                            {Object.keys(row).map((key) => (
                                <td key={key} className='p-4 text-left'>
                                    {row[key]}
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>

        </div>
        <div className='flex'>
            <div className='w-1/2'>
                <label>Terms & Conditions</label>
                <ul className='p-2'>
                    <li>All prices shown on the platform are in Indian INR and are exclusive of all taxes.</li>
                    <li>All products returned for refund/replacement or extended on credit must be returned in “saleable” condition with original packing.</li>
                    <li>We may condition future contract renewals or suspend our services to you until credit amount is paid in full in the stipulated time. </li>
                </ul>
            </div>
            <div className='w-1/2'>
                <div className='flex mx-2 border-b-2 border-bodydark p-2'>
                    <h1 className='font-bold mx-4 w-[40%]'>Subtotal:</h1>
                    <h1 className='font-bold mx-4 w-[20%]'>₹</h1>
                    <h1 className='font-bold mx-4 w-[40%] text-center'>1000</h1>
                </div>
                <div className='flex mx-2 border-b-2 border-bodydark p-2'>
                    <h1 className='font-bold mx-4 w-[40%]'>SGST%</h1>
                    <h1 className='font-bold mx-4 w-[20%]'>₹</h1>
                    <h1 className='font-bold mx-4 w-[40%] text-center'>1000</h1>
                </div>
                <div className='flex mx-2 border-b-2 border-bodydark p-2'>
                    <h1 className='font-bold mx-4 w-[40%]'>CGST%</h1>
                    <h1 className='font-bold mx-4 w-[20%]'>₹</h1>
                    <h1 className='font-bold mx-4 w-[40%] text-center'>1000</h1>
                </div>
                <div className='flex mx-2 border-b-2 border-bodydark p-2'>
                    <h1 className='font-bold mx-4 w-[40%]'>Total:</h1>
                    <h1 className='font-bold mx-4 w-[20%]'>₹</h1>
                    <h1 className='font-bold mx-4 w-[40%] text-center'>1000</h1>
                </div>
            </div>
        </div>

        <div className='w-full flex justify-end mt-5'>
        {paymentTypeOptions ?
            <div className='w-1/2'>
                <form className=''>
                <label className="block text-gray-700 text-sm font-bold my-2">Payment Type</label>
                <div>
                    <select className="shadow border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    >
                        <option>--Select Option--</option>
                        <option>One Time</option>
                        <option>Credit</option>
                        <option>Partial Credit</option>
                    </select>
                </div>
                <label className="block text-gray-700 text-sm font-bold my-2">Payment Option</label>
                <div>
                <select className="shadow border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                >
                    <option>--Select Option--</option>
                    <option>Cash</option>
                    <option>Digital</option>
                </select>
                </div>
                <label className="block text-gray-700 text-sm font-bold my-2">Discount(In Rupees)</label>
                <div>
                <input type="text" className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                </div>
            </form>
            </div>
        : ''
        }
        </div>
        <br/>
        <div className='flex justify-end'>
            <button className='bg-green-500 text-white p-3 mr-2 rounded'>Generate</button>
            <button className='bg-red-500 text-white p-3 rounded'>Cancel</button>
        </div>

    </div>
  )
}

export default InputFormMultiple