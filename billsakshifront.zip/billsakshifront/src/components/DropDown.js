import React, { useState, useEffect } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { MdKeyboardArrowDown } from "react-icons/md";
import { CgShapeCircle } from "react-icons/cg";

const DropDown = ({
  sidebarOpen,
  isOpen,
  onToggle,
  data,
  text,
  icon,
  level,
}) => {
  const location = useLocation();
  const [localIsOpen, setLocalIsOpen] = useState(isOpen);

  useEffect(() => {
    if (!sidebarOpen) {
      setLocalIsOpen(false);
    } else {
      setLocalIsOpen(isOpen);
    }
  }, [sidebarOpen, isOpen]);

  const handleToggle = () => {
    if (sidebarOpen) {
      setLocalIsOpen(!localIsOpen);
      onToggle();
    }
  };

  const paddingLeft = `${level * 0.5}rem`;

  return (
    <div className="transition-all duration-500">
      <div
        onClick={handleToggle}
        className="w-full flex gap-4 px-4 py-3 mt-1 text-gray-700 font-medium items-center cursor-pointer"
        style={{ paddingLeft }}
      >
        <div className="flex items-center" style={{ flexShrink: 0 }}>
          {icon}
        </div>
        <div
          className={`transition-all duration-500 group-hover:opacity-100 group-hover:max-w-full max-w-full flex items-center justify-between w-full ${
            !sidebarOpen ? "opacity-0 max-w-0" : "opacity-100 max-w-full"
          }`}
        >
          <span style={{ whiteSpace: "nowrap" }}>{text}</span> {/* Prevent text wrapping */}
          <MdKeyboardArrowDown
            className={`text-xl transition-transform duration-500 ${
              localIsOpen ? "" : "rotate-90"
            }`}
          />
        </div>
      </div>
      <div
        className={`${
          localIsOpen ? "max-h-screen" : "max-h-0"
        } overflow-hidden transition-max-height duration-500`}
      >
        {data.map((item, index) =>
          item.isDropDown ? (
            <DropDown
              key={index}
              isOpen={item.isDropOpen}
              icon={item.icon || <CgShapeCircle size={20} />}
              data={item.data}
              text={item.text}
              sidebarOpen={sidebarOpen}
              level={level + 1}
              onToggle={() => {}}
            />
          ) : (
            <NavLink
              key={index}
              to={item.route}
              className={`flex gap-4 items-center py-2 ${
                location.pathname === item.route ? "bg-[#092FF1] text-white" : ""
              }`}
              style={{ paddingLeft: `${(level + 1) * 0.5}rem` }}
            >
              <div className="flex items-center" style={{ flexShrink: 0 }}>
                {item.icon ? item.icon : <CgShapeCircle size={20} />}
              </div>
              <span style={{ whiteSpace: "nowrap" }}>{item.text}</span> {/* Prevent text wrapping */}
            </NavLink>
          )
        )}
      </div>
    </div>
  );
};

export default DropDown;
