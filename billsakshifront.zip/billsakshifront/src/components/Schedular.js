import React from 'react';
import { Calendar, dateFnsLocalizer } from 'react-big-calendar';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import './Schedularrr.css';
import format from 'date-fns/format';
import parse from 'date-fns/parse';
import startOfWeek from 'date-fns/startOfWeek';
import getDay from 'date-fns/getDay';
import enUS from 'date-fns/locale/en-US';

const locales = {
  'en-US': enUS,
};

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
});

const myEventsList = [
  {
    title: 'Meeting',
    start: new Date(2024, 5, 20, 10, 0),
    end: new Date(2024, 5, 20, 11, 0),
  },
  {
    title: 'Conference',
    start: new Date(2024, 5, 23, 12, 0),
    end: new Date(2024, 5, 23, 13, 0),
  },
];

const Event = ({ event }) => (
  <span>
    <strong>{event.title}</strong>
    <p>{event.desc}</p>
  </span>
);

const CustomToolbar = (toolbar) => {
  const goToBack = () => {
    toolbar.onNavigate('PREV');
  };

  const goToNext = () => {
    toolbar.onNavigate('NEXT');
  };

  const goToToday = () => {
    toolbar.onNavigate('TODAY');
  };

  const label = () => {
    const date = new Date(toolbar.date);
    return <span>{date.toLocaleDateString('default', { month: 'long', year: 'numeric' })}</span>;
  };

  return (
    <div className="rbc-toolbar">
      <span className="rbc-btn-group">
        <button type="button" onClick={goToBack}>Back</button>
        <button type="button" onClick={goToToday}>Today</button>
        <button type="button" onClick={goToNext}>Next</button>
      </span>
      <span className="rbc-toolbar-label">{label()}</span>
    </div>
  );
};

const Schedularrr = () => (
  <div>
    <Calendar
      localizer={localizer}
      events={myEventsList}
      startAccessor="start"
      endAccessor="end"
      style={{ height: 500 }}
      components={{
        event: Event,
        toolbar: CustomToolbar,
      }}
    />
  </div>
);

export default Schedularrr;
