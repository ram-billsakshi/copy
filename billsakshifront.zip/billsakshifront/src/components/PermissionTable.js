import React, { useEffect, useState } from 'react';

const PermissionTable = ({ data }) => {
  const [tableData, setTableData] = useState(data);

  useEffect(()=>{
    console.log(tableData);
  },[tableData])

  const handleColumnCheckboxChange = (column) => {
    const newData = tableData.map(module => ({
      ...module,
      functions: module.functions.map(func => ({
        ...func,
        [column]: !tableData.some(mod => mod.functions.some(f => f[column] === ""))
          ? "" : "checked"
      }))
    }));
    setTableData(newData);
  };

  const handleRowCheckboxChange = (moduleIndex, funcIndex, column) => {
    const newData = [...tableData];
    newData[moduleIndex].functions[funcIndex][column] =
      newData[moduleIndex].functions[funcIndex][column] === "checked" ? "" : "checked";
    setTableData(newData);
  };

  return (
    <div className="w-full">
      <table className="min-w-full border border-[rgba(0,0,0,0.1)]">
        <thead>
          <tr className='text-md'>
            <th className="px-6 py-3 font-semibold  border-b border-[rgba(0,0,0,0.1)] bg-gray-50 text-left font-medium text-gray-500 uppercase tracking-wider">Sl. No.</th>
            <th className="px-6 py-3 font-semibold  border-b border-[rgba(0,0,0,0.1)] bg-gray-50 text-left font-medium text-gray-500 uppercase tracking-wider">Module Name</th>
            <th className="px-6 py-3 font-semibold  border-b border-[rgba(0,0,0,0.1)] bg-gray-50 text-left font-medium text-gray-500 uppercase tracking-wider">Function Name</th>
            {["view", "add", "edit", "delete"].map(column => (
              <th key={column} className="px-6 py-3 font-semibold  border-b border-[rgba(0,0,0,0.1)] bg-gray-50 text-center font-medium text-gray-500 uppercase tracking-wider">
                <div className="flex justify-center items-center">
                  {column.charAt(0).toUpperCase() + column.slice(1)}
                  <input
                    type="checkbox"
                    className="ml-2"
                    onChange={() => handleColumnCheckboxChange(column)}
                  />
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {tableData.map((module, moduleIndex) => (
            <React.Fragment key={module.sl_no}>
              <tr className="bg-blue-100 text-md font-semibold">
                <td className="px-6 py-4 border-b border-[rgba(0,0,0,0.1)]">{module.sl_no}</td>
                <td className="px-6 py-4 border-b border-[rgba(0,0,0,0.1)]">{module.module_name}</td>
                <td className="px-6 py-4 border-b border-[rgba(0,0,0,0.1)]" colSpan="5"></td>
              </tr>
              {module.functions.map((func, funcIndex) => (
                <tr key={func.sl_no} className={`text-md ${funcIndex%2===0?"bg-white":"bg-blue-50"}`}>
                  <td className="px-6 py-4 border-b border-[rgba(0,0,0,0.1)]">{func.sl_no}</td>
                  <td className="px-6 py-4 border-b border-[rgba(0,0,0,0.1)]"></td>
                  <td className="px-6 py-4 border-b border-[rgba(0,0,0,0.1)]">{func.function_name}</td>
                  {["view", "add", "edit", "delete"].map(column => (
                    <td key={column} className="px-6 py-4 border-b border-[rgba(0,0,0,0.1)] text-center">
                      <input
                        type="checkbox"
                        checked={func[column] === "checked"}
                        onChange={() => handleRowCheckboxChange(moduleIndex, funcIndex, column)}
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
};

  export default PermissionTable