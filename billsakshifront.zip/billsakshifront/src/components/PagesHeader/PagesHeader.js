import React from 'react'
import { useNavigate } from 'react-router-dom'

const PagesHeader = ({navigateTo= null, heading, button= null }) => {
    const navigate = useNavigate()

    const handleOnClickNavigate = () => {
        navigate(navigateTo)
    }
  return (
    <div>
        <div className='flex justify-between border-b-2 border-bodydark p-3'>
            <h1 className='text-xl'>{heading}</h1>
            {button ? <div className='flex bg-blue-600 p-1'>
                <button onClick={handleOnClickNavigate} className=' text-white px-4 my-auto text-lg'>{button}</button>
            </div>: <></>}
        </div>
    </div>
  )
}

export default PagesHeader