import React from 'react'

const Buttons = ({buttons, list}) => {
  return (
    <div className=''>
        {
        buttons?.map((button, index)=>{
        return <button className="bg-[#6c757d] hover:bg-graydark text-white font-bold p-1 rounded ml-1">
                {button} 
        </button> 
        })}
    </div>
  )
}

export default Buttons