import React, { useEffect, useState } from 'react'

const Report = ({heading, fetchPersons, rows}) => {

    const [data, setData] = useState([])
    const [selectedName, setSelectedName] = useState('')
    useEffect(()=>{
        getCustomers()
    }, [])

    const handleSelectedName = () => {

    }
    const onFormSubmit = (e) => {
        e.prevent.default()
    }

    const getCustomers = async() => {
        const apiBaseUrl = process.env.REACT_APP_API_BASE_URL;
        const response = await fetch(`${apiBaseUrl}${fetchPersons}`);
        const data = await response.json()
        console.log('customers', data)
        setData(data)
    }
  return (
    <div className='flex'>
        <div className='w-1/3'>{heading}</div>
        <div className='w-2/3 flex flex-wrap'>
        <form onSubmit={onFormSubmit} className="flex flex-wrap w-full p-3 ml-3">
            {rows?.map((row, index) => {
                let inputField;
                if (row?.type === 'textArea') {
                    inputField = (
                        <textarea
                            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                            id={row.name}
                            placeholder={row.name}
                            required={row.isRequired} 
                            maxLength={row.maxChar}
                            readOnly={row.readOnly}
                        />
                    );
                } else if (row?.type === 'checkbox') {
                    inputField = <div className='flex'>
                        {row?.fields?.map((fieldName, index) => (
                        <div key={index}>
                            <input type="checkbox" id={fieldName} name={fieldName} value={fieldName} className='' required={row.isRequired} 
                                maxLength={row.maxChar}
                                readOnly={row.readOnly}/>
                            <label htmlFor={fieldName} className='mx-1'>{fieldName}</label>
                        </div>
                    ))};
                    </div> 
                    
                } else if (row?.type === 'dropdown') {
                    inputField = (
                        <div className="flex items-center w-full    ">
                            <select 
                            className="shadow border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                            value={selectedName}
                            onChange={handleSelectedName}
                            >
                            {data?.map((fieldName, index) => (
                                <option value={fieldName.name} key={index}>{fieldName.name}</option>
                                
                            ))}
                            </select>
                        </div>
                    );
                }  else {
                    inputField = (
                        <input
                            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                            id={row.name}
                            type={row.type}
                            placeholder={row.name}
                            required={row.isRequired} 
                            maxLength={row.maxChar}
                            readOnly={row.readOnly}
                        />
                    );
                }
                return (
                    <div className="mb-4 flex" key={index}>
                        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor={row.name}>
                            {row.name}
                        </label>
                        <div className='mx-3'>
                        {inputField}
                        </div>
                    </div>
                );
            })}
            <button className='bg-green-500 text-white p-2 mr-2 rounded' type='submit'>Find</button>
        </form>
        </div>
    </div>
  )
}

export default Report