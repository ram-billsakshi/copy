import React from "react";
import { Link } from "react-router-dom";

const InvoiceTableCard = ({invoices,columns,tblHead,viewAllRoute="#"}) => {

  return (
    <div className="bg-white shadow-md p-5 pb-7">
        <div className="w-full flex justify-between mb-4 text-[#007bff]">
            <div className="font-bold">{tblHead}</div>
            <Link to={viewAllRoute}>View All</Link>
        </div>
      <table className="w-full">
        <thead>
          <tr>
            {columns.map((col,index) => <th className="px-4 py-4 text-left text-gray-600" key={index}>{col}</th>)}
          </tr>
        </thead>
        <tbody>
          {invoices?.map((invoice, index) => (
            <tr className={`${index%2 === 0 ? 'bg-[#f2f2f2] shadow-lg' : 'bg-white'} border-t border-[#e2e6e9]`} key={invoice.invoiceNumber}>
              <td className="px-4 py-4 text-[#007bff]">{invoice.invoiceNumber}</td>
              <td className="px-4 py-4">{invoice.date}</td>
              <td className="px-4 py-4">{invoice.amount}</td>
             {invoice.status!==undefined && <td className="px-4 py-4">{invoice.status}</td>}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default InvoiceTableCard;
