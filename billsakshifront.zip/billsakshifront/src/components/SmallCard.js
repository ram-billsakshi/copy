import React from 'react'


const SmallCard = ({icon,head1,head2}) => {
  return (
    <div className="w-full flex flex-col gap-2 justify-center items-center">
    <div className="w-15 h-15 border-2 border-dotted border-[#4634ec] rounded-full flex justify-center items-center">{icon}</div>
    <h2 className="text-[#666] font-bold text-xl">{head1}</h2>
    <p className="text-[#444444] font-normal">{head2}</p>
  </div>
  )
}

export default SmallCard