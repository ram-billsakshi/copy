import React from 'react';
import { Calendar, dateFnsLocalizer, Views } from 'react-big-calendar';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import './index.css';
import format from 'date-fns/format';
import parse from 'date-fns/parse';
import startOfWeek from 'date-fns/startOfWeek';
import getDay from 'date-fns/getDay';
import enUS from 'date-fns/locale/en-US';

const locales = {
  'en-US': enUS,
};

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
});

const myEventsList = [
  {
    title: 'INV13620249526',
    start: new Date(2024, 5, 20, 10, 0),
    end: new Date(2024, 5, 20, 11, 0),
  },
  {
    title: 'INV13620249520',
    start: new Date(2024, 5, 23, 12, 0),
    end: new Date(2024, 5, 23, 13, 0),
  },
];

const CustomToolbar = (toolbar) => {
  const goToBack = () => {
    toolbar.onNavigate('PREV');
  };

  const goToNext = () => {
    toolbar.onNavigate('NEXT');
  };

  const goToToday = () => {
    toolbar.onNavigate('TODAY');
  };

  const label = () => {
    const date = new Date(toolbar.date);
    return <span>{date.toLocaleDateString('default', { month: 'long', year: 'numeric' })}</span>;
  };

  return (
    <div className="rbc-toolbar font-medium">
      <span className="rbc-btn-group">
        <button type="button" onClick={goToBack}>Back</button>
        <button type="button" onClick={goToToday}>Today</button>
        <button type="button" onClick={goToNext}>Next</button>
      </span>
      <span className="rbc-toolbar-label">{label()}</span>
      <span className="rbc-btn-group">
        <button type="button" onClick={() => toolbar.onView('day')}>Day</button>
        <button type="button" onClick={() => toolbar.onView('week')}>Week</button>
        <button type="button" onClick={() => toolbar.onView('month')}>Month</button>
      </span>
    </div>
  );
};

const Index = () => (
  <div className='bg-white p-3 shadow-md'>
    <h2 className='text-center mb-2 text-[#80caee] font-semibold'>Sale Dues Calendar</h2>
    <Calendar
      localizer={localizer}
      events={myEventsList}
      startAccessor="start"
      endAccessor="end"
      style={{ height: 450 }}
      views={[Views.MONTH, Views.WEEK, Views.DAY]}
      components={{
        toolbar: CustomToolbar,
      }}
    />
  </div>
);

export default Index;
