import React from 'react'
import { Link } from 'react-router-dom'

const BtnPrimary = ({text, action,route}) => {
  return <Link to={route?route:'#'} onClick={()=>{action && action()}} className={`bg-[#3b82f6] text-white py-2 px-4 rounded`}>{text}</Link>
}

export default BtnPrimary