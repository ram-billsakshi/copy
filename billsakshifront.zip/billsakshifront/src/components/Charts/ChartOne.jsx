import React, { useState, useEffect } from "react";
import ReactApexChart from "react-apexcharts";
import moment from "moment"; // For date manipulation
import { salesData } from "../../data/data";

// Example sales data (this would normally come from your backend or state)


// Generate data for the last 7 days
const getLast7DaysData = (data) => {
  const last7Days = [];
  for (let i = 6; i >= 0; i--) {
    const date = moment().subtract(i, 'days').format('YYYY-MM-DD');
    const sales = data.find(d => d.date === date);
    last7Days.push({ date, total: sales ? sales.total : Math.floor(Math.random() * 100) });
  }
  return last7Days;
};

// Generate data for the last 4 weeks
const getLast4WeeksData = (data) => {
  const last4Weeks = [];
  for (let i = 3; i >= 0; i--) {
    const week = moment().subtract(i, 'weeks').format('YYYY-[W]WW');
    const sales = data.find(d => d.week === week);
    last4Weeks.push({ week, total: sales ? sales.total : Math.floor(Math.random() * 400) });
  }
  return last4Weeks;
};

// Generate data for the last 12 months
const getLast12MonthsData = (data) => {
  const last12Months = [];
  for (let i = 11; i >= 0; i--) {
    const month = moment().subtract(i, 'months').format('YYYY-MM');
    const sales = data.find(d => d.month === month);
    last12Months.push({ month, total: sales ? sales.total : Math.floor(Math.random() * 2000) });
  }
  return last12Months;
};

// Generate data for the last 5 years
const getLast5YearsData = (data) => {
  const last5Years = [];
  for (let i = 4; i >= 0; i--) {
    const year = moment().subtract(i, 'years').format('YYYY');
    const sales = data.find(d => d.year === year);
    last5Years.push({ year, total: sales ? sales.total : Math.floor(Math.random() * 20000) });
  }
  return last5Years;
};

const ChartOne = () => {
  const [currentTimeFrame, setCurrentTimeFrame] = useState("day");
  const [chartData, setChartData] = useState({ categories: [], series: [] });

  useEffect(() => {
    let data;
    switch (currentTimeFrame) {
      case "day":
        data = getLast7DaysData(salesData.daily);
        setChartData({
          categories: data.map(d => d.date),
          series: [{ name: "Total Sales", data: data.map(d => d.total) }]
        });
        break;
      case "week":
        data = getLast4WeeksData(salesData.weekly);
        setChartData({
          categories: data.map(d => d.week),
          series: [{ name: "Total Sales", data: data.map(d => d.total) }]
        });
        break;
      case "month":
        data = getLast12MonthsData(salesData.monthly);
        setChartData({
          categories: data.map(d => d.month),
          series: [{ name: "Total Sales", data: data.map(d => d.total) }]
        });
        break;
      case "year":
        data = getLast5YearsData(salesData.yearly);
        setChartData({
          categories: data.map(d => d.year),
          series: [{ name: "Total Sales", data: data.map(d => d.total) }]
        });
        break;
      default:
        break;
    }
  }, [currentTimeFrame]);

  const options = {
    legend: {
      show: false,
      position: "top",
      horizontalAlign: "left",
    },
    colors: ["#3C50E0", "#80CAEE"],
    chart: {
      fontFamily: "Satoshi, sans-serif",
      height: 335,
      type: "area",
      dropShadow: {
        enabled: true,
        color: "#623CEA14",
        top: 10,
        blur: 4,
        left: 0,
        opacity: 0.1,
      },
  
      toolbar: {
        show: false,
      },
    },
    responsive: [
      {
        breakpoint: 1024,
        options: {
          chart: {
            height: 300,
          },
        },
      },
      {
        breakpoint: 1366,
        options: {
          chart: {
            height: 350,
          },
        },
      },
    ],
    stroke: {
      width: [2, 2],
      curve: "straight",
    },
  
    grid: {
      xaxis: {
        lines: {
          show: true,
        },
      },
      yaxis: {
        lines: {
          show: true,
        },
      },
    },
    dataLabels: {
      enabled: false,
    },
    markers: {
      size: 4,
      colors: "#fff",
      strokeColors: ["#3056D3", "#80CAEE"],
      strokeWidth: 3,
      strokeOpacity: 0.9,
      strokeDashArray: 0,
      fillOpacity: 1,
      discrete: [],
      hover: {
        size: undefined,
        sizeOffset: 5,
      },
    },
  
    xaxis: {
      type: "category",
      categories: chartData.categories,
      axisBorder: {
        show: false,
      },
      axisTicks: {
        show: false,
      },
    },
    yaxis: {
      title: {
        style: {
          fontSize: "0px",
        },
      },
      min: 0,
    },
    stroke: {
      curve: 'smooth'
    },
    tooltip: {
      x: {
        format: currentTimeFrame === "day" ? 'dd/MM/yyyy' : currentTimeFrame === "week" ? 'YYYY-[W]WW' : currentTimeFrame === "month" ? 'MMM yyyy' : 'yyyy',
      },
    }
  };

  const handleTimeFrameChange = (timeFrame) => {
    setCurrentTimeFrame(timeFrame);
  };

  return (
    <div className="col-span-12 rounded-sm border border-stroke bg-white px-5 pt-7.5 pb-5 shadow-default dark:border-strokedark dark:bg-boxdark sm:px-7.5">
      <div className="flex flex-wrap items-start justify-between gap-3 sm:flex-nowrap">
        <div className="flex w-full flex-wrap gap-3 sm:gap-5">
          <div className="flex min-w-47.5">
            <span className="mt-1 mr-2 flex h-4 w-full max-w-4 items-center justify-center rounded-full border border-secondary">
              <span className="block h-2.5 w-full max-w-2.5 rounded-full bg-secondary"></span>
            </span>
            <div className="w-full">
              <p className="font-semibold text-secondary">Total Sales</p>
            </div>
          </div>
        </div>
        <div className="flex w-full max-w-45 justify-end">
          <div className="inline-flex items-center rounded-md bg-whiter p-1.5 dark:bg-meta-4">
            <button onClick={() => handleTimeFrameChange("day")} className={`rounded py-1 px-3 text-xs font-medium text-black hover:bg-white hover:shadow-card dark:text-white dark:hover:bg-boxdark ${currentTimeFrame === "day" ? "bg-white" : ""}`}>
              Day
            </button>
            <button onClick={() => handleTimeFrameChange("week")} className={`rounded py-1 px-3 text-xs font-medium text-black hover:bg-white hover:shadow-card dark:text-white dark:hover:bg-boxdark ${currentTimeFrame === "week" ? "bg-white" : ""}`}>
              Week
            </button>
            <button onClick={() => handleTimeFrameChange("month")} className={`rounded py-1 px-3 text-xs font-medium text-black hover:bg-white hover:shadow-card dark:text-white dark:hover:bg-boxdark ${currentTimeFrame === "month" ? "bg-white" : ""}`}>
              Month
            </button>
            <button onClick={() => handleTimeFrameChange("year")} className={`rounded py-1 px-3 text-xs font-medium text-black hover:bg-white hover:shadow-card dark:text-white dark:hover:bg-boxdark ${currentTimeFrame === "year" ? "bg-white" : ""}`}>
              Year
            </button>
          </div>
        </div>
      </div>

      <div>
        <div id="chartOne" >
          <ReactApexChart
            options={options}
            series={chartData.series}
            type="area"
            height={403}
          />
        </div>
      </div>
    </div>
  );
};

export default ChartOne;
