import React, { useEffect, useState } from "react";
import billsakshiLogo from "../../images/billsakshi/billsakshiLogo.svg";
import { Link, NavLink, useLocation } from "react-router-dom";
import DropDown from "../DropDown";
import { sidebarData as sidebar } from "../../data/data";

const level = 1;

const Index = ({ sidebarOpen }) => {
  const [sidebarData, setSidebarData] = useState(sidebar);
  const [openDropDown, setOpenDropDown] = useState(null); // State to track open dropdown
  const [hovered, setHovered] = useState(false);
  const location = useLocation();

  useEffect(() => {
    console.log(location.pathname, "testing");
  }, [location]);

  useEffect(() => {
    if (!sidebarOpen) {
      setHovered(false);
    }
  }, [sidebarOpen]);

  const handleDropDown = (index) => {
    if (openDropDown === index) {
      setOpenDropDown(null);
    } else {
      setOpenDropDown(index);
    }
  };


  return (
    <div
      className={`bg-white transition-all duration-500 text-[#626262] ${
        sidebarOpen || hovered ? "w-64" : "w-17"
      } group`}
      style={{ boxShadow: "2px 0 3px -1px rgba(0, 0, 0, 0.3)",zIndex:"10" }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div className="h-[82px] mb-2 border-b border-[rgba(0,0,0,0.1)] flex items-center justify-center gap-3">
        <Link to={"/"}>
          <img src={billsakshiLogo} alt="Logo" className="w-12 h-12" />
        </Link>
        <div
                  className={`text-xl transition-all duration-500 group-hover:opacity-100 group-hover:max-w-full ${
                    !sidebarOpen && !hovered
                      ? "opacity-0 max-w-0"
                      : "opacity-100 max-w-full"
                  }`}
                  style={{ whiteSpace: "nowrap" }} 
                >BillSakshi</div>
      </div>
      <ul className="overflow-y-auto h-[calc(100vh-82px)]">
        {sidebarData.map((item, index) => (
          <li key={item.text} className={`shadow-sm`}>
            {item.isDropDown ? (
              <div className="flex mb-1.5">
                <div className="w-full">
                  <DropDown
                    sidebarOpen={sidebarOpen || hovered}
                    isOpen={openDropDown === index}
                    onToggle={() => handleDropDown(index)}
                    icon={item.icon}
                    data={item.data}
                    text={item.text}
                    level={level + 1}
                  />
                </div>
              </div>
            ) : (
              <NavLink
                style={{ paddingLeft: `${(level + 1) * 0.5}rem` }}
                to={item.route}
                className={`mb-1.5 py-3 flex gap-4 items-center font-medium transition-colors duration-300 ${
                  location.pathname === item.route ? "bg-[#092FF1] text-white" : ""
                }`}
              >
                <div className="flex items-center" style={{ flexShrink: 0 }}>
                  {item.icon}
                </div>
                <div
                  className={`transition-all duration-500 group-hover:opacity-100 group-hover:max-w-full ${
                    !sidebarOpen && !hovered
                      ? "opacity-0 max-w-0"
                      : "opacity-100 max-w-full"
                  }`}
                  style={{ whiteSpace: "nowrap" }} 
                >
                  {item.text}
                </div>
              </NavLink>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Index;
