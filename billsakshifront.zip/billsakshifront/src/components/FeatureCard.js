import React from 'react'

const FeatureCard = ({img,text}) => {
  return (
    <div className="w-1/2 lg:w-2/3 grow flex justify-center items-center flex-col m-auto">
    <img src={img} alt="" className="w-full" />
    <h2 className="text-[#515f7d] text-lg font-medium text-center">{text}</h2>
  </div>
  )
}

export default FeatureCard