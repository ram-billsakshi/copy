import React,{useState,useEffect} from "react";
import BtnPrimary from "./BtnPrimary";

const Report2 = ({fetchPersons,heading}) => {
  const [data, setData] = useState([]);
  const [selectedName, setSelectedName] = useState("");
  useEffect(() => {
    getCustomers();
  }, []);

  const handleSelectedName = () => {};
  const onFormSubmit = (e) => {
    e.prevent.default();
  };

  const getCustomers = async () => {
    const apiBaseUrl = process.env.REACT_APP_API_BASE_URL;
    const response = await fetch(`${apiBaseUrl}${fetchPersons}`);
    const data = await response.json();
    console.log("customers", data);
    setData(data);
  };
  return (
    <div className="flex flex-wrap">
      <div className="w-full xl:w-[20%]">
        <h2 className="text-md">{heading}</h2>
      </div>
      <form className="w-[75%] flex flex-wrap gap-2 grow">
        <div className="w-full p-2 grow">
          <label>Customer Wise</label>
          <br />
          <select className="w-full text-[rgba(0,0,0,0.8)] p-3 rounded-md bg-white outline-none border border-[rgba(0,0,0,0.1)] mt-2">
          <option value="">--Select--</option>

            {data?.map((fieldName, index) => (
              <option value={fieldName.name} key={index}>
                {fieldName.name}
              </option>
            ))}
          </select>
        </div>
        <div className="w-[20%] p-2 grow">
          <label>Year</label>
          <br />
          <select className="w-full text-[rgba(0,0,0,0.8)] p-3 rounded-md bg-white outline-none border border-[rgba(0,0,0,0.1)] mt-2">
            <option value="">--Select--</option>
            <option value="">All</option>
            <option value="">2022</option>
            <option value="">2023</option>
            <option value="">2024</option>
          </select>
        </div>
        <div className="w-[20%] p-2 grow">
          <label>Group by Data</label>
          <br />
          <select className="w-full text-[rgba(0,0,0,0.8)] p-3 rounded-md bg-white outline-none border border-[rgba(0,0,0,0.1)] mt-2">
            <option value="">--Select--</option>
            <option value="">Daily</option>
            <option value="">Monthly</option>
            <option value="">Yearly</option>
          </select>
        </div>
        <div className="w-[20%] p-2 grow">
          <label>From Date</label>
          <br />
          <input
            type="date"
            className="w-full text-[rgba(0,0,0,0.8)] p-2.5 rounded-md bg-white outline-none border border-[rgba(0,0,0,0.1)] mt-2"
          />
        </div>
        <div className="w-[20%] p-2 grow">
          <label>From Date</label>
          <br />
          <input
            type="date"
            className="w-full text-[rgba(0,0,0,0.8)] p-2.5 rounded-md bg-white outline-none border border-[rgba(0,0,0,0.1)] mt-2"
          />
        </div>
        <div className="w-full">
          <BtnPrimary text={"Find"} />
        </div>
      </form>
    </div>
  );
};

export default Report2;
