import React from 'react'
import banner from "../images/billsakshi/banner2.png"
import loveIndia from "../images/billsakshi/love-india.png"

const HeroSection = () => {
  return (
    <section id="home" className='min-h-[100vh] pl-3 lg:pl-6 pt-32'>
        <div className="w-full flex flex-wrap diagonal-split bg-diagonal">
        <div className="w-[100%]  lg:w-[50%] flex justify-center items-center flex-col order-2 lg:order-1">
          <div>
            <h1 className="text-3xl lg:text-5xl text-[#092FF1] font-bold text-center lg:text-left mb-3">Billsakshi</h1>
            <h2 className="text-[#515f7d] text-xl font-medium lg:my-2">A Cloud Based GST Billing, and Inventory Management Software</h2>
          </div>
        </div>
        <div className="w-[100%] lg:w-[50%] flex justify-center items-center order-1 lg:order-2 flex-col py-10 lg:items-start lg:py-20">
          <div className=" w-[65%] flex flex-col items-center" >
            <img src={banner} alt="" className="w-full" />
            <img src={loveIndia} alt="" className="w-[70%] my-4 " />
          </div>
        </div>
      </div>
    </section>
  )
}

export default HeroSection