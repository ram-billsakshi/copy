import React from 'react';
import { useNavigate } from 'react-router-dom';
import LoginFinal3 from '../../images/billsakshi/LoginFinal3.png'

const CompanyInfoView = () => {
  const navigate = useNavigate();

//   const buttonGroup = [
//     {
//       name: 'Add',
//       action: 'addPage',
//       navigate: '/add-page',
//       className: 'bg-red-500 text-white px-4 py-2 rounded hover:bg-red-700'
//     },
//     {
//       name: 'Company List',
//       action: 'listPage',
//       navigate: '/company-list',
//       className: 'bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700'
//     }
//   ];

//   const handleButtonClick = (actionHandle, path) => {
//     switch (actionHandle) {
//       case 'addPage':
//         navigate(path);
//         break;
//       case 'listPage':
//         navigate(path);
//         break;
//       default:
//         break;
//     }
//   };

  return (
    <div className="flex">
      <div className="w-1/3 bg-red-500">
        <img src={LoginFinal3} alt="Company Logo" className="w-full h-full" />
      </div>
      <div className="ml-20 grid grid-cols-2 gap-4">
        <div className="col-span-1">
          <div className="mb-2">
            <strong>Name:-</strong> Billsakshi
          </div>
          <div className="mb-2">
            <strong>Email:-</strong> kimlit.com@gmail.com
          </div>
          <div className="mb-2">
            <strong>GST:-</strong> 10AAICK0683L1ZJ
          </div>
          <div className="mb-2">
            <strong>TIN No.:-</strong> U80100BR2020PLC045866
          </div>
          <div className="mb-2">
            <strong>Pan Individual:-</strong> APVPS5869M
          </div>
          <div className="mb-2">
            <strong>City:-</strong> Patna
          </div>
          <div className="mb-2">
            <strong>Country:-</strong> India
          </div>
          <div className="mb-2">
            <strong>Address:-</strong> PGS More, Near Hotel Kautilya Inn, Khagaul Danapur Road, Danapur, Patna, Bihar - 801503 India
          </div>
        </div>
        <div className="col-span-1">
          <div className="mb-2">
            <strong>Contact:-</strong> 7004770290
          </div>
          <div className="mb-2">
            <strong>Pan Card:-</strong> AAICK0683L
          </div>
          <div className="mb-2">
            <strong>CIN No.:-</strong> U80100BR2020PLC045866
          </div>
          <div className="mb-2">
            <strong>Registration No.:-</strong> U80100BR2020PLC045868
          </div>
          <div className="mb-2">
            <strong>Type:-</strong> Limited Company
          </div>
          <div className="mb-2">
            <strong>State:-</strong> Bihar
          </div>
          <div className="mb-2">
            <strong>Zip Code:-</strong> 801503
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompanyInfoView;
