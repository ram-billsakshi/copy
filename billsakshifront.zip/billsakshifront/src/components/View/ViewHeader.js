import React from 'react'
import { useNavigate } from 'react-router-dom';

const ViewHeader = ({heading = null, buttonGroup}) => {
    const navigate = useNavigate()
    
    const handleButtonClick = (actionHandle, path) => {
        console.log(actionHandle)
        console.log(navigate)
        console.log('in handle chlick')
        switch(actionHandle) {
            case 'addPage':
              navigate(path)
              break;
            case 'listPage':
              navigate(path);
              break;
            case 'print':
              window.print();
              break;
            default:
              break;
          }
    }

  return (
    <div className='flex justify-between items-center'>
        <h1 className='font-bold text-2xl'>{heading}</h1>
        <div className='flex'>
            {
                buttonGroup.map((buttons)=>{
                    return <button onClick={() => handleButtonClick(buttons.action, buttons.navigate)} className={buttons.className}>{buttons.name}</button>
                })
            }
        </div>
    </div>
  )
}

export default ViewHeader
