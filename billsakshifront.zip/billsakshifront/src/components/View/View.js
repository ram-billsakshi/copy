import React from 'react';

const View = ({tableHeading, paymentIncluded, billDetials}) => {
  return (
    <div className="">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p><span className="font-semibold">Name:</span> suresh</p>
            <p><span className="font-semibold">Contact:</span> 8423341664</p>
            <p><span className="font-semibold">Email:</span> suresh89@gmail.com</p>
            <p><span className="font-semibold">Address:</span> mira road</p>
          </div>
          <div>
            <p><span className="font-semibold">Invoice Date:</span> 25-06-2024</p>
            <p><span className="font-semibold">Due Date:</span> dd-mm-yyyy</p>
          </div>
        </div>

      <div className="border-b pb-4 mb-4">
        <h2 className="text-xl font-semibold mb-2">Invoice INV25620244636</h2>
        <table className="w-full text-left border">
          <thead>
            <tr>
              <th className="border p-2">S.No</th>
              <th className="border p-2">Item Details</th>
              <th className="border p-2">Quantity</th>
              <th className="border p-2">Rate</th>
              <th className="border p-2">Tax%</th>
              <th className="border p-2">Total Amount</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border p-2">1</td>
              <td className="border p-2">Pulses</td>
              <td className="border p-2">1 KG</td>
              <td className="border p-2">180</td>
              <td className="border p-2">IGST(5%) - 9</td>
              <td className="border p-2">180</td>
            </tr>
            <tr>
              <td className="border p-2">2</td>
              <td className="border p-2">Vim Bar</td>
              <td className="border p-2">1 Ps</td>
              <td className="border p-2">120</td>
              <td className="border p-2">IGST(5%) - 6</td>
              <td className="border p-2">120</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="border-b pb-4 mb-4">
        <p><span className="font-semibold">Payment Mode:</span> Cash</p>
        <p><span className="font-semibold">Payment Type:</span> One Time</p>
        <p><span className="font-semibold">Order Id:</span> order_NHK8vCiNIBHs</p>
        <p><span className="font-semibold">Payment Status:</span> Success</p>
        <p><span className="font-semibold">Payment By:</span> Cash</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <h3 className="font-semibold">Terms and Conditions</h3>
          <ul className="list-disc ml-6">
            <li>All prices shown on the platform are in Indian INR and are exclusive of all taxes.</li>
            <li>All products returned for refund/replacement or extended on credit must be returned in "saleable" condition with original packing.</li>
            <li>We may condition future contract renewals or suspend our services to you until credit amount is paid in full in the stipulated time.</li>
          </ul>
        </div>
        <div className="text-right">
          <p><span className="font-semibold">Sub Total:</span> ₹300</p>
          <p><span className="font-semibold">GST%:</span> ₹15</p>
          <p><span className="font-semibold">Total:</span> ₹315</p>
          <p><span className="font-semibold">Discount:</span> ₹0</p>
          <p><span className="font-semibold">Grand Total:</span> ₹315.00</p>
          <p><span className="font-semibold">Paid:</span> ₹315</p>
          <p><span className="font-semibold">Due:</span> ₹0</p>
        </div>
      </div>
    </div>
  );
};

export default View;
