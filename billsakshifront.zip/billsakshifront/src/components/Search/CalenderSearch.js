import React, {useState} from 'react';

function SearchWithCalendar({inputField}) {
  const [selectedDate, setSelectedDate] = React.useState('');

  const handleDateChange = (event) => {
    setSelectedDate(event.target.value);
  };

  const [date, setDate] = useState("");
  return (
    <div className='flex my-auto  content-center'>
      <input
            type="date"
            value={date}
            placeholder="DD/MM/YY"
            onChange={(e) => setDate(e.target.value)}
            // style={{border: '2px solid #ebebeb', padding: '5px', margin: "auto"}}
            className='border border-1 border-bodydark p-5 my-auto h-10'
        />
      {inputField ? <input
            type="text"
            value={date}
            placeholder="Search"
            onChange={(e) => setDate(e.target.value)}
            className='border border-1 border-bodydark ml-1 h-10 my-auto p-5'
        /> : ' ' }
    </div>
  );
}

export default SearchWithCalendar;
