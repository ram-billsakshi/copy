import { useState, useEffect } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import BtnPrimary from './BtnPrimary';
import { copyArrayToText, exportArrayToCSV, exportArrayToExcel, exportArrayToPDF, printTable } from '../utils';

const theme = createTheme({
  components: {
    MuiDataGrid: {
      styleOverrides: {
        columnHeader: {
          backgroundColor:"#f2f2f2",
          fontSize: '1rem',
          // color: "#626262",
          '& .MuiDataGrid-columnHeaderTitle': {
            fontWeight: 'bold',
          },
        },
      },
    },
  },
});


const fetchDataFromApi = async (url) => {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  const data = await response.json();
  return data;
};

const DataTable = ({isHead=true, endpoint, columns, type,isHeaderAction=true,isAdd=true,redirect="#" }) => {
  const [paginationModel, setPaginationModel] = useState({
    page: 0,
    pageSize: 10,
  });
  const [rows, setRows] = useState([]);
  const [rowCount, setRowCount] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const apiBaseUrl = process.env.REACT_APP_API_BASE_URL;

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      setError(null);

      try {
        const totalCountResponse = await fetch(`${apiBaseUrl}${endpoint}`);
        const totalCountData = await totalCountResponse.json();
        setRowCount(totalCountData.length);
        const apiUrl = `${apiBaseUrl}${endpoint}?_page=${paginationModel.page + 1}&_limit=${paginationModel.pageSize}`;
        const paginatedData = await fetchDataFromApi(apiUrl);
        setRows(paginatedData);
      } catch (err) {
        setError(err.message || 'Error fetching data');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [apiBaseUrl, endpoint, paginationModel]);

  const handlePaginationModelChange = (model) => {
    setPaginationModel(model);
  };

  return (
    <div className='w-full bg-white shadow-sm rounded-md'>
      {/* <div className='px-5 py-4 border-b border-[rgba(0,0,0,0.1)] text-[#626262] font-medium text-xl'>{tblHeading} List</div> */}
      <div className='w-full px-5 py-4 border-b border-[rgba(0,0,0,0.1)] text-[#626262] flex justify-between items-center flex-wrap'>
        { <h2 className='font-bold text-xl order-1 mb-5 md:mb-1'>{isHead && `${type}`}</h2>}
{      isAdd &&  <div className='order-2 md:order-3 mb-5 md:mb-1'>
          <BtnPrimary text={`Add ${type}`} route={redirect}/>
        </div>
        }

        {isHeaderAction && 
        <div className='flex gap-2 order-3 w-full md:w-auto md:order-2'>
        <BtnPrimary text={`Copy`} action={()=>{copyArrayToText(rows)}}/>
        <BtnPrimary text={`Excel`} action={()=>{exportArrayToExcel(rows,"roles")}}/>
        <BtnPrimary text={`PDF`} action={()=>{exportArrayToPDF(rows,"roles")}}/>
        <BtnPrimary text={`Print`} action={()=>{printTable(rows)}}/>
        <BtnPrimary text={`CSV`} action={()=>{exportArrayToCSV(rows,"roles")}}/>
        </div>
        }
      </div>
      <div className='p-5'>
      {error && <p>Error: {error}</p>}
      <ThemeProvider theme={theme}>
      <DataGrid
        rows={rows}
        columns={columns}
        rowCount={rowCount}
        loading={isLoading}
        pageSizeOptions={[5, 10, 25, 50]}
        paginationModel={paginationModel}
        paginationMode="server"
        onPaginationModelChange={handlePaginationModelChange}
        disableSelectionOnClick
        pagination

      />
      </ThemeProvider>
      </div>
    </div>
  );
};

export default DataTable;
