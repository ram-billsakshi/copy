import { useLocation, useNavigate } from 'react-router-dom';
import { Link as Alink, scroller } from 'react-scroll';
import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import useCheckAuth from "../../hooks/useCheckAuth"
import billsakshiLogo from "../../images/billsakshi/billsakshiLogo.svg"
import { IoIosMenu } from "react-icons/io";
import { FaPhoneAlt } from "react-icons/fa";
import { MdContactSupport } from "react-icons/md";
import { IoClose } from "react-icons/io5";
import { useDispatch, useSelector } from 'react-redux';
import { setPage } from '../../redux/pageSlice';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false)
  const [active, setActive] = useState(0)

  const isAuthenticated = useCheckAuth()
  const location = useLocation();
  const [isScrolled, setIsScrolled] = useState(false)
  const {page} = useSelector(state => state.page)
  const navigate = useNavigate()
  const dispatch = useDispatch()

  const handleMenuClick = (page) => {
    navigate("/")
    dispatch(setPage(page))
  }

  const handleMobileMenu = () => {
    setMenuOpen(!menuOpen)
  }
  const handleScroll = () => {
    const offset = window.scrollY;
    if (offset > 200) {
      setIsScrolled(true)
    } else {
      setIsScrolled(false)
    }
    setMenuOpen(false)
    setActive(window.scrollY);
  }


  useEffect(() => {
    window.addEventListener('scroll', handleScroll)

    return () => {
      window.removeEventListener('scroll', handleScroll)
    }
  }, [])



  useEffect(() => {
    scroller.scrollTo(page, {
      duration: 800,
      delay: 0,
      smooth: 'easeInOutQuart',
    });
    console.log(page);
  }, [page]);

  const MenuIcon = menuOpen ? IoClose : IoIosMenu


  return (
    <>

      <div className={`h-[40px] text-white text-sm bg-[#092FF1] transition-all duration-500 fixed top-0 right-0 left-0 flex items-center ${location.pathname !== '/' && 'hidden'}`}>
        <div className='w-full flex justify-between max-w-[80%] m-auto'>
          <span className='flex gap-2 items-center'><MdContactSupport size={20} />support@billsakshi.in</span>
          <span className='flex gap-2 items-center'><FaPhoneAlt />Call us now +91 8000611500</span>
        </div>
      </div>

      <header id='header' className={`flxed text-center transition-all duration-500 ${location.pathname === '/' ? 'top-[40px]' : 'top-[0]'} sticky flex w-full bg-white drop-shadow-1 dark:bg-boxdark dark:drop-shadow-none fixed-top ${isScrolled ? 'header-scrolled' : ''}`}>
        <div className="flex justify-center shadow-2 w-full">
          <div className='flex items-center justify-between w-full px-5 py-3  lg:w-[80%] lg:px-1'>


            <div className="w-12">
              <Link to={'/'}><img src={billsakshiLogo} alt="billsakshiLogo" /></Link>
            </div>

            <div className="flex items-center">

              <>

                <ul className={`flex items-center gap-2 2xsm:gap-4 text-[#626262] text-md font-medium hidden lg:flex`}>    
                  <li className={`cursor-pointer hover:text-[#f90e8f] ${active >= 0 && active < 794 && 'text-[#f90e8f]'}`} onClick={()=>{handleMenuClick("home")}}>Home</li>
                  <li className={`cursor-pointer hover:text-[#f90e8f] ${active >= 794 && active < 2209 && 'text-[#f90e8f]'}`} onClick={()=>{handleMenuClick("about")}}>About</li>
                  <li className={`cursor-pointer hover:text-[#f90e8f] ${active >= 2209 && active < 3003 && 'text-[#f90e8f]'}`} onClick={()=>{handleMenuClick("features")}}>Features</li>
                  <li className={`cursor-pointer hover:text-[#f90e8f] ${active >= 3003 && active < 3797 && 'text-[#f90e8f]'}`} onClick={()=>{handleMenuClick("pricing")}}>Pricing</li>
                  <li className={`cursor-pointer hover:text-[#f90e8f] ${active >= 3797 && 'text-[#f90e8f]'}`} onClick={()=>{handleMenuClick("contact")}}>Contact</li>
                </ul>
                <Link to={isAuthenticated ? '/dashboard' : '/login'}
                  className="w-full cursor-pointer rounded-md  bg-[#092FF1] ml-8 mr-2 lg:mr-0 px-6 py-2 text-white transition hover:bg-opacity-90"
                >{isAuthenticated ? 'Dashboard' : 'Login'}</Link>
                <div onClick={handleMobileMenu}><MenuIcon color='#626262' className='cursor-pointer  lg:hidden' size={30} /></div>
              </>
            </div>
          </div>
        </div>
      </header>
      <div className={`fixed ${isScrolled ? 'top-22' : 'top-32'} left-0 w-[100vw] transition-all duration-500 shadow-xl ${menuOpen ? 'opacity-100' : 'opacity-0'}`} style={{ background: "white", height: menuOpen ? '240px' : '0' }}>
        <div className={`flex justify-between pr-3`}>
          <div className='h-[240px] flex items-center'>
          <ul className={`flex flex-col gap-2 2xsm:gap-4 text-md font-medium text-[#626262]`}>
            {/* <DarkModeSwitcher /> */}
            <li className={`cursor-pointer mx-4 hover:text-[#f90e8f] ${active >= 0 && active < 794 && 'text-[#f90e8f]'}`}>Home</li>
              <li className={`cursor-pointer mx-4 hover:text-[#f90e8f] ${active >= 794 && active < 2209 && 'text-[#f90e8f]'}`}>About</li>
            
              <li className={`cursor-pointer mx-4 hover:text-[#f90e8f] ${active >= 2209 && active < 3003 && 'text-[#f90e8f]'}`}>Features</li>
            
              <li className={`cursor-pointer mx-4 hover:text-[#f90e8f] ${active >= 3003 && active < 3797 && 'text-[#f90e8f]'}`}>Pricing</li>
            
              <li className={`cursor-pointer mx-4 hover:text-[#f90e8f] ${active >= 3797 && 'text-[#f90e8f]'}`}>Contact</li>
            

          </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export default Header;
