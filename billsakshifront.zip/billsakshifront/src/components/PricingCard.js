import React from 'react'
import { useDispatch } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { setCurrent } from '../redux/subscriptionSlice'

const PricingCard = ({price,gst,time,desc,clickType}) => {
    const dispatch = useDispatch()
    const navigate = useNavigate()
    return (
        <div className='h w-full bg-white shadow-lg  transition-transform duration-300 hover:scale-105 group rounded-xl text-center'>
            <div className='w-full bg-[#f5f5f9] text-[#092ff1] text-center p-5 rounded-b-[50%] rounded-t-xl group-hover:bg-[#092ff1] group-hover:text-white'>
                <h1 className='text-5xl font-bold'>{price}</h1>
                <h3 className='text-[#cad0de] text-xl font-bold mt-2 group-hover:text-white'>{gst}</h3>
            </div>
            <div className='w-full py-5 pb-10'>
            <h2 className='font-bold text-4xl text-[#f91f97] pb-3 text-center'>{time}</h2>
            <ul className='text-center'>
                {desc.map((text,index) => <li className='text-[#444444] mt-2' key={index}>{text}</li>)}
            </ul>
            <button className='px-10 py-3 text-white bg-[#f91f97] rounded-full mt-10' onClick={()=>{
                dispatch(setCurrent(clickType))
                navigate("/register")
            }}>VIEW DETAILS</button>

            </div>
        </div >
    )
}

export default PricingCard