import React, {useState} from 'react';

const RenewPopup = ({ setPopup }) => {
    const [inputValue, setInputValue] = useState('')
    const [selectedOption, setSelectedOption] = useState('')
    const handleOptionChange = (event) => {
        const optionValue = event.target.value;
        console.log(optionValue)
        setSelectedOption(optionValue);
        switch (optionValue) {
        case '1 year - ₹2999':
            setInputValue('3538.82'); 
            break;
        case '2 year - ₹4999':
            setInputValue('5898.82'); 
            break;
        case '3 year - ₹7299':
            setInputValue('8612.82');
            break;
        default:
            setInputValue('');
        }
    }
  return (
    <div className="fixed inset-0 flex items-center justify-center z-50">
      <div className="bg-black bg-opacity-50 absolute inset-0" onClick={() => setPopup(false)}></div>
      <div className="bg-white rounded-lg shadow-lg p-6 relative z-10 w-full max-w-lg">
        <button
          className="absolute top-2 right-2 text-gray-500 hover:text-gray-700 text-3xl"
          onClick={() => setPopup(false)}
        >
            &times;
        </button>
        <h2 className="text-xl font-semibold mb-4">Renew <span className="font-normal">[GST - 18% (Excluding)]</span></h2>
        <div className="space-y-4">
          <label className="block">
            <input type="radio" name="renewal" className="mr-2" value="1 year - ₹2999" checked={selectedOption === '1 year - ₹2999'} onChange={handleOptionChange} /> 1 year - ₹2999
          </label>
          <label className="block">
            <input type="radio" name="renewal" className="mr-2" value="2 year - ₹4999" checked={selectedOption === '2 year - ₹4999'} onChange={handleOptionChange} /> 2 year - ₹4999
          </label>
          <label className="block">
            <input type="radio" name="renewal" className="mr-2" value="3 year - ₹7299" checked={selectedOption === '3 year - ₹7999'} onChange={handleOptionChange} /> 3 year - ₹7299
          </label>
          <input
            type="text"
            value={inputValue}
            className="block w-full p-2 border rounded"
            readOnly
          />
          <button className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Pay Now</button>
        </div>
      </div>
    </div>
  );
};

export default RenewPopup;
