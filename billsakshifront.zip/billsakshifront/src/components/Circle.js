import React from 'react'

const Circle = ({Icon}) => {
  return (
    <div className='w-9 h-9 rounded-full bg-[#FA4FAB] flex items-center justify-center'>{<Icon/>}</div>
  )
}

export default Circle