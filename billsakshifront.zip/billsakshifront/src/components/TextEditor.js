import React, { useEffect, useState } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import PropTypes from 'prop-types';
import './TextEditor.css'; // Assuming you have the provided CSS in Editor.css

const Editor = ({ html}) => {
  console.log('html', html)
  const [editorHtml, setEditorHtml] = useState(html);
  console.log('editor ',editorHtml)

  const handleChange = (html) => {
    setEditorHtml(html);
  };

  return (
    <div className="app">
      <ReactQuill
        theme="snow"  
        onChange={handleChange}
        value={editorHtml}
        modules={Editor.modules}
        formats={Editor.formats}
        bounds={'.app'}
      />
    </div>
  );
};

// Quill modules to attach to editor
Editor.modules = {
  toolbar: [
    [{ 'header': '1'}, {'header': '2'}, { 'font': [] }],
    [{ size: [] }],
    ['bold', 'italic', 'underline', 'strike', 'blockquote'],
    [{ 'list': 'ordered' }, { 'list': 'bullet' }, { 'indent': '-1' }, { 'indent': '+1' }],
    ['link', 'image', 'video'],
    ['clean'] // remove formatting button
  ],
  clipboard: {
    matchVisual: false,
  },
};

// Quill editor formats
Editor.formats = [
  'header', 'font', 'size',
  'bold', 'italic', 'underline', 'strike', 'blockquote',
  'list', 'bullet', 'indent',
  'link', 'image', 'video'
];

Editor.propTypes = {
  placeholder: PropTypes.string,
};

export default Editor;

// Usage Example
// ReactDOM.render(<Editor placeholder={'Write something...'} />, document.querySelector('.app'));
