import React from 'react'

const MapOne = () => {
  return (
    <div>MapOne</div>
  )
}

export default MapOne