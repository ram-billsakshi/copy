import React from 'react';


const Popup = ({ isOpen, setIsOpen, handleSubmit, heading='Update Password',submitText='Update',children}) => {
  return (
    <div
      className={`w-full h-screen bg-[rgba(0,0,0,0.5)] flex justify-center fixed top-0 left-0 z-20 transition-all duration-300 ${!isOpen ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}
      onClick={() => setIsOpen(false)}
    >
      <form
        onSubmit={handleSubmit}
        className={`w-full max-w-[480px] h-min mt-5 rounded-md overflow-hidden shadow-md bg-white transition-all duration-300 transform ${isOpen ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0'}`}
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className='text-lg p-5 border-b border-[rgba(0,0,0,0.1)]'>{heading}</h2>
          <>{children}</>
        <div className='border-t border-[rgba(0,0,0,0.1)] flex flex-row-reverse gap-2 p-5'>
          <button type='button' className='px-5 py-1.5 border border-[rgba(0,0,0,0.2)] rounded-[4px]' onClick={() => setIsOpen(false)}>Close</button>
          <button type='submit' className='px-4 py-1.5 bg-[#28a745] rounded-[4px] text-white'>{submitText}</button>
        </div>
      </form>
    </div>
  );
};

export default Popup;
