import { MdDashboard } from "react-icons/md";
import { IoSettingsSharp } from "react-icons/io5";
import { RiAdminFill } from "react-icons/ri";
import { FaBuilding } from "react-icons/fa";
import { FaUsers } from "react-icons/fa";
import { FaSitemap } from "react-icons/fa";
import { FaList } from "react-icons/fa";
import { FaBalanceScale } from "react-icons/fa";
import { FaFileInvoice } from "react-icons/fa";
import { FaRupeeSign } from "react-icons/fa";
import { FaBook } from "react-icons/fa";
import { IoLockClosed } from "react-icons/io5";

const sidebarData = [
  {
    icon: <MdDashboard className="text-xl" />,
    text: "Dashboard",
    route: "/dashboard",
  },
  {
    icon: <IoSettingsSharp className="text-xl" />,
    text: "Setting",
    isDropDown: true,
    data : [{text: "Permission",route: "/permission"}]
  },
  {
    icon: <RiAdminFill className="text-xl" />,
    text: "Administrator",
    isDropDown: true,
    data: [
      {
        text: "Role",
        route: "/role/list"
      },
      {
        text: "User",
        route: "/user/list"
      },
      {
        text: "My Subscription",
        route: "/my-subscription/list"
      },
      {
        text: "My Transaction",
        route: "/my-transaction/list"
      },
      {
        text: "Term & Condition",
        route: "/term-condition/list"
      },
      {
        text: "Wallet Payments",
        route: "/wallet/list"
      },
    ],
  },
  {
    icon: <FaBuilding className="text-xl" />,
    text: "Company",
    route: "/company/list"
  },
  {
    icon: <FaUsers className="text-xl" />,
    text: "Party",
    route: "/vendor/list"
  },
  {
    icon: <FaSitemap className="text-xl" />,
    text: "Master",
    isDropDown: true,
    data: [
      {
        text: "GST",
        route: "/gst/list"
      },
      {
        text: "Unit",
        route: "/unit/list"
      },
      {
        text: "Payment Settings",
        route: "/payment"
      },
    ],
  },
  {
    icon: <FaList className="text-xl" />,
    text: "Product Listing",
    isDropDown: true,
    data: [
      {
        text: "Category",
        route: "/category/list"
      },
      {
        text: "SUb Category",
        route: "/sub-category/list"
      },
      {
        text: "Product",
        route: "/product/list"
      },
    ],
  },
  {
    icon: <FaBalanceScale className="text-xl" />,
    text: "Purchase",
    isDropDown: true,
    data: [
      {
        text: "Purchase Invoice",
        route: "/purchase-invoice/list" 
      },
      // {
      //   text: "Account Payble",
      //   route: "/account-payble/list"
      // },
      // {
      //   text: "Purchase Issued",
      //   route: "/purchase-issued/list"
      // },
      // {
      //   text: "Purchase return",
      //   route: "/purchase-return/list"
      // },
    ],
  },
  {
    icon: <FaFileInvoice className="text-xl" />,
    text: "Sales",
    isDropDown: true,
    data: [
      {
        text: "Customers",
        route: "/customer/list"
      },
      {
        text: "Estimate",
        route: "/estimate/list"
      },
      {
        text: "Invoice",
        route: "/invoice/list"
      },
      // {
      //   text: "Payment Recieved",
      //   route: "/payment-recieved/list"
      // },
      // {
      //   text: "Dues Payment",
      //   route: "/dues-payment/list"
      // },
      // {
      //   text: "Return",
      //   route: "/return/list"
      // },
    ],
  },
  {
    icon: <FaRupeeSign className="text-xl" />,
    text: "Expenses",
    isDropDown: true,
    data: [
      {
        text: "Expense Category",
        route: "/expensesCategoryList"
      },
      {
        text: "Expense Details",
        route: "/expensesDetailsList"
      },
    ],
  },
  {
    icon: <FaBook className="text-xl" />,
    text: "Reports",
    isDropDown: true,
    data: [
      {
        text: "Sales Report",
        route: "/sales/list",
      },
      {
        text: "Purchase Report",
        route: "/purchase/list",
      },
      {
        text: "Recievable Report",
        route: "/recievable",
      },
      {
        text: "Payable Report",
        route: "/payable",
      },
      {
        text: "Credits",
        route: "/credits",
      },
      {
        text: "Debits",
        route: "/debits",
      },
    ],
  },
  {
    icon: <IoLockClosed className="text-xl" />,
    text: "Change Password",
    route: "/changePassword",
  },
];

const subscriptionData = {
  trial : {
    time: "7 Days",
    features: [
      "7 Days Free Access",
      "Generate GST Invoices",
      "Inventory & Stock Management",
      "Manage Account Payables",
      "Manage Account Receivables",
      "Collect Payments Faster",
      "Track and Manage Business Reports",
      "Customer Support",
    ],
    price: 0,
    gst: "Excluding",
  },
  oneyear :{
    time: "1 Year",
    features: [
      "365 Days Access",
      "Billed Quarterly For First Billing",
      "Generate GST Invoices",
      "Inventory & Stock Management",
      "Manage Account Payables",
      "Manage Account Receivables",
      "Collect Payments Faster",
      "Track and Manage Business Reports",
      "Customer Support"
    ],
    price: 2999,
    gst: "Including",
  },
  twoyear : {
    time: "2 Years",
    features: [
      "730 Days Access",
      "Generate GST Invoices",
      "Inventory & Stock Management",
      "Manage Account Payables",
      "Manage Account Receivables",
      "Collect Payments Faster",
      "Track and Manage Business Reports",
      "Customer Support",
    ],
    price: 4999,
    gst: "Excluding",
  },
  threeyear : {
    time: "3 Years",
    features: [
      "1095 Days Access",
      "Generate GST Invoices",
      "Inventory & Stock Management",
      "Manage Account Payables",
      "Manage Account Receivables",
      "Collect Payments Faster",
      "Track and Manage Business Reports",
      "Customer Support",
    ],
    price: 7299,
    gst: "Excluding",
  },
}
const cardData = [
  { title: "Total sales", total: "5.456K", rate: "0.43%", levelUp: true, totalIcon: <FaRupeeSign /> },
  { title: "Sales Dues", total: "3.456K", rate: "0.55%", levelUp: false, totalIcon: <FaRupeeSign /> },
  { title: "Sales Paid", total: "8.456K", rate: "0.98%", levelUp: true, totalIcon: <FaRupeeSign /> },
  { title: "Return Sales", total: "10.456K", rate: "0.67%", levelUp: false, totalIcon: <FaRupeeSign /> },
  { title: "Total vendors", total: "456", rate: "0.12%", levelUp: true, totalIcon: null },
  { title: "Total Customers", total: "356", rate: "0.78%", levelUp: false, totalIcon: null },
  { title: "Total purchase", total: "13.456K", rate: "0.19%", levelUp: true, totalIcon: <FaRupeeSign /> },
  { title: "Purchase dues", total: "3.456K", rate: "0.99%", levelUp: true, totalIcon: <FaRupeeSign /> },
  { title: "Purchase paid", total: "4.456K", rate: "0.15%", levelUp: true, totalIcon: <FaRupeeSign /> },
  { title: "Return purchase", total: "31.456K", rate: "0.83%", levelUp: true, totalIcon: <FaRupeeSign /> },
  { title: "Total active items", total: "345", rate: "0.44%", levelUp: false, totalIcon: null },
  { title: "Total expenses", total: "7.456K", rate: "0.49%", levelUp: true, totalIcon: <FaRupeeSign /> },
];
const salesData = {
  daily: [
    { date: "2023-06-01", total: 25 },
    { date: "2023-06-02", total: 45 },
    { date: "2023-06-03", total: 35 },
    { date: "2023-06-04", total: 50 },
    { date: "2023-06-05", total: 55 },
    { date: "2023-06-06", total: 65 },
    { date: "2023-06-07", total: 75 },
    { date: "2023-06-08", total: 60 },
    { date: "2023-06-09", total: 70 },
    { date: "2023-06-10", total: 40 },
    { date: "2023-06-11", total: 30 },
    { date: "2023-06-12", total: 80 },
    { date: "2023-06-13", total: 50 },
    { date: "2023-06-14", total: 55 },
  ],
  weekly: [
    { week: "2023-W23", total: 220 },
    { week: "2023-W24", total: 310 },
    { week: "2023-W25", total: 270 },
    { week: "2023-W26", total: 350 },
    { week: "2023-W27", total: 330 },
    { week: "2023-W28", total: 300 },
    { week: "2023-W29", total: 280 },
    { week: "2023-W30", total: 320 },
  ],
  monthly: [
    { month: "2023-01", total: 850 },
    { month: "2023-02", total: 650 },
    { month: "2023-03", total: 1050 },
    { month: "2023-04", total: 950 },
    { month: "2023-05", total: 1450 },
    { month: "2023-06", total: 1650 },
    { month: "2023-07", total: 1250 },
    { month: "2023-08", total: 1150 },
    { month: "2023-09", total: 1050 },
    { month: "2023-10", total: 950 },
    { month: "2023-11", total: 850 },
    { month: "2023-12", total: 1350 },
  ],
  yearly: [
    { year: "2019", total: 10500 },
    { year: "2020", total: 12500 },
    { year: "2021", total: 14500 },
    { year: "2022", total: 16500 },
    { year: "2023", total: 18500 },
  ]
};


const options = {
  // legend: {
  //   show: false,
  //   position: "top",
  //   horizontalAlign: "left",
  // },
  // colors: ["#3C50E0", "#80CAEE"],
  // chart: {
  //   fontFamily: "Satoshi, sans-serif",
  //   height: 335,
  //   type: "area",
  //   dropShadow: {
  //     enabled: true,
  //     color: "#623CEA14",
  //     top: 10,
  //     blur: 4,
  //     left: 0,
  //     opacity: 0.1,
  //   },

  //   toolbar: {
  //     show: false,
  //   },
  // },
  // responsive: [
  //   {
  //     breakpoint: 1024,
  //     options: {
  //       chart: {
  //         height: 300,
  //       },
  //     },
  //   },
  //   {
  //     breakpoint: 1366,
  //     options: {
  //       chart: {
  //         height: 350,
  //       },
  //     },
  //   },
  // ],
  // stroke: {
  //   width: [2, 2],
  //   curve: "straight",
  // },

  // grid: {
  //   xaxis: {
  //     lines: {
  //       show: true,
  //     },
  //   },
  //   yaxis: {
  //     lines: {
  //       show: true,
  //     },
  //   },
  // },
  // dataLabels: {
  //   enabled: false,
  // },
  // markers: {
  //   size: 4,
  //   colors: "#fff",
  //   strokeColors: ["#3056D3", "#80CAEE"],
  //   strokeWidth: 3,
  //   strokeOpacity: 0.9,
  //   strokeDashArray: 0,
  //   fillOpacity: 1,
  //   discrete: [],
  //   hover: {
  //     size: undefined,
  //     sizeOffset: 5,
  //   },
  // },
  xaxis: {
    type: "category",
    categories: [
      "Sep",
      "Oct",
      "Nov",
      "Dec",
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
    ],
    axisBorder: {
      show: false,
    },
    axisTicks: {
      show: false,
    },
  },
  yaxis: {
    title: {
      style: {
        fontSize: "0px",
      },
    },
    min: 0,
    max: 100,
  },
};


export  {sidebarData,subscriptionData,cardData,salesData};
