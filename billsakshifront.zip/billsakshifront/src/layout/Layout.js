import { useState } from 'react';
import Header from '../components/Header/index';
import Sidebar from '../components/Sidebar/index';
import { Outlet, useLocation } from 'react-router-dom';
import AuthHeader from '../components/AuthHeader';
import Home from '../pages/Home';

const Layout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation()

  return (
    <div className="dark:bg-boxdark-2 dark:text-bodydark">
      {location.pathname === "/" ? <Home/> :<div className="flex h-screen overflow-hidden">
        <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen}  />
        <div id='main' className="relative flex flex-1 flex-col overflow-y-auto overflow-x-hidden">
          <AuthHeader sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen}/>
          <main >
            <div className="mx-auto py-5 px-7">
              <Outlet/>
            </div>
          </main>
        </div>
      </div>}
    </div>
  );
};

export default Layout;
