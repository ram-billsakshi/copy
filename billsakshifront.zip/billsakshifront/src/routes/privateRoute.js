// routes/privateRoute.js
import React from "react";
import { Navigate } from "react-router-dom";
import Layout from "../layout/Layout";
import Dashboard from "../pages/Dashboard";
import Setting from "../pages/Setting";
import PermissionList from "../pages/PermissionList";
import Rolelist from "../pages/Rolelist";
import RoleAdd from "../pages/RoleAdd";
import UserAdd from '../pages/UserAdd';
import UserList from '../pages/UserList';
import SubscriptionList from '../pages/SubscriptionList';
import TransactionList from '../pages/TransactionList';
import WalletList from '../pages/WalletList';
import CompanyList from '../pages/CompanyList';
import VendorList from '../pages/VendorList';
import VendorAdd from '../pages/VendorAdd';
import GstAdd from '../pages/GstAdd';
import GstList from '../pages/GstList';
import UnitAdd from '../pages/UnitAdd';
import UnitList from '../pages/UnitList';
import ProductCategoryAdd from '../pages/ProductCategoryAdd';
import ProductCategoryList from '../pages/ProductCategoryList';
import ProductSubCategoryAdd from '../pages/ProductSubCategory';
import ProductSubCategoryList from '../pages/ProductSubCategoryList';
import ProductAdd from '../pages/ProductAdd';
import BulkAdd from '../pages/BulkAdd';
import ProductList from '../pages/ProductList';
import SalesCustomerAdd from "../pages/SalesCustomerAdd";
import CreditReport from "../pages/CreditReport";
import DebitReport from "../pages/Debits";
import PayableReport from "../pages/Payable";
import RecievableReport from "../pages/RecievableReport";
import ExpensesCategoryAdd from "../pages/ExpensesCategoryAdd";
import ExpenseCategoryList from "../pages/ExpensesCategoryList";
import ExpensesDetailsList from "../pages/ExpensesDetailsList";
import ExpensesDetailsAdd from "../pages/ExpensesDetailsAdd";
import SalesCustomerList from "../pages/SalesCustomerList";
import EstimateAdd from "../pages/EstimateAdd";
import InvoiceAdd from "../pages/InvoiceAdd";
import SalesReport from "../pages/SalesReport";
import ChangePassword from "../pages/ChangePassword";
import LoginPage from "../pages/Login2";
import EstimateList from "../pages/EstimateList";
import InvoiceList from "../pages/InvoiceList";
import PaymentOptions from "../pages/Payment";
import PurchaseReport from "../pages/PurchaseReport";
import TermConditionList from "../pages/TermConditionList";
import TermConditionAdd from "../pages/TermConditionAdd";
import EditPermission from "../pages/EditPermission";
import PurchaseInvoiceList from "../PurchaseInvoiceList";
import PurchaseInvoice from "../PurchaseInvoice";
import CompanyAdd from "../pages/CompanyAdd";
import EstimateView from "../pages/EstimateView";
import InvoiceView from "../pages/InvoiceView";
import CompanyInfoView from "../components/View/CompanyInfoView";
import CompanyView from "../pages/CompanyView";

const privateRoute = () => ({
  path: "",
  element: <Layout />,
  children: [
    { path: "/dashboard", element: <Dashboard /> },
    { path: "/settings", element: <Setting /> },
    { path: "/permission", element: <PermissionList /> },
    { path: "/permission/edit", element: <EditPermission/> },
    { path: "/role/list", element: <Rolelist /> },
    { path: "/role/add", element: <RoleAdd /> },
    { path: "/user/list", element: <UserList/> },
    { path: "/term-condition/list", element: <TermConditionList/> },
    { path: "/term-condition/add", element: <TermConditionAdd/> },
    { path: "/term-condition/edit/:termId", element: <TermConditionAdd/> },
    { path: "/role/add", element: <RoleAdd /> },
    { path: "*", element: <Navigate to="/dashboard" /> },
    { path: "/list", element: <PermissionList/>},
    { path: "/role/list", element: <Rolelist/>},
    { path:"/role/add", element: <RoleAdd/>},
    { path:"/user/add", element: <UserAdd/>},
    {path:"/user/edit/:userId", element: <UserAdd/>},
    { path:"/user/list", element: <UserList/>},
    { path:"/myTransaction/list", element: <TransactionList/>},
    { path:"/wallet/list", element: <WalletList/>},
    { path:"/company/list", element: <CompanyList/>},
    { path:"/vendor/list", element: <VendorList/>},
    { path:"/vendor/add", element: <VendorAdd/>},
    { path:"/vendor/edit/:vendorId", element: <VendorAdd/>},
    { path:"/gst/add", element: <GstAdd/>},
    { path:"/gst/edit/:gstId", element: <GstAdd/>},
    { path:"/gst/list", element: <GstList/>},
    { path:"/unit/list", element: <UnitList/>},
    { path:"/unit/add", element: <UnitAdd/>},
    { path:"/unit/edit/:unitId", element: <UnitAdd/>},
    { path:"/meta_type/add", element: <ProductCategoryAdd/>},
    { path:"/meta_type/list", element: <ProductCategoryList/>},
    { path:"/meta_label/add", element: <ProductSubCategoryAdd/>},
    { path:"/meta_label/list", element: <ProductSubCategoryList/>},
    { path:"/meta_label/list", element: <ProductSubCategoryList/>},
    { path:"/listitems/add", element:<ProductAdd/>},
    { path:"/listitems/list", element:<ProductList/>},
    { path:"/bulk/add", element:<BulkAdd/>},
    { path:"/customer/add", element:<SalesCustomerAdd/>},
    { path:"/credits", element:<CreditReport/>},
    { path:"/debits", element:<DebitReport/>},
    { path:"/payable", element:<PayableReport/>},
    { path:"/recievable", element:<RecievableReport/>},
    { path:"/expensesCategoryAdd", element:<ExpensesCategoryAdd/>},
    { path:"/expensesCategoryEdit/:expenseCategoryId", element:<ExpensesCategoryAdd/>},
    { path:"/expensesCategoryList", element:<ExpenseCategoryList/>},
    { path:"/expensesDetailsAdd", element:<ExpensesDetailsAdd/>},
    { path:"/expensesDetailsEdit/:expenseDetailsId", element:<ExpensesDetailsAdd/>},
    { path:"/expensesDetailsList", element:<ExpensesDetailsList/>},
    { path:"/salesCustomerList", element:<SalesCustomerList/>},
    { path:"/estimate/add", element:<EstimateAdd/>},
    { path:"/estimate/list", element:<EstimateList/>},
    { path:"/estimate/view", element:<EstimateView/>},
    { path:"/invoice/add", element:<InvoiceAdd/>},
    { path:"/invoice/list", element:<InvoiceList/>},
    { path:"/invoice/view", element:<InvoiceView/>},
    { path: "/sales/list", element: <SalesReport/>},
    { path: "/purchase/list", element: <PurchaseReport/>},
    { path:"/changePassword", element: <ChangePassword/>},
    {path: "/role/list", element: <Rolelist/>},
    {path:"/role/add", element: <RoleAdd/>},
    {path:"/role/edit/:roleId", element: <RoleAdd/>},
    {path:"/user/add", element: <UserAdd/>},
    {path:"/user/list", element: <UserList/>},
    {path:"/my-subscription/list", element: <SubscriptionList/>},
    {path:"/my-transaction/list", element: <TransactionList/>},
    {path:"/wallet/list", element: <WalletList/>},
    {path:"/company/list", element: <CompanyList/>},
    {path:"/vendor/list", element: <VendorList/>},
    {path:"/vendor/add", element: <VendorAdd/>},
    {path:"/gst/add", element: <GstAdd/>},
    {path:"/gst/list", element: <GstList/>},
    {path:"/unit/list", element: <UnitList/>},
    {path:"/unit/add", element: <UnitAdd/>},
    {path:"/category/add", element: <ProductCategoryAdd/>},
    {path:"/category/edit/:prodCategId", element: <ProductCategoryAdd/>},
    {path:"/category/list", element: <ProductCategoryList/>},
    {path:"/sub-category/add", element: <ProductSubCategoryAdd/>},
    {path:"/sub-category/edit/:subCategId", element: <ProductSubCategoryAdd/>},
    {path:"/sub-category/list", element: <ProductSubCategoryList/>},
    {path:"/product/add", element:<ProductAdd/>},
    {path:"/product/edit/:productId", element:<ProductAdd/>},
    {path:"/product/list", element:<ProductList/>},
    {path:"/bulk/add", element:<BulkAdd/>},
    {path:"/loginNew", element: <LoginPage/>},
    {path:"/customer/add", element:<SalesCustomerAdd/>},
    {path:"/customer/edit/:salesCustomerEdit", element:<SalesCustomerAdd/>},
    {path:"/customer/list", element:<SalesCustomerList/>},
    {path:"/payment", element:<PaymentOptions/>},
    {path:"/purchase-invoice/list", element:<PurchaseInvoiceList/>},
    {path:"/purchase-invoice/add", element:<PurchaseInvoice/>},
    {path:"/purchase-invoice/edit/:invoiceId", element:<PurchaseInvoice/>},

    {path:"/company/add", element:<CompanyAdd/>},
    {path:"/company/edit/:companyId", element:<CompanyAdd/>},
    {path:"/company/view", element:<CompanyView/>}
  ],
});

export default privateRoute;
