// routes/publicRoute.js
import React from 'react';
import { Navigate } from 'react-router-dom';
import Login from '../pages/Login';
import Home from '../pages/Home';
import Register from '../pages/Register';
import LoginPage from '../pages/Login2';
import PaymentSuccess from '../pages/PaymentSuccess';

const publicRoute = (isAUthenticated) => [
  { path: "/", element: <Home /> },
  { path: "/home", element: <Home /> },
  { path: "/login", element: isAUthenticated ?<Navigate to={'/dashboard'}/> : <LoginPage /> },
  { path: "/register", element: <Register /> },
  { path: "/payments/pay", element: <PaymentSuccess/> },
  { path: "*", element: <Navigate to="/" /> },

];

export default publicRoute;
