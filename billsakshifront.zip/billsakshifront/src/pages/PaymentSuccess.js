import React from "react";
import Header from "../components/Header";
import { MdVerified } from "react-icons/md";

const data = [
    { label: "Subscription Name", "value": "Trial" },
    { label: "Order Id", "value": "I8S8Os2rYR5o243" },
    { label: "Transaction Id", "value": "I8S8Os2rYR5o243" },
    { label: "Amount", "value": "0.00" },
    { label: "Phone", "value": "7320863504" },
    { label: "Email", "value": "ram@billsakshi.com" },
    { label: "Payment Date", "value": "14-Jun-2024 15:11 pm" },
    { label: "Duration", "value": "7 / Days" },
    { label: "Expiry On", "value": "21-Jun-2024" }
  ]
  

const PaymentSuccess = () => {
  return (
    <div className="bg-white">
      <Header />
      <div className="w-[95%] border border-[rgba(0,0,0,0.1)] lg:max-w-[900px] m-auto mt-10 rounded-md flex flex-col gap-4 items-center m-auto">
        <div className="w-full p-5 bg-[#198754] flex justify-center items-center rounded-md">
          <MdVerified size={50} color="white" />
        </div>
        <h1 className="text-4xl font-bold text-[#4154f1]">RAM</h1>
        <h2 className="text-2xl font-semibold text-[rgba(0,0,0,0.7)]">Your transaction Success !</h2>
        <p className="text-center px-3"><span className="font-semibold">Note : -</span> Your login details has been sent on given email id. Please check now.</p>
        <div className=" w-[90%] border border-[rgba(0,0,0,0.2)] mx-auto mt-2">
            {data.map(row => {
                return (
                <div className="w-full border-b border-[rgba(0,0,0,0.2)] flex text-sm md:text-lg">
                    <span className="w-[40%] grow p-2 md:p-2.5">{row.label}</span>
                    <span className="w-10 border-x border-[rgba(0,0,0,0.2)] text-center p-2 md:p-2.5">:</span>
                    <span className="w-[40%] grow p-2 md:p-2.5">{row.value}</span>
                </div>
                )
            })}

        </div>
        <p className="mt-2 mb-4 text-center px-3">*This is a computer generated bill and does not require company stamp & signature.</p>
      </div>
    </div>
  );
};

export default PaymentSuccess;
