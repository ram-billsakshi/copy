import React from 'react'
import DataTable from '../components/DataTable';

const columns = []


const  DebitReport = () => {
    return (
        <div><DataTable columns={columns} endpoint={"/debits"} type={"Payable Report"} isAdd={false}/></div>
      );
}

export default DebitReport