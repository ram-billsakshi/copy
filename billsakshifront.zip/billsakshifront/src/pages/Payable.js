import React from 'react'
import DataTable from '../components/DataTable';

const columns = []


const PayableReport = () => {
    return (
        <div><DataTable columns={columns} endpoint={"/payable"} type={"Payable Report"} isAdd={false}/></div>
      );
}

export default PayableReport