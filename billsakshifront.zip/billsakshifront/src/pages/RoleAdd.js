import React, { useEffect, useState } from 'react';
import InputForm from '../components/InputForm/InputForm';
import PagesHeader from '../components/PagesHeader/PagesHeader';
import { handleChange, stateData } from '../utils';
import { useParams } from 'react-router-dom';
import { useSelector } from 'react-redux';

const rows = [
    {
        name: "roleName",
        label:'Role Name',
        placeholder: 'Enter Role',
        type: "text",
        isRequired: true,
        maxChar: null, 
        readOnly: false,
    },
    {
        name: "roleSlug",
        label: "Role Slug",
        placeholder:'Enter Slug',
        type: "text",
        isRequired: true,
        maxChar: null, 
        readOnly: false
    },
    {
        name: "note",
        label: "Note",
        placeholder:'Note',
        type: "text",
        isRequired: true,
        maxChar: null, 
        readOnly: false
    }
];

function Form() {
    const [data, setData] = useState(stateData(rows));
    const roleEdit = useSelector(state => state?.role?.roleEdit) || JSON.parse(localStorage.role)

    const handleSubmit = (e) => {
        e.preventDefault()
        console.log(data);
    }
    const handleEdit = (e) => {
        e.preventDefault()
        console.log('edit')
    }
    const { roleId } = useParams()

    useEffect(()=>{
        console.log(roleId)
        const data = JSON.parse(localStorage.role)
        if(roleId) {
            setData({
                ...data, 
                roleName: roleEdit?.name, 
                roleSlug: roleEdit?.slug, 
                note: roleEdit?.note
            })
        }
    }, [])



    return (
        <div className='flex-1 shadow-1 bg-white' >
            <PagesHeader navigateTo={"/role/list"} heading={roleId ? "Update" : "Add"} button={"List"} />
            <form onSubmit={handleSubmit} className='p-5'>
                <InputForm rows={rows} onChange={(e)=>handleChange(e,setData)} data={data}/>
                <button type='submit' className='text-white bg-blue-600 px-4 py-2 mx-auto block mb-3'>{roleId ? "Update" : "Add"}</button>
            </form>
        </div>
    );
}

export default Form;
