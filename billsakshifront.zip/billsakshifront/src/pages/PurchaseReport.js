import React from 'react'
import Report from '../components/Report'
import Report2 from '../components/Report2'
import DataTable from '../components/DataTable'

const PurchaseReport = () => { 
    const rows = [
        {
            name: "Customer Wise",
            type:"dropdown",
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "Year",
            type: "date",
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "Group by Data",
            type: "date",
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "From Date",
            type: "date",
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "To Date",
            type: "date",
            isRequired: true,
            maxChar:null, 
            readonly: false
        }
    ]
  return (
    <div className='flex-1 max-h-200 border-2 border-gray shadow-1 m-4 bg-white '>
        <div className="px-4 py-7 border-b border-[rgba(0,0,0,0.2)]">
            {/* <Report rows={rows} heading="Sales Report List" fetchPersons="/getCustomers"/> */}
            <Report2 fetchPersons="/getCustomers" heading="Sales Report List"/>
        </div>
        <div className='mt-10 border-t border-[rgba(0,0,0,0.1)]'>
        <DataTable columns={[]} endpoint={"/purchase-reports"} type={"Purchase Report"} isAdd={false} isHead={false}/>
        </div>
    </div>  
  )
}

export default PurchaseReport