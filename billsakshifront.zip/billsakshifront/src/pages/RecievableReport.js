import React from 'react'
import DataTable from '../components/DataTable';



const RecievableReport = () => {
  const columns = [
    { field: "id", headerName: "Sl No.", width: 80 },
    { field: "customer_name", headerName: "Customer Name", flex: 1, minWidth: 200 },
    { field: "customer_number", headerName: "Customer Number", flex: 1, minWidth: 200 },
    { field: "sales_date", headerName: "Sales Date", flex: 1, minWidth: 200 },
    { field: "total_amount", headerName: "Total Amount", flex: 1, minWidth: 200 },
    { 
      field: "status", 
      headerName: "Status", 
      flex: 1, 
      minWidth: 100,
      renderCell: (params) => (
          <button className={`${params.value?'bg-red-500':'bg-[#3b82f6]'} text-white leading-normal w-[100px] py-2 rounded-md`} onClick={() => alert(params.value)}>{params.value?'Deactivate':'Activate'}</button>
      ),
    }
  ];
    return (
        <div><DataTable columns={columns} endpoint={"/recievable"} type={"Recieveable Report"} isAdd={false}/></div>
      );
}

export default RecievableReport 