import React, { useEffect, useState } from 'react'
import PagesHeader from '../components/PagesHeader/PagesHeader';
import InputFormTwoColumn from '../components/InputForm/InputFormTwoColumn';
import { handleChange, stateData } from '../utils';
import { useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';

const CompanyAdd = () => {
    const [data, setData] = useState({})
    const selectCity = ["---Select City---"]
    const selector = useSelector(state => state?.company?.editCompany) || JSON.parse(localStorage.company)
    const {companyId} = useParams()

    
    const cityObj = {
        'Andhra Pradesh': ['Adoni','Amaravati','Anantapur','Chandragiri','Chittoor',
                            'Dowlaiswaram',
                            'Eluru',
                            'Guntur',
                            'Kadapa',
                            'Kakinada',
                            'Kurnool',
                            'Machilipatnam',
                            'Rajahmundry',
                            'Srikakulam',
                            'Tirupati',
                            'Vijayawada',
                            'Vizianagaram',
                            'Yemmiganur',
                            'Visakhapatnam',
                            'Nagarjunakoṇḍa',],
        'Arunachal Pradesh': ['Itanagar', 'Tawang', 'Ziro', 'Pasighat', 'Bomdila'],
        'Assam': ['Guwahati', 'Silchar', 'Dibrugarh', 'Jorhat', 'Nagaon'],
        'Bihar': ['Patna', 'Gaya', 'Bhagalpur', 'Muzaffarpur', 'Purnia'],
        'Chhattisgarh': ['Raipur', 'Bhilai', 'Bilaspur', 'Korba', 'Durg'],
        'Goa': ['Panaji', 'Margao', 'Vasco da Gama', 'Mapusa', 'Ponda'],
        'Gujarat': ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Bhavnagar'],
        'Haryana': ['Gurgaon', 'Faridabad', 'Panipat', 'Ambala', 'Hisar'],
        'Himachal Pradesh': ['Shimla', 'Dharamshala', 'Manali', 'Mandi', 'Solan'],
        'Jharkhand': ['Ranchi', 'Jamshedpur', 'Dhanbad', 'Bokaro Steel City', 'Hazaribagh'],
        'Karnataka': ['Bangalore', 'Mysore', 'Mangalore', 'Hubli', 'Belgaum'],
        'Kerala': ['Thiruvananthapuram', 'Kochi', 'Kozhikode', 'Kollam', 'Thrissur'],
        'Madhya Pradesh': ['Bhopal', 'Indore', 'Gwalior', 'Jabalpur', 'Ujjain'],
        'Maharashtra': ['Mumbai', 'Pune', 'Nagpur', 'Nashik', 'Thane'],
        'Manipur': ['Imphal', 'Bishnupur', 'Churachandpur', 'Kakching', 'Ukhrul'],
        'Meghalaya': ['Shillong', 'Tura', 'Nongpoh', 'Cherrapunji', 'Jowai'],
        'Mizoram': ['Aizawl', 'Lunglei', 'Saiha', 'Champhai', 'Serchhip'],
        'Nagaland': ['Kohima', 'Dimapur', 'Mokokchung', 'Tuensang', 'Wokha'],
        'Odisha': ['Bhubaneswar', 'Cuttack', 'Rourkela', 'Sambalpur', 'Berhampur'],
        'Punjab': ['Ludhiana', 'Amritsar', 'Jalandhar', 'Patiala', 'Bathinda'],
        'Rajasthan': ['Jaipur', 'Jodhpur', 'Udaipur', 'Kota', 'Ajmer'],
        'Sikkim': ['Gangtok', 'Namchi', 'Geyzing', 'Mangan', 'Rangpo'],
        'Tamil Nadu': ['Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Salem'],
        'Telangana': ['Hyderabad', 'Warangal', 'Nizamabad', 'Khammam', 'Karimnagar'],
        'Tripura': ['Agartala', 'Dharmanagar', 'Udaipur', 'Kailashahar', 'Belonia'],
        'Uttar Pradesh': ['Lucknow', 'Kanpur', 'Ghaziabad', 'Agra', 'Varanasi'],
        'Uttarakhand': ['Dehradun', 'Haridwar', 'Roorkee', 'Haldwani', 'Rudrapur'],
        'West Bengal': ['Kolkata', 'Howrah', 'Darjeeling', 'Siliguri', 'Durgapur'],
        'Andaman and Nicobar Islands': ['Port Blair', 'Garacharma', 'Rangat', 'Diglipur', 'Mayabunder'],
        'Chandigarh': ['Chandigarh'],
        'Dadra and Nagar Haveli and Daman and Diu': ['Daman', 'Diu', 'Silvassa', 'Amli'],
        'Lakshadweep': ['Kavaratti', 'Agatti', 'Amini', 'Andrott', 'Minicoy'],
        'Delhi': ['New Delhi', 'Old Delhi', 'Dwarka', 'Rohini', 'Saket'],
        'Puducherry': ['Puducherry', 'Karaikal', 'Mahe', 'Yanam'],
        'Jammu and Kashmir': ['Puducherry', 'Karaikal', 'Mahe', 'Yanam']
    }
    const rows = [
        {
            label: "Company Name",
            type: "text",
            isRequired: true,
            placeholder: "Name",
            maxChar: null,
            readOnly: false,
            name: "name"
        },
        {
            label: "Company Logo",
            type: "file",
            isRequired: true,
            placeholder: "Company Logo",
            maxChar: 10,
            readOnly: false,
            name: "clogo"
        },
        {
            label: "Email Id",
            type: "email",
            isRequired: true,
            placeholder: "Email Id",
            maxChar: null,
            readOnly: false,
            name: "email"
        },
        {
            label: "Pan No(Indiviual)",
            type: "text",
            isRequired: true,
            placeholder: "Plan No.",
            maxChar: null,
            readOnly: false,
            name: "pan_individual"
        },
        {
            label: "Pan No(Company)",
            type: "text",
            isRequired: true,
            placeholder: "Plan No.",
            maxChar: null,
            readOnly: false,
            name: "pan_company"
        },
        {
            label: "GST",
            type: "text",
            isRequired: true,
            placeholder: "GST",
            maxChar: null,
            readOnly: false,
            name: "gst"
        },
        {
            label: "CIN",
            type: "text",
            isRequired: true,
            placeholder: "CIN",
            maxChar: null,
            readOnly: false,
            name: "cin"
        },
        {
            label: "TIN",
            type: "text",
            isRequired: true,
            placeholder: "TIN",
            maxChar: null,
            readOnly: false,
            name: "tin"
        },
        {
            label: "Registration Type",
            type: "dropdown",
            isRequired: true,
            placeholder: "Registration Type",
            fields: [
                "Select Registration Type",
                "Udyam Aadhar",
                "Limited Company",
                "Public Limited Company",
                "Private Limited Company",
                "Joint Venture Company",
                "Paternship Firm",
                "Sole Proprietorship"
              ],
            maxChar: null,
            readOnly: false,
            name: "registration_type"
        },
        {
            label: "Registration No",
            type: "text",
            isRequired: true,
            placeholder: "Registration No.",
            maxChar: null,
            readOnly: false,
            name: "registration_number"
        },
        {
            label: "Country",
            type: "dropdown",
            isRequired: true,
            placeholder: "IFSC",
            fields: [
                "---Select Country---",
                "India (+91)",
                "United States (+1)",
                "China (+86)",
                "Indonesia (+62)",
                "Pakistan (+92)",
                "Brazil (+55)",
                "Nigeria (+234)",
                "Bangladesh (+880)",
                "Russia (+7)",
                "Mexico (+52)",
                "Japan (+81)",
                "Philippines (+63)",
                "Vietnam (+84)",
                "Ethiopia (+251)",
                "Egypt (+20)",
                "Germany (+49)",
                "Iran (+98)",
                "Turkey (+90)",
                "Democratic Republic of the Congo (+243)",
                "Thailand (+66)",
                "United Kingdom (+44)",
                "France (+33)",
                "Italy (+39)",
                "South Africa (+27)",
                "Tanzania (+255)",
                "Myanmar (+95)",
                "South Korea (+82)",
                "Colombia (+57)",
                "Kenya (+254)",
                "Spain (+34)",
                "Argentina (+54)",
                "Algeria (+213)",
                "Sudan (+249)",
                "Ukraine (+380)",
                "Uganda (+256)",
                "Iraq (+964)",
                "Poland (+48)",
                "Canada (+1)",
                "Morocco (+212)",
                "Saudi Arabia (+966)",
                "Uzbekistan (+998)",
                "Peru (+51)",
                "Malaysia (+60)",
                "Venezuela (+58)",
                "Nepal (+977)",
                "Ghana (+233)",
                "Yemen (+967)",
                "Afghanistan (+93)",
            ],
            maxChar: null,
            readOnly: false,
            name: "country"
        },
        {
            label: "State",
            type: "dropdown",
            isRequired: true,
            placeholder: "IFSC",
            fields:[
                "----Select State ---",
                "Andhra Pradesh",
                "Arunachal Pradesh",
                "Assam",
                "Bihar",
                "Chhattisgarh",
                "Gujarat",
                "Haryana",
                "Himachal Pradesh",
                "Jammu and Kashmir",
                "Goa",
                "Jharkhand",
                "Karnataka",
                "Kerala",
                "Madhya Pradesh",
                "Maharashtra",
                "Manipur",
                "Meghalaya",
                "Mizoram",
                "Nagaland",
                "Odisha",
                "Punjab",
                "Rajasthan",
                "Sikkim",
                "Tamil Nadu",
                "Telangana",
                "Tripura",
                "Uttarakhand",
                "Uttar Pradesh",
                "West Bengal",
                "Andaman and Nicobar Islands",
                "Chandigarh",
                "Dadra and Nagar Haveli",
                "Daman and Diu",
                "Delhi",
                "Lakshadweep",
                "Puducherry",
            ],
            maxChar: null,
            readOnly: false,
            name: "state"
        },
        {
            label: "City",
            type: "dropdown",
            isRequired: true,
            placeholder: "City",
            fields: data?.state && cityObj[data?.state] ? ["--Select City----",...cityObj[data?.state]] : ["--Select City----"],
            // fields: selectCity.concat(cityObj[data.state]) || selectCity, 
            maxChar: null,
            readOnly: false,
            name: "city"
        },
        {
            label: "Zip Code",
            type: "text",
            isRequired: true,
            placeholder: "Zip Code",
            maxChar: null,
            readOnly: false,
            name: "zip"
        },
        {
            label: "Contact Number",
            type: "text",
            isRequired: true,
            placeholder: "Contact Number",
            maxChar: null,
            readOnly: false,
            name: "contact"
        },
        {
            label: "Barcode Format",
            type: "dropdown",
            isRequired: true,
            placeholder: "Barcode Format",
            fields:["------Select Barcode Format-------", " Numeric", "Alphabetic"],
            maxChar: null,
            readOnly: false,
            name: "barcodeformat"
        },
        {
            label: "Address",
            type: "textArea",
            isRequired: true,
            placeholder: "Address",
            maxChar: null,
            readOnly: false,
            name: "address"
        },
        {
            label: "Description",
            type: "textArea",
            isRequired: true,
            placeholder: "Description",
            maxChar: null,
            readOnly: false,
            name: "description"
        },
        {
            label: "Do you need multiple prices?",
            type: "radio",
            fields: [{ label: "Yes", value: "yes" }, { label: "No", value: "no" }],
            isRequired: true,
            placeholder: "multiplePrices",
            maxChar: null,
            readOnly: false,
            name: "multiplepricingoptions"
        },
        {
            label: "Number of Prices?",
            type: "number",
            isRequired: true,
            placeholder: "Number Of Prices",
            maxChar: null,
            readOnly: data.multiplePrices === "yes" ? false : true,
            name: "noofprices"
        },
        {
            label: "Status",
            type: "radio",
            fields: [{ label: "Active", value: "active" }, { label: "Inactive", value: "inactive" }],
            isRequired: true,
            placeholder: "Status",
            maxChar: null,
            readOnly: false,
            name: "status"
        }
    ];

    useEffect(()=> {
        setData(rows)
        console.log(companyId)
        const data = JSON.parse(localStorage.company)
        console.log(data)
        console.log(selector)   
        if(companyId){
            setData({
                ...data
            })
        }  
    }, [])

    useEffect(()=>{
        Object.keys(cityObj)
    }, [data])


    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(data);
    };

    return (
        <div className='flex-1 shadow-1 bg-white'>
            <PagesHeader navigateTo={"/company/list"} heading={companyId ? "Company Update" : "Company Add"} button={"List"} />
            <form className='p-5' onSubmit={handleSubmit}>
                <InputFormTwoColumn rows={rows} onChange={(e) => handleChange(e, setData)} data={data} />
                <button className='flex text-white bg-blue-600 rounded p-3 mx-auto'>Submit</button>
            </form>
        </div>
    );
}

export default CompanyAdd