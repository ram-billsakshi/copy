import React, { useState } from 'react';
import PagesHeader from '../components/PagesHeader/PagesHeader';
import razor from '../images/billsakshi/razor.png'
import paypal from '../images/billsakshi/paypal.png'
import paytm from '../images/billsakshi/paytm.png'
import payu from '../images/billsakshi/payu.png'


const PaymentOptions = () => {
  const [selectedOption, setSelectedOption] = useState('Razorpay');
  const handleFormSubmit = (e) => {
    // e.prevent
    console.log(e)
  }

  const renderForm = () => {
    switch (selectedOption) {
      case 'Razorpay':
        return (
          <form>
            <div className='flex'>
            <div className="mb-4 w-1/2 mr-2">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Razorpay key*
              </label>
              <input
                type="text"
                placeholder="Razorpay Key"
                required
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              />
            </div>
            <div className="mb-4 w-1/2">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Razorpay key Secret*
              </label>
              <input
                type="text"
                placeholder="Razorpay Key Secret"
                required
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              />
            </div>
            </div>
            <img src={razor} alt="Razorpay" className="w-73 mb-4" />
          </form>
        );
      case 'Paypal':
        return (
          <form>
            <div className='flex'>
                <div className="mb-4 w-1/2 mr-2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                    Paypal Email*
                </label>
                <input
                    type="text"
                    placeholder="Paypal Email"
                    required
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                </div>
                <div className="mb-4 w-1/2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                Is Demo?*
                </label>
                <select
                    type="Dropdown"
                    placeholder="Paytm Merchant Key"
                    required
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                >
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
                </div>
            </div>
            <div className='flex'>
                <div className="mb-4 w-1/2 mr-2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                    Paypal Extra Charge*
                </label>
                <input
                    type="text"
                    placeholder="Paypal Email"
                    required
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                </div>
                <div className="mb-4 w-1/2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                Is Active?*
                </label>
                <select
                    type="Dropdown"
                    placeholder="Paytm Merchant Key"
                    required
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                >
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
                </div>
            </div>
            <img src={paypal} alt="Paypal" className="w-73 mb-4 mt-4" />
          </form>
        );
      case 'PayUMoney':
        return (
            <form>
            <div className='flex'>
                <div className="mb-4 w-1/2 mr-2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                    PayUMoney Key*
                </label>
                <input
                    type="text"
                    placeholder="PayUMoney Key"
                    required
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                </div>
                <div className="mb-4 w-1/2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                Is Demo?*
                </label>
                <select
                    type="Dropdown"
                    required
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                >
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
                </div>
            </div>
            <div className='flex'>
                <div className="mb-4 w-1/2 mr-2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                    PayUMoney Key Salt
                </label>
                <input
                    type="text"
                    placeholder="PayUMoney Key Salt"
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                </div>
                <div className="mb-4 w-1/2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                Is Active?*
                </label>
                <select
                    type="Dropdown"
                    required
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                >
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
                </div>
            </div>
            <div className="mb-4 w-1/2 mr-2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                    PayUMoney Extra Charge*
                </label>
                <input
                    type="text"
                    placeholder="PayUMoney Extra Charge"
                    required
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                </div>
            <img src={payu} alt="Payu" className="w-73 mb-4 mt-4" />
            </form>
        );
      case 'CCAVENUE':
        return (
            <form>
            <div className='flex'>
                <div className="mb-4 w-1/2 mr-2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                    CCAvenue Key*
                </label>
                <input
                    type="text"
                    required
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                </div>
                <div className="mb-4 w-1/2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                Is Demo?*
                </label>
                <select
                    type="Dropdown"
                    required
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                >
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
                </div>
            </div>
            <div className='flex'>
                <div className="mb-4 w-1/2 mr-2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                    CCAvenue Key Salt
                </label>
                <input
                    type="text"
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                </div>
                <div className="mb-4 w-1/2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                Is Active?*
                </label>
                <select
                    type="Dropdown"
                    required
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                >
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
                </div>
            </div>
            <div className="mb-4 w-1/2 mr-2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                    Extra Charge*
                </label>
                <input
                    type="text"
                    required
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                </div>
            <img src={payu} alt="Payu" className="w-73 mb-4 mt-4" />
            </form>
        );
      case 'PayTM':
        return (
            <form>
            <div className='flex'>
                <div className="mb-4 w-1/2 mr-2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                    PayTM Merchant Key*
                </label>
                <input
                    type="text"
                    required
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                </div>
                <div className="mb-4 w-1/2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                Is Demo?*
                </label>
                <select
                    type="Dropdown"
                    required
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                >
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
                </div>
            </div>
            <div className='flex'>
                <div className="mb-4 w-1/2 mr-2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                    PayTM Merchant MID
                </label>
                <input
                    type="text"
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                </div>
                <div className="mb-4 w-1/2">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                Is Active?*
                </label>
                <select
                    type="Dropdown"
                    required
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                >
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
                </div>
            </div>
            <div className='flex'>
                <div className="mb-4 w-1/2 mr-2">
                    <label className="block text-gray-700 text-sm font-bold mb-2">
                        PayTM Extra Charge*
                    </label>
                    <input
                        type="text"
                        required
                        className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    />
                </div>
                <div className="mb-4 w-1/2 mr-2">
                    <label className="block text-gray-700 text-sm font-bold mb-2">
                        PayTM Website*
                    </label>
                    <input
                        type="text"
                        required
                        className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    />
                </div>
            </div>
            <img src={paytm} alt="PayTM" className="w-73 mb-4 mt-4" />
            </form>
        );
      default:
        return null;
    }
  };

  return (
    <div className='flex-1 max-h-180 border-2 border-gray shadow-1 m-4 bg-white'>
        <PagesHeader heading={"Payment Settings Add"}/>
        <div className="p-6">
            <div className="flex space-x-4 mb-4">
                <button onClick={() => setSelectedOption('Razorpay')} className={`px-4 py-2 ${selectedOption === 'Razorpay' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}>
                Razorpay
                </button>
                <button onClick={() => setSelectedOption('Paypal')} className={`px-4 py-2 ${selectedOption === 'Paytm' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}>
                Paypal
                </button>
                <button onClick={() => setSelectedOption('PayUMoney')} className={`px-4 py-2 ${selectedOption === 'PayUMoney' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}>
                PayUMoney
                </button>
                <button onClick={() => setSelectedOption('CCAVENUE')} className={`px-4 py-2 ${selectedOption === 'CCAVENUE' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}>
                CCAVENUE
                </button>
                <button onClick={() => setSelectedOption('PayTM')} className={`px-4 py-2 ${selectedOption === 'PayTM' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}>
                PayTM
                </button>
            </div>
            <div className="p-4 rounded">
                {renderForm()}
                <button className="bg-blue-500 text-white px-4 py-2 rounded" onClick={handleFormSubmit}>Submit</button>
            </div>
        </div>
    </div>
  );
};

export default PaymentOptions;
