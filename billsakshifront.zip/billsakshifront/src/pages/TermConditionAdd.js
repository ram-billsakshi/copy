import React, { useEffect, useState } from 'react'
import TextEditor from '../components/TextEditor'
import BtnPrimary from '../components/BtnPrimary'
import { useParams } from 'react-router-dom'
import { useSelector } from 'react-redux'

const TermConditionAdd = () => {

  const {termId} = useParams()
  // const termsEdit = useSelector(state => state?.terms?.termsAndCondition) || JSON.parse(localStorage.getItem('termsAndCondition'))
  const termsEdit =JSON.parse(localStorage.getItem('termsAndCondition'))

  const [htmlTerms, setHtmlTerms] = useState('')  

  useEffect(()=>{
    console.log(termId)
    console.log('termsEdit', termsEdit.messages)
    if(termId){
      setHtmlTerms(termsEdit.messages)
    }
  },[])

  return (
    <div className='bg-white p-5 shadow-sm w-full'>
      <div className='flex justify-between items-center p-4 border-b border-[rgba(0,0,0,0.2)]'>
        <h2>{termId ? "Terms & condition Edit" : "Terms & condition Add"}</h2>
        <BtnPrimary text='List' route={'/term-condition/list'}/>
      </div>
      {termId ? htmlTerms && <TextEditor html={htmlTerms}/> : <TextEditor html={htmlTerms}/>}
      <div className='text-right'><BtnPrimary text={termId ? 'Edit':'Add'} action={()=>{alert("action")}}/></div>
    </div>
  )
}

export default TermConditionAdd