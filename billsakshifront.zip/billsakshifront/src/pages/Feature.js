import React from 'react'
import feature1 from "../images/billsakshi/feature1.png"
import feature2 from "../images/billsakshi/feature2.png"
import feature3 from "../images/billsakshi/feature3.png"
import feature4 from "../images/billsakshi/feature4.png"
import feature5 from "../images/billsakshi/feature5.png"
import feature6 from "../images/billsakshi/feature6.png"
import FeatureCard from "../components/FeatureCard"


const Feature = () => {
  return (
    <section id='features' className="w-full flex flex-col items-center    min-h-[calc(100vh-85.63px)] px-3 lg:px-6 pt-29">
    <h1 className="text-3xl lg:text-4xl font-medium text-center text-[#1034F1]">OUR F<span className="pb-5 border-b-4 border-[#FA33A0]">EAT</span>URES</h1>
    <div className="w-[95%] lg:w-[60%] p-3 flex gap-5 flex-wrap justify-between">
      <div className="lg:w-[30%] sm:w-[45%] w-[100%]">
        <FeatureCard img={feature1} text={"Create and share GST Invoices & E-waybills with customers"} />
      </div>
      <div className="lg:w-[30%] sm:w-[45%] w-[100%]">
        <FeatureCard img={feature2} text={"Manage and check your Inventory instantly"} />
      </div>
      <div className="lg:w-[30%] sm:w-[45%] w-[100%]">
        <FeatureCard img={feature3} text={"Manage and Track Purchase, Expenses and Ledgers"} />
      </div>
      <div className="lg:w-[30%] sm:w-[45%] w-[100%]">
        <FeatureCard img={feature4} text={"Send Gentle Payment Reminders to Customers"} />
      </div>
      <div className="lg:w-[30%] sm:w-[45%] w-[100%]">
        <FeatureCard img={feature5} text={"Keep a live track of various business reports"} />
      </div>
      <div className="lg:w-[30%] sm:w-[45%] w-[100%]">
        <FeatureCard img={feature6} text={"Make your GST Filing simpler and faster"} />
      </div>
    </div>
  </section>
  )
}

export default Feature