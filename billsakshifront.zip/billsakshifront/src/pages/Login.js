import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import billsakshi_banner from '../images/billsakshi/billsakshi_banner.jpeg';
import billsakshiLogo from "../images/billsakshi/billsakshiLogo.png"
import { useDispatch } from 'react-redux';
import { setPage } from '../redux/pageSlice';
import useGetData from "../hooks/useGetData";
import { loginFailure, loginSuccess } from '../redux/authSlice';



const Login = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const {data:users} = useGetData("users")
  const [formData,setFormData] = useState({
      userId: "",
      password: ""
  })

  const handleLogin = (e) => {
    e.preventDefault();
  
    const user = users?.find(user => user.email === formData.userId && user.password === formData.password);
  
    if (user) {
      dispatch(loginSuccess(user));
  
      const baseUrl = process.env.REACT_APP_API_BASE_URL;
      console.log(user, "testing22");
  
      fetch(`${baseUrl}/profile`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(user) 
      })
      .then(response => response.json())
      .then(data => console.log('Success:', data))
      .catch((error) => console.error('Error:', error));
  
    } else {
      dispatch(loginFailure("User doesn't exist"));
    }
  };
  

  return (
    <div className='flex flex-col justify-between h-[100vh] bg-white'>
      <div>
      <div className='min-h-[90px] w-full shadow-md flex items-center justify-around'>
      <div className="w-12">
              <Link to={'/'}><img src={billsakshiLogo} alt="billsakshiLogo" /></Link>
      </div>
        <Link className='text-[#007bff] font-bold text-xl' to={'#'}>Contact Us</Link>
      </div>
      <br />
      <br />
      <br />
      <div className="flex flex-col lg:flex-row bg-gray-100 mt-10">
        {/* Left Side - Image */}
        <div className="w-full lg:w-1/2 flex justify-center items-center bg-gray-100">
          <img src={billsakshi_banner} alt="Bill Sakshi Banner" className="max-w-full h-auto" />
        </div>

        {/* Right Side - Form */}
        <div className="w-full lg:w-1/2 flex flex-col justify-center items-center p-8">
          <div className="w-full max-w-sm">
            <h1 className="text-3xl text-[#377fb7] font-bold mb-6 text-center lg:text-left">
              A Cloud Based GST Billing, and Inventory Management Software
            </h1>
            <h2 className="text-xl text-[#f91f97] font-bold mb-6 text-center lg:text-left">
              Login to Smart | Simple | Secure IMS
            </h2>

            <form onSubmit={handleLogin}>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="username">
                  Username
                </label>
                <input
                  className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  type="text"
                  placeholder="Username"
                  onChange={(e)=>{setFormData({...formData,userId:e.target.value})}}
                />
              </div>
              <div className="mb-6">
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">
                  Password
                </label>
                <input
                  className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
                  type="password"
                  placeholder="************"
                  onChange={(e)=>{setFormData({...formData,password:e.target.value})}}
                />
              </div>
              <div className="flex flex-col lg:flex-row items-center justify-between mb-4">
                <button
                  className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline mb-2 lg:mb-0"
                  type="submit"
                >
                  Sign In
                </button>
                <Link className="inline-block align-baseline font-bold text-sm text-blue-500 hover:text-blue-800" to="#">
                  Forgot Password?
                </Link>
              </div>
              <div className="flex items-center justify-center">
                <button onClick={()=>{
                  dispatch(setPage('pricing'))
                  navigate("/")
                }}
                  className="bg-pink-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                  type="button">
                  Sign Up
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      </div>
      <div className='w-full flex justify-center items-center border-t-2 border-[rgba(0,0,0,0.1)] min-h-[70px] text-[#626262]'>
      About BILLSAKSHI . Terms & Conditions . Privacy Policy . Contact Us . © 2022 BILLSAKSHI
      </div>
    </div>
  );
};

export default Login;
