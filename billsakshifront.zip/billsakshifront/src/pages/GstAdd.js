import React, { useEffect, useState } from 'react'
import PagesHeader from '../components/PagesHeader/PagesHeader';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import InputForm from '../components/InputForm/InputForm';
import { handleChange, stateData } from '../utils';
import { useParams } from 'react-router-dom';

const rows = [
    {
        name: "gstName",
        label: "GST Name",
        placeholder: "Enter GST Name",
        type: "text",
        isRequired: true,
        maxChar:null, 
        readonly: false
    },
    {
        name: "gstValue",
        label: "GST Value",
        placeholder: "Enter GST Value",
        type: "text",
        isRequired: true,
        maxChar:null, 
        readonly: false
    }
] 

const GstAdd = () => {
    const [data,setData] = useState(stateData(rows))

    const gstEdit = 
    // useSelector(state => state?.vendor?.vendorEdit) || 
    JSON.parse(localStorage.gstEdit)
    
    const handleSubmit = (e) => {
        e.preventDefault()
        console.log(data);
    }
    const handleEdit = (e) => {
        e.preventDefault()
        console.log('edit')
    }
    const { gstId } = useParams()

    useEffect(()=>{
        const {gstName,gstValue} = gstEdit
        if(gstId){
            setData({...data,gstName,gstValue})
        }
    }, [])

   return (
    <div className='flex-1 shadow-1 bg-white'>
        <PagesHeader navigateTo={"/gst/list"} heading={"Gst Add"} button={"List"}/>
        <form className='p-5' onSubmit={gstId ? handleEdit : handleSubmit}>
            <InputForm rows={rows} data={data} onChange={(e) => handleChange(e,setData)}/>
            <button className='flex text-white bg-blue-600 rounded p-3 mx-auto'>Submit</button>
        </form>
    </div>
);
}

export default GstAdd