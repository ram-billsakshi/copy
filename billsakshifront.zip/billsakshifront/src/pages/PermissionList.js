import * as React from 'react';
import DataTable from "../components/DataTable"
import { IoMdSettings } from "react-icons/io";
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { getEditData } from '../redux/permissionSlice';
// import Header from '../components/Header';
// import CustomizedTables from '../components/Table/Table';IoMdSettings
// import Sidebar from '../components/Sidebar';

// function createData(
//   name,
//   calories,
//   fat,
//   carbs,
//   protein,
// ) {
//   return { name, calories, fat, carbs, protein };
// }

// const columns = ["Sl. No.", "Role Name", "Note", "Is Default", "Action"]

// const rows = [
//   createData('Frozen yoghurt', 159, 6.0, 24, 4.0),
//   createData('Ice cream sandwich', 237, 9.0, 37, 4.3),
//   createData('Eclair', 262, 16.0, 24, 6.0),
//   createData('Cupcake', 305, 3.7, 67, 4.3),
//   createData('Gingerbread', 356, 16.0, 49, 3.9),
// ];



export default function PermissionList() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const handleEdit = (row) => {
    dispatch(getEditData(row))
    navigate("/permission/edit")
  }

  const columns = [
    { field: "id", headerName: "Sl No.", width: 80 },
    { field: "name", headerName: "Role Name", flex: 1, minWidth: 200 },
    { field: "note", headerName: "Note", flex: 1, minWidth: 200 },
    { 
      field: "is_default", 
      headerName: "Is Default", 
      flex: 1, 
      minWidth: 100,
      renderCell: (params) => (
        params.value === 1 ? "Yes" : "No"
      ),
    },
    {
      field: "action",
      headerName: "Action",
      width: 100,
      renderCell: (params) => (
        <div className='h-[100%] flex items-center cursor-pointer'><IoMdSettings size={20} onClick={() => handleEdit(params.row)}/></div>
      ),
    },
  ];

  return (
    <div className='w-full'>
      <DataTable endpoint="/roles" columns={columns} type="Permission" isAdd={false} isHeaderAction={false}/>
    </div>
    // <div className='border-2 border-gray flex-1 bg-white shadow-sm'>
    //   <h1 className='p-4 border-b-2 border-gray'>Permission</h1>    
    //   <CustomizedTables rows={rows} columns={columns}/>
    // </div>
  );
}
