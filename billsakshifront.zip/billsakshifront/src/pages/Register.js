import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { FaRupeeSign } from "react-icons/fa";
import { Link, useNavigate } from "react-router-dom";
import LoginFinal from '../images/billsakshi/LoginFinal.png';
import Header from '../components/Header';
import LoginFinal3 from '../images/billsakshi/LoginFinal3.png'

const SubscriptionForm = () => {
  const { current, data } = useSelector((state) => state.subscription);
  const [isTick, setIsTick] = useState(false);
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    email: "",
    amount: ""
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({
      ...form,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted:", form);
    navigate("/payments/pay");
  };

  useEffect(() => {
    const tmp = data[current].gst === "Including" ? data[current].price : (data[current].price * 118) / 100;
    setForm({ ...form, amount: isTick ? tmp : "" });
  }, [isTick]);

  return (
    <>
      <div className="h-screen flex-col items-center justify-center bg-cover bg-center" style={{ backgroundImage: `url(${LoginFinal3})` }}>
      <Header/>
      <div className="bg-black bg-opacity-40 w-full h-[calc(100vh-86px)] flex items-center justify-center overflow-hidden">
        <div className="bg-white rounded-lg max-w-4xl w-full">
          <div className="text-[#626262]">
            <h1 className="text-3xl font-bold text-center mt-8">
              SUBSCRIPTION DETAILS
            </h1>

            <div className="flex flex-col lg:flex-row bg-gray-100 mt-3">
              <div className="w-full lg:w-1/2 flex justify-center mt-15 bg-gray-100 p-4">
                <div className="">
                  <h2 className="text-2xl font-semibold mb-4">
                    {data[current].price === 0 ? "Trial" : data[current].time}
                  </h2>
                  <ul className="text-left list-disc ml-8">
                    {data[current].features.map((item, index) => (
                      <li key={index}>{item}</li>
                    ))}
                  </ul>
                  <h2 className="text-2xl font-semibold mb-4 mt-8">
                    Price [GST - 18% ({data[current].gst})]
                  </h2>
                  <div className="flex items-center gap-2">
                    <input type="checkbox" checked={isTick} onChange={() => { setIsTick(!isTick); }} />
                    <div className="flex items-center">
                      {data[current].price === 0 ? (
                        "Free"
                      ) : (
                        <>
                          <span>{data[current].time} - </span>
                          <FaRupeeSign />
                          <span>{data[current].price}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Side - Form */}
              <div className="w-full lg:w-1/2 flex flex-col justify-center items-center p-8">
                <div className="w-full max-w-sm">
                  <form onSubmit={handleSubmit}>
                    <div className="mb-4">
                      <label
                        className="block text-gray-700 text-sm font-bold mb-2"
                        htmlFor="name"
                      >
                        Name
                      </label>
                      <input
                        placeholder="Enter Name"
                        type="text"
                        id="name"
                        name="name"
                        value={form.name}
                        onChange={handleChange}
                        required
                        className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      />
                      {/* <input type="text" placeholder="Enter Name" /> */}
                    </div>
                    <div className="mb-4">
                      <label
                        className="block text-gray-700 text-sm font-bold mb-2"
                        htmlFor="email"
                      >
                        Email
                      </label>
                      <input
                        placeholder="Enter email"
                        type="email"
                        id="email"
                        name="email"
                        value={form.email}
                        onChange={handleChange}
                        required
                        className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      />
                    </div>
                    <div className="mb-4">
                      <label
                        className="block text-gray-700 text-sm font-bold mb-2"
                        htmlFor="contactNumber"
                      >
                        Contact Number
                      </label>
                      <input
                        placeholder="Enter Contact Number"
                        type="text"
                        id="contactNumber"
                        name="contactNumber"
                        value={form.contactNumber}
                        onChange={handleChange}
                        required
                        maxLength={10}
                        pattern="^-?\d+$"
                        title="Please enter valid mobile number"
                        className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      />
                    </div>
                    <div className="mb-4">
                      <label
                        className="block text-gray-700 text-sm font-bold mb-2"
                        htmlFor="address"
                      >
                        ADDRESS
                      </label>
                      <input
                        placeholder="Enter Address"
                        type="text"
                        id="address"
                        name="address"
                        value={form.address}
                        onChange={handleChange}
                        required
                        minLength={5}
                        className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      />
                    </div>
                    <div className="flex">
                    <div className="mb-4 mr-2">
                      <label
                        className="block text-gray-700 text-sm font-bold mb-2"
                        htmlFor="amount"
                      >
                        Amount
                      </label>
                      <input
                        type="text"
                        id="amount"
                        name="amount"
                        value={form.amount}
                        onChange={handleChange}
                        readOnly={true}
                        className="bg-gray-200 shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      />
                    </div>
                    <div className="mb-4">
                      <label
                        className="block text-gray-700 text-sm font-bold mb-2"
                        htmlFor="otp"
                      >
                        OTP
                      </label>
                      <input
                        placeholder="Enter OTP"
                        type="text"
                        id="otp"
                        name="otp"
                        value={form.otp}
                        onChange={handleChange}
                        required
                        className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      />
                    </div>
                    </div>
                    <div className="flex">
                    <div className="mb-4 mr-2">
                      <label
                        className="block text-gray-700 text-sm font-bold mb-2"
                        htmlFor="couponCode"
                      >
                        Coupon Code (Optional)
                      </label>
                      <input
                        placeholder="Enter Coupon Code"
                        type="text"
                        id="couponCode"
                        name="couponCode"
                        value={form.couponCode}
                        onChange={handleChange}
                        className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      />
                    </div>
                    <div className="mb-4">
                      <label
                        className="block text-gray-700 text-sm font-bold mb-2"
                        htmlFor="referralCode"
                      >
                        Referral Code
                      </label>
                      <input
                        placeholder="Enter Referral Code"
                        type="text"
                        id="referralCode"
                        name="referralCode"
                        value={form.referralCode}
                        onChange={handleChange}
                        className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      />
                    </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <button
                        type="submit"
                        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                      >
                        Pay now
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> 
    </div>
    </>
    
  );
};

export default SubscriptionForm;
