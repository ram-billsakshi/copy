import React from 'react'
import PricingCard from "../components/PricingCard"
const fdata1 = [
  '7 Days Free Access',
  'Generate GST Invoices',
  'Inventory Stock Management',
  'Manage Account Payables',
  'Manage Account Receivables',
  'Collect Payments Faster',
  'Track and Manage Business Reports',
  'Customer Support',
  <span className="text-white">.</span>
]
const fdata2 = [
  "365 Days Access",
  "Billed Quarterly For First Billing",
  "Generate GST Invoices",
  "Inventory & Stock Management",
  "Manage Account Payables",
  "Manage Account Receivables",
  "Collect Payments Faster",
  "Track and Manage Business Reports",
  "Customer Support"
]
const fdata3 = [
  "730 Days Access",
  "Generate GST Invoices",
  "Inventory & Stock Management",
  "Manage Account Payables",
  "Manage Account Receivables",
  "Collect Payments Faster",
  "Track and Manage Business Reports",
  "Customer Support",
  <span className="text-white">.</span>
];
const fdata4 = [
  "1095 Days Access",
  "Generate GST Invoices",
  "Inventory & Stock Management",
  "Manage Account Payables",
  "Manage Account Receivables",
  "Collect Payments Faster",
  "Track and Manage Business Reports",
  "Customer Support",
  <span className="text-white">.</span>
];

function Pricing() {
  return (
    <section id='pricing' className="flex flex-wrap justify-center  min-h-[calc(100vh-85.63px)] px-3 lg:px-6 pt-29 bg-[#edf2f4]">
    <h1 className="text-3xl lg:text-4xl font-medium text-center text-[#444444] mb-15">PR<span className="pb-5 border-b-4 border-[#FA33A0]">ICI</span>NG</h1>

    <div className="w-[95%] m-auto flex gap-5 flex-wrap">
      <div className="w-[100%] sm:w-[45%] lg:w-[22%] grow" key={1}>
        <PricingCard price="FREE" gst="7 Days Excluding GST" time="TRIAL" desc={fdata1} clickType={"trial"} />
      </div>
      <div className="w-[100%] sm:w-[45%] lg:w-[22%] grow " key={2}>
        <PricingCard price="₹ 2999" gst="Including GST" time="1 Year" desc={fdata2} clickType={"oneyear"} />
      </div>
      <div className="w-[100%] sm:w-[45%] lg:w-[22%] grow " key={3}>
        <PricingCard price="₹ 4999" gst="Excluding GST" time="2 Years" desc={fdata3} clickType={"twoyear"} />
      </div>
      <div className="w-[100%] sm:w-[45%] lg:w-[22%] grow " key={4}>
        <PricingCard price="₹ 7299" gst="Excluding GST" time="3 Years" desc={fdata4} clickType={"threeyear"} />
      </div>
    </div>
  </section>
  )
}

export default Pricing