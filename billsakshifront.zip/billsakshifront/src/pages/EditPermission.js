import React from 'react'
import { useSelector } from 'react-redux'
import PermissionTable from '../components/PermissionTable';

const data = [
  {
    "sl_no": "1",
    "module_name": "Settings",
    "functions": [
      {
        "sl_no": "1.1",
        "function_name": "Operation",
        "view": "",
        "add": "",
        "edit": "checked",
        "delete": ""
      },
      {
        "sl_no": "1.2",
        "function_name": "Module",
        "view": "",
        "add": "checked",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "1.3",
        "function_name": "Permission",
        "view": "",
        "add": "",
        "edit": "",
        "delete": "checked"
      }
    ]
  },
  {
    "sl_no": "2",
    "module_name": "Administrator",
    "functions": [
      {
        "sl_no": "2.1",
        "function_name": "Role",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "2.2",
        "function_name": "User",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "2.3",
        "function_name": "Subscription_type",
        "view": "",
        "add": "checked",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "2.4",
        "function_name": "Subscription",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "2.5",
        "function_name": "My_subscription",
        "view": "",
        "add": "",
        "edit": "checked",
        "delete": ""
      },
      {
        "sl_no": "2.6",
        "function_name": "Term_condition",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "2.7",
        "function_name": "My_transaction",
        "view": "checked",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "2.8",
        "function_name": "User_subscription",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "2.9",
        "function_name": "Wallet",
        "view": "",
        "add": "",
        "edit": "",
        "delete": "checked"
      }
    ]
  },
  {
    "sl_no": "3",
    "module_name": "Category",
    "functions": [
      {
        "sl_no": "3.1",
        "function_name": "Meta_label",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "3.2",
        "function_name": "Listitems",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "3.3",
        "function_name": "Meta_type",
        "view": "",
        "add": "checked",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "3.4",
        "function_name": "Bulk",
        "view": "",
        "add": "",
        "edit": "",
        "delete": "checked"
      }
    ]
  },
  {
    "sl_no": "4",
    "module_name": "Sales",
    "functions": [
      {
        "sl_no": "4.1",
        "function_name": "Credit",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "4.2",
        "function_name": "Return",
        "view": "",
        "add": "",
        "edit": "",
        "delete": "checked"
      },
      {
        "sl_no": "4.3",
        "function_name": "Customer",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "4.4",
        "function_name": "Estimate",
        "view": "",
        "add": "",
        "edit": "",
        "delete": "checked"
      },
      {
        "sl_no": "4.5",
        "function_name": "Invoice",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "4.6",
        "function_name": "Payment",
        "view": "",
        "add": "",
        "edit": "",
        "delete": "checked"
      }
    ]
  },
  {
    "sl_no": "5",
    "module_name": "Customer",
    "functions": [
      {
        "sl_no": "5.1",
        "function_name": "Company",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "5.2",
        "function_name": "Vendor",
        "view": "",
        "add": "",
        "edit": "checked",
        "delete": ""
      }
    ]
  },
  {
    "sl_no": "6",
    "module_name": "Expenses",
    "functions": [
      {
        "sl_no": "6.1",
        "function_name": "Category",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "6.2",
        "function_name": "Expenses_detail",
        "view": "",
        "add": "",
        "edit": "checked",
        "delete": ""
      }
    ]
  },
  {
    "sl_no": "7",
    "module_name": "Report",
    "functions": [
      {
        "sl_no": "7.1",
        "function_name": "Debits",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "7.2",
        "function_name": "Recievable",
        "view": "",
        "add": "",
        "edit": "",
        "delete": "checked"
      },
      {
        "sl_no": "7.3",
        "function_name": "Payable",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "7.4",
        "function_name": "Credits",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "7.5",
        "function_name": "Purchase",
        "view": "",
        "add": "",
        "edit": "checked",
        "delete": ""
      },
      {
        "sl_no": "7.6",
        "function_name": "Sales",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      }
    ]
  },
  {
    "sl_no": "8",
    "module_name": "Purchase",
    "functions": [
      {
        "sl_no": "8.1",
        "function_name": "Purchase_return",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "8.2",
        "function_name": "Purchase_invoice",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "8.3",
        "function_name": "Account_payable",
        "view": "",
        "add": "",
        "edit": "checked",
        "delete": ""
      },
      {
        "sl_no": "8.4",
        "function_name": "Purchase_issued",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      }
    ]
  },
  {
    "sl_no": "9",
    "module_name": "Master",
    "functions": [
      {
        "sl_no": "9.1",
        "function_name": "Gst",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "9.2",
        "function_name": "Unit",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "9.3",
        "function_name": "Banking",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      },
      {
        "sl_no": "9.4",
        "function_name": "Discount",
        "view": "",
        "add": "",
        "edit": "",
        "delete": ""
      }
    ]
  }
]

const EditPermission = () => {
  const {editData} = useSelector(state => state.permission)
  return (
    <div className="w-full p-5 bg-white shadow-md rounded-md">
      <h1 className='mb-5 font-bold text-xl'>{editData.name}</h1>
      <div className='h-[calc(100vh-220px)] overflow-auto'>
        <PermissionTable data={data} />
      </div>
  </div>
  )
}

export default EditPermission