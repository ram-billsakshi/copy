import React from 'react'
import DataTable from '../components/DataTable';
import { FiEdit } from 'react-icons/fi';
import { MdOutlineDelete } from 'react-icons/md';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { setExpenseDetail } from '../redux/expenseDetailSlice';


const ExpenseCategoryList = () => {
  const columns = [
    { field: "id", headerName: "Sl No.", width: 80 },
      { field: "expense_name", headerName: "Expense Name", flex: 1, minWidth: 200 },
      { 
        field: "status", 
        headerName: "Status", 
        flex: 1, 
        minWidth: 100,
        renderCell: (params) => (
            <button className={`${params.value?'bg-red-500':'bg-[#3b82f6]'} text-white leading-normal w-[100px] py-2 rounded-md`} onClick={() => alert(params.value)}>{params.value?'Deactivate':'Activate'}</button>
        ),
      },
      {
        field: "action",
        headerName: "Action",
        width: 100,
        renderCell: (params) => (
          <div className="flex h-full items-center">
            <FiEdit className="w-1/2 h-1/2 items-center cursor-pointer" onClick={() => handleRole(params)}/>  
            <MdOutlineDelete className="w-1/2 h-1/2 items-center cursor-pointer"  onClick={() => alert(params.id)}/>
          </div>
        ),
      },
  ]
  const dispatch = useDispatch()
  const navigate = useNavigate()
  
  const handleRole = (expense) => {
    console.log(expense)
    localStorage.setItem('expenseDetails', JSON.stringify(expense.row))
    dispatch(setExpenseDetail(expense.row))
    navigate(`/expensesCategoryEdit/${expense.id}`)
  }
    return (
        <div>
          <DataTable columns={columns} endpoint={"/expense_details"} type={"Expense Category"} redirect='/expensesCategoryAdd'/>
        </div>
      );
}

export default ExpenseCategoryList