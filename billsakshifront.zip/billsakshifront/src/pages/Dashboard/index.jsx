import React from "react";
import CardDataStats from "../../components/CardDataStats";
import ChartOne from "../../components/Charts/ChartOne";
import ChartThree from "../../components/Charts/ChartThree";
import ChartTwo from "../../components/Charts/ChartTwo";
import MapOne from "../../components/Maps/MapOne";
import CardSlider from "../../components/Slider";
import { cardData } from "../../data/data";
import Calendar from "../Calendar";
import InvoiceTableCard from "../../components/InvoiceTableCard";
import useGetData from "../../hooks/useGetData";
import Schedular from "../../components/Schedular/Index";


const invoiceCol=["Invoice Number","Date","Amount (INR)"]

const Index = () => {

  const {data:recentSaleInvoices} = useGetData("sales-invoice")
  const {data:recentSaleReturnInvoices} = useGetData("sales-return")
  const {data:recentPurchaseInvoices} = useGetData("purchase-invoice")
  const {data:recentPurchaseReturnInvoices} = useGetData("purchase-return")
  const {data:calendarData} = useGetData("sale-due-dates")

  const cards = cardData.map((data, index) => (
    <CardDataStats
      key={index}
      title={data.title}
      total={data.total}
      rate={data.rate}
      totalIcon={data.totalIcon}
      levelUp={data.levelUp}
    />
  ));

  return (
    <>
      <div className="grid-cols-1 gap-4 md:grid-cols-2 md:gap-6 xl:grid-cols-4 2xl:gap-7.5 grid"></div>
      <div className="w-full lg:hidden">
        <CardSlider cards={cards} />
      </div>

      <div className="grid-cols-1 gap-2 md:grid-cols-4 xl:grid-cols-6 hidden lg:grid">
        {cards.map((card) => card)}
      </div>

      <div className=" w-full flex flex-wrap gap-4 md:gap-6 2xl:gap-7.5 mt-7">
        <div className="w-full xl:w-[45%] grow">
        <ChartOne />
        </div>
        <div className="w-full xl:w-[45%] grow">
        {/* <Calendar data={calendarData}/> */}
        <Schedular/>

        </div>
        <div className="w-full xl:w-[45%] grow">
        <InvoiceTableCard invoices={recentSaleInvoices} columns={invoiceCol} tblHead={"Recent Sales Invoice"}/>
        </div>
        <div className="w-full xl:w-[45%] grow">
        <InvoiceTableCard invoices={recentSaleReturnInvoices} columns={[...invoiceCol,"Status"]} tblHead={"Recent Sales Return"}/>
        </div>
        <div className="w-full xl:w-[45%] grow">
        <InvoiceTableCard invoices={recentPurchaseInvoices} columns={invoiceCol} tblHead={"Recent Sales Invoice"}/>
        </div>
        <div className="w-full xl:w-[45%] grow">
        <InvoiceTableCard invoices={recentPurchaseReturnInvoices} columns={[...invoiceCol,"Status"]} tblHead={"Recent Sales Return"}/>
        </div>

      </div>
    </>
  );
};

export default Index;
