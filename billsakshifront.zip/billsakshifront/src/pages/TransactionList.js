import React from 'react'
import DataTable from '../components/DataTable';

const columns = [
  { field: "id", headerName: "Sl No.", width: 80 },
  { field: "order_id", headerName: "Order Id", flex: 1 },
  { field: "transition_id", headerName: "Transition Id", flex: 1},
  { field: "payment_method", headerName: "Payment Method", flex: 1},
  { field: "payment_status", headerName: "Payment Status", flex: 1},
  { field: "amount", headerName: "Amount", flex: 1},
  { field: "payment_at", headerName: "Payment At", flex: 1},
]

const TransactionList = () => {
    return (
        <div><DataTable columns={columns} endpoint={"/transition-list"} type={"My Transaction"} isAdd={false}/></div>
      );
}

export default TransactionList