import React, { useState } from "react";

import DataTable from "../components/DataTable";
import { FiEdit } from "react-icons/fi";
import { FaWindowClose } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import Popup from "../components/Popup";

const ProductSubCategoryList = () => {
  const [warn, setWarn] = useState(false);
  const navigate = useNavigate();
  const columns = [
    { field: "id", headerName: "Sl No.", width: 80 },
    { field: "typeName", headerName: "Type Name", flex: 1 },
    { field: "labelName", headerName: "Label Name", flex: 1 },
    { field: "description", headerName: "Description", flex: 1 },
    { field: "icon", headerName: "Icon", flex: 1 },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
      minWidth: 150,
      renderCell: (params) => (
        <button
          className={`${
            params.value ? "bg-red-500" : "bg-[#3b82f6]"
          } text-white leading-normal w-[100px] py-2 rounded-md`}
          onClick={() => alert(params.value)}
        >
          {params.value ? "Deactivate" : "Activate"}
        </button>
      ),
    },
    {
      field: "action",
      headerName: "Action",
      renderCell: (params) => (
        <div className="flex gap-2 h-full items-center text-[rgba(0,0,0,0.7)]">
          <FiEdit
            size={35}
            className="cursor-pointer"
            onClick={() => handlesubCategEdit(params)}
          />
          <FaWindowClose
            className="cursor-pointer"
            size={35}
            onClick={() => setWarn(true)}
          />
        </div>
      ),
    },
  ];
  const handlesubCategEdit = (subCateg) => {
    console.log("subCateg", subCateg);
    // dispatch(setVendor(vendor.row));
    localStorage.setItem("subCategEdit", JSON.stringify(subCateg.row));
    navigate(`/sub-category/edit/${subCateg.id}`);
  };
  const handleWarn = (e) => {
    e.preventDefault();
    console.log("Submission");
    setWarn(false);
  };

  return (
    <div className="w-full">
      <Popup
        isOpen={warn}
        setIsOpen={setWarn}
        handleSubmit={handleWarn}
        heading="Are you sure ?"
        submitText="OK"
      ></Popup>
      <DataTable
        columns={columns}
        endpoint={"/productSubCategory"}
        type={"Sub Category"}
        redirect="/sub-category/add"
      />
    </div>
  );
};

export default ProductSubCategoryList;
