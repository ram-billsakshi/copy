import React from 'react'
import DataTable from '../components/DataTable';
import { FiEdit } from 'react-icons/fi'; 
import { MdOutlineDelete } from "react-icons/md";
import { FaRegEye } from "react-icons/fa";
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { setCompany } from '../redux/companySlice';

const CompanyList = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const  columns = [
    { field: 'id', headerName: 'Sl No.', width:80 }, 
    { field: 'name', headerName: 'Name', flex: 1,minWidth:200 },
    { field: 'contact', headerName: 'Contact No.', flex: 1,minWidth:200 },
    { field: 'email', headerName: 'Email Id', flex: 1,minWidth:100,},
    { field: 'address', headerName: 'Address', flex: 1,minWidth:100,},
    { field: 'status', headerName: 'Status', flex: 1,minWidth:100,
      renderCell: (params) => (
        <button className={`${params.value?'bg-red-500':'bg-[#3b82f6]'} text-white leading-normal w-[100px] py-2 rounded-md`} onClick={() => alert(params.value)}>{params.value?'Inactive':'Active'}</button>
      ),
    },
    { 
      field: 'action', 
      headerName: 'Action', 
      width:100,
      renderCell: (params) => (
        <div className="flex h-full items-center">
          <FiEdit className="w-1/2 h-1/2 items-center cursor-pointer" onClick={() => handleRole(params)}/>
          <MdOutlineDelete className="w-1/2 h-1/2 items-center cursor-pointer" onClick={() => handleRole(params)}/>
          <FaRegEye className="w-1/2 h-1/2 items-center cursor-pointer" onClick={()=> handleOnEyeClick(params)}/>
        </div>
      ),
    },
  ];
  const handleRole = (company) => {
      console.log('comapny', company)
      dispatch(setCompany(company.row))
      localStorage.setItem('company', JSON.stringify(company.row))
      navigate(`/company/edit/${company.id}`)
  }
  const handleOnEyeClick = (params) => {
    console.log(params)
    navigate('/company/view')
  }

    return (
        <div className='w-full'>
          <DataTable columns={columns} endpoint={"/company"} type={"Company"} isAdd={true} redirect="/company/add"/>
        </div>
      );
}


export default CompanyList