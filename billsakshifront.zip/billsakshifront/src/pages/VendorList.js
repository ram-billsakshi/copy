import React, { useState } from 'react'
import DataTable from '../components/DataTable';
import { FiEdit } from "react-icons/fi";
import { FaWindowClose } from "react-icons/fa";
import { IoLockClosed } from "react-icons/io5";
import Popup from '../components/Popup';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';

const VendorList = () => {
  const [warn, setWarn] = useState(false);
  const [vendor, setVendor] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();


  const handleVendorEdit = (vendor) => {
    console.log("vendor", vendor);
    // dispatch(setVendor(vendor.row));
    localStorage.setItem("vendorEdit", JSON.stringify(vendor.row));
    navigate(`/vendor/edit/${vendor.id}`);
  };

  const columns = [
    { field: "id", headerName: "Sl No.", width: 80 },
    { field: "name", headerName: "Name", flex: 1 },
    { field: "contact", headerName: "Contact No.", flex: 1 },
    { field: "email", headerName: "Email Id", flex: 1 },
    { field: "ifsc", headerName: "IFSC", flex: 1 },
    { field: "account", headerName: "Account No.", flex: 1 },
    { field: "gst", headerName: "GST No.", flex: 1 },
    { field: "address", headerName: "Address", flex: 1 },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
      minWidth: 150,
      renderCell: (params) => (
        <button
          className={`${
            params.value ? "bg-red-500" : "bg-[#3b82f6]"
          } text-white leading-normal w-[100px] py-2 rounded-md`}
          onClick={() => alert(params.value)}
        >
          {params.value ? "Deactivate" : "Activate"}
        </button>
      ),
    },
    {
      field: "action",
      headerName: "Action",
      renderCell: (params) => (
        <div className="flex gap-2 h-full items-center text-[rgba(0,0,0,0.7)]">
          <FiEdit
            size={35}
            className="cursor-pointer"
            onClick={() => handleVendorEdit(params)}
          />
          <FaWindowClose className="cursor-pointer" size={35} onClick={()=>setWarn(true)} />
        </div>
      ),
    }];

  const handleWarn = (e) => {
    e.preventDefault();
    console.log("Submission");
    setWarn(false);
  };

    return (
        <div className='w-full'>
                <Popup
        isOpen={warn}
        setIsOpen={setWarn}
        handleSubmit={handleWarn}
        heading="Are you sure ?"
        submitText="OK"
      ></Popup>
          <DataTable columns={columns} endpoint={"/vendors"} type={"Vendor"} redirect='/vendor/add'/>
        </div>
      );
}

export default VendorList