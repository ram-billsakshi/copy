import React, {useState} from 'react';
import { useDispatch } from 'react-redux';
import { setPage } from '../redux/pageSlice';
import useGetData from "../hooks/useGetData";
import { loginFailure, loginSuccess } from '../redux/authSlice';
import { Link, useNavigate } from 'react-router-dom';
import LoginFinal from '../images/billsakshi/LoginFinal.png'
import LoginFinal2 from '../images/billsakshi/LoginFinal2.png'
import LoginFinal3 from '../images/billsakshi/LoginFinal3.png'

const LoginPage = () => {

    const dispatch = useDispatch()
  const navigate = useNavigate()
  const {data:users} = useGetData("users")
  const [formData,setFormData] = useState({
      userId: "",
      password: ""
  })

  const handleLogin = (e) => {
    e.preventDefault();
  
    const user = users?.find(user => user.email === formData.userId && user.password === formData.password);
  
    if (user) {
      dispatch(loginSuccess(user));
  
      const baseUrl = process.env.REACT_APP_API_BASE_URL;
      console.log(user, "testing22");
  
      fetch(`${baseUrl}/profile`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(user) 
      })
      .then(response => response.json())
      .then(data => console.log('Success:', data))
      .catch((error) => console.error('Error:', error));
  
    } else {
      dispatch(loginFailure("User doesn't exist"));
    }
  };

  return (
    <div className="h-screen flex items-center justify-center bg-cover bg-center" style={{ backgroundImage: `url(${LoginFinal3})` }}>
      <div className="bg-black bg-opacity-40 w-full h-full flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg max-w-md w-full">
          <h2 className="text-5xl font-bold mb-4 text-center text-[#30629D]">BillSakshi</h2>
          <h2 className="text-xl font-bold mb-4 text-center">व्यापार हो स्मार्ट, tension रहे apart!</h2>
          <h2 className="text-3xl text-center mb-4">🙏</h2>
          <form className="w-full" onSubmit={handleLogin}>
          <div className="mb-4">
            <label className="block text-gray-700 text-xl font-bold mb-2" htmlFor="username">
                Username
            </label>
            <input
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                type="text"
                placeholder="Username"
                onChange={(e)=>{setFormData({...formData,userId:e.target.value})}}
            />
            </div>
            <div className="mb-6">
                <label className="block text-gray-700 text-xl font-bold mb-2" htmlFor="password">
                  Password
                </label>
                <input
                  className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
                  type="password"
                  placeholder="************"
                  onChange={(e)=>{setFormData({...formData,password:e.target.value})}}
                />
            </div>
            <div className="flex flex-col gap-4">
              <button
                className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                type="submit"
              >
                Sign In
              </button>
              <Link className="inline-block align-baseline font-bold text-xl text-blue-500 hover:text-blue-800" to="#">
                  Forgot Password?
                </Link>
                <button onClick={()=>{
                  dispatch(setPage('pricing'))
                  navigate("/")
                }}
                  className="bg-pink-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                  type="button">
                  Sign Up
                </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;

