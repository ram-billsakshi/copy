import React from 'react'
import DataTable from '../components/DataTable';

const columns = [
  { field: "id", headerName: "Sl No.", width: 80 },
  { field: "order_id", headerName: "Order Id", flex: 1 },
  { field: "transaction_id", headerName: "Transaction Id", flex: 1 },
  { field: "payment_by", headerName: "Payment By", flex: 1 },
  { field: "payment_mode", headerName: "Payment Mode", flex: 1 },
  { field: "amount", headerName: "Amount", flex: 1 },
  { field: "payment_at", headerName: "Payment At", flex: 1 },
];


const WalletList = () => {
    return (
        <div><DataTable columns={columns} endpoint={"/wallets"} type={"Wallet"} isAdd={false}/></div>
      );
}

export default WalletList