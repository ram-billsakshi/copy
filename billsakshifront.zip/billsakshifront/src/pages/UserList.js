import React, { useState } from "react";
import DataTable from "../components/DataTable";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { setUser } from "../redux/userSlice";
import { FiEdit } from "react-icons/fi";
import { FaWindowClose } from "react-icons/fa";
import { IoLockClosed } from "react-icons/io5";
import Popup from "../components/Popup";

const UserList = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [warn, setWarn] = useState(false);
  const [passwordData, setPasswordData] = useState({
    userId: "",
    password: "",
    confirmPassword: "",
  });
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Submission", passwordData);
    setIsOpen(false);
  };
  const handleWarn = (e) => {
    e.preventDefault();
    console.log("Submission");
    setWarn(false);
  };

  const columns = [
    { field: "id", headerName: "Sl No.", width: 80 },
    { field: "role", headerName: "Role", flex: 1, minWidth: 150 },
    { field: "unique_id", headerName: "Unique Id", flex: 1, minWidth: 100 },
    { field: "name", headerName: "Name", flex: 1, minWidth: 130 },
    { field: "contact", headerName: "Contact", flex: 1, minWidth: 100 },
    { field: "email", headerName: "Email", flex: 1, minWidth: 210 },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
      minWidth: 150,
      renderCell: (params) => (
        <button
          className={`${
            params.value ? "bg-red-500" : "bg-[#3b82f6]"
          } text-white leading-normal w-[100px] py-2 rounded-md`}
          onClick={() => alert(params.value)}
        >
          {params.value ? "Deactivate" : "Activate"}
        </button>
      ),
    },
    {
      field: "action",
      headerName: "Action",
      renderCell: (params) => (
        <div className="flex gap-2 h-full items-center text-[rgba(0,0,0,0.7)]">
          <FiEdit
            size={35}
            className="cursor-pointer"
            onClick={() => handleUserEdit(params)}
          />
          <FaWindowClose className="cursor-pointer" size={35} onClick={()=>setWarn(true)} />

          <IoLockClosed
            size={35}
            className="cursor-pointer"
            onClick={() => {
              setPasswordData({ ...passwordData, userId: params.id });
              setIsOpen(true);
            }}
          />
        </div>
      ),
    },
  ];
  const handleUserEdit = (user) => {
    console.log("role", user);
    dispatch(setUser(user.row));
    localStorage.setItem("userEdit", JSON.stringify(user.row));
    navigate(`/user/edit/${user.id}`);
  };

  return (
    <div className="w-full">
      <Popup
        isOpen={warn}
        setIsOpen={setWarn}
        handleSubmit={handleWarn}
        heading="Are you sure ?"
        submitText="OK"
      ></Popup>
      <Popup
        isOpen={isOpen}
        setIsOpen={setIsOpen}
        handleSubmit={handleSubmit}
        heading="Update Password"
        submitText="Update"
      >
        <div className="w-full flex flex-col gap-4 px-5 py-6">
          <div className="w-full flex justify-between items-center gap-4">
            <div className="font-semibold w-max">Password</div>
            <input
              onChange={(e) => {
                setPasswordData({ ...passwordData, password: e.target.value });
              }}
              type="password"
              className="border border-[rgba(0,0,0,0.1)] outline-none rounded-sm px-2 py-1.5"
            />
          </div>
          <div className="w-full flex justify-between items-center gap-4">
            <div className="font-semibold w-max">Confirm password</div>
            <input
              onChange={(e) => {
                setPasswordData({
                  ...passwordData,
                  confirmPassword: e.target.value,
                });
              }}
              type="text"
              className="border border-[rgba(0,0,0,0.1)] outline-none rounded-sm px-2 py-1.5"
            />
          </div>
        </div>
      </Popup>
      <DataTable
        columns={columns}
        endpoint={"/users"}
        type={"User"}
        redirect="/user/add"
      />
    </div>
  );
};

export default UserList;
