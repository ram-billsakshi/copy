import Header from "../components/Header"
import Contact from "./Contact"
import Pricing from "./Pricing"
import Feature from "./Feature"
import WhyChooseUs from "./WhyChooseUs"
import About from "./About"
import HeroSection from "../components/HeroSection"
import Footer from "../components/Footer"
import { Element } from 'react-scroll';


const Home = () => {


  return (
    <div>
      <Header />
          <HeroSection />
          <About />
      <WhyChooseUs />
          <Feature />
          <Pricing />
          <Contact />
      <Footer />
    </div>
  )
}

export default Home