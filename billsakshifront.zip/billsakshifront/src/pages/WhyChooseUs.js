import React from 'react'
import one from "../images/billsakshi/1.png"
import two from "../images/billsakshi/2.png"
import three from "../images/billsakshi/3.png"
import four from "../images/billsakshi/4.png"
import five from "../images/billsakshi/5.png"
import six from "../images/billsakshi/6.png"
import whyChooseUs from "../images/billsakshi/why_choose_us.png"


const WhyChooseUs = () => {
  return (
    <section>
              <h1 className="text-3xl lg:text-4xl font-medium text-center text-[#1034F1] my-10 mb-20">WHY C<span className="pb-5 border-b-4 border-[#FA33A0]">HO</span>OSE US</h1>
      <div className="flex flex-wrap">
        <div className="w-[100%] lg:w-[38%]">
          <div className="justify-between flex gap-2 p-10">
            <div>
              <h2 className="text-xl font-medium mb-2">Generate Invoices and Reports</h2>
              <p className="text-1">With the use of BILLSAKSHI as an end user you can create and monitor all of your bills and reports, track and control your ledger and expenses.</p>
            </div>
            <img src={one} alt="" className="w-17" />
          </div>
          <div className="justify-between flex gap-2 px-10">
            <div>
              <h2 className="text-xl font-medium mb-2">Automated Back-up System</h2>
              <p className="text-1">all the transaction reports and invoices are automatically saved.</p>
            </div>
            <img src={two} alt="" className="w-17" />
          </div>
          <div className="justify-between flex gap-2 p-10">
            <div>
              <h2 className="text-xl font-medium mb-2">Safe and Secure</h2>
              <p className="text-1">BILLSAKSHI brings in SSL, Firewall and 64 as well as 128 Bit encryption to keep the transactions and your data safe and secure.</p>
            </div>
            <img src={three} alt="" className="w-17" />
          </div>
        </div>
        <div className="w-[100%] lg:w-[24%] flex justify-center">
          <img src={whyChooseUs} alt="" className="w-[70%] max-w-[500px]" />
        </div>
        <div className="w-[100%] lg:w-[38%]">
          <div className="justify-between flex gap-10 p-10">
            <img src={four} alt="" className="w-17" />
            <div>
              <h2 className="text-xl font-medium mb-2">Faster Payments</h2>
              <p className="text-1">With Digital Payments Enabled for your customers, it will help you to offer multiple payments options and that will enhance the convenience.</p>
            </div>
          </div>
          <div className="justify-between flex gap-10 px-10">
            <img src={five} alt="" className="w-17" />
            <div>
              <h2 className="text-xl font-medium mb-2">Ease of Use</h2>
              <p className="text-1">You can use the application even if you basic knowledge of computer and create invoices for your daily sales and orders.</p>
            </div>
          </div>
          <div className="justify-between flex gap-10 p-10">
            <img src={six} alt="" className="w-17" />
            <div>
              <h2 className="text-xl font-medium mb-2">Client Support</h2>
              <p className="text-1">With BILLSAKSHI you get 10x7 Multilingual Voice Support and 24x7 Tech Support.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default WhyChooseUs