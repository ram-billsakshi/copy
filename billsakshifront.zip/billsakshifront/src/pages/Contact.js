import React from 'react'
import SmallCard from "../components/SmallCard"
import { MdOutlineLocationOn } from "react-icons/md";
import { MdOutlineEmail } from "react-icons/md";
import { FaPhoneVolume } from "react-icons/fa6";


const Contact = () => {
  return (
    <section id='contact' className="w-full w-[95%] lg:w-3/4 m-auto text-center  min-h-[calc(100vh-85.63px)] px-3 lg:px-6 pt-29">
    <h1 className="text-3xl lg:text-4xl font-medium text-center text-[#1034F1]">CON<span className="pb-5 border-b-4 border-[#FA33A0]">TAC</span>T US</h1>
    <br />
    <br />
    <p className="text-[#212529]">For any queries or comments just fill-up the form below and submit, a member from our team will review and contact you soon.</p>
    <div className="bg-[#f7f8f8] p-4 w-full mt-4 flex flex-wrap gap-5">
      <div className="w-[90%] lg:w-[45%] grow -200 py-6 shadow-lg bg-white">
        <SmallCard icon={<MdOutlineLocationOn size={35} color="#FA56AC" />} head1={"Our Address"} head2="BILLSAKSHI" />
      </div>
      <div className="w-[90%] lg:w-[45%]  grow flex flex-wrap gap-5">
        <div className="w-[90%] sm:w-[45%] grow py-6 shadow-lg bg-white">
          <SmallCard icon={<MdOutlineEmail size={30} color="#FA56AC" />} head1={"Email Us"} head2="support@billsakshi.in" />
        </div>
        <div className="w-[90%] sm:w-[45%] grow py-6 shadow-lg bg-white">
          <SmallCard icon={<FaPhoneVolume size={27} color="#FA56AC" />} head1={"Call Us"} head2="+91 8000611500" />
        </div>
      </div>
      <form className="flex flex-wrap gap-5 bg-white p-5 shadow-lg">
      <div className="w-[45%] grow">
        <input type="text" placeholder="Your Name" className="text-md py-3 px-5 w-full border border-[#ced4da] rounded-md outline-[#86b7fe]" />
      </div>
      <div className="w-[45%] grow"><input type="text" placeholder="Your Email" className="text-md py-3 px-5 w-full border border-[#ced4da] rounded-md outline-[#86b7fe]" /></div>
      <div className="w-[45%] grow"><input type="text" placeholder="Your Mobile" className="text-md py-3 px-5 w-full border border-[#ced4da] rounded-md outline-[#86b7fe]" /></div>
      <div className="w-[45%] grow"><input type="text" placeholder="Subject" className="text-md py-3 px-5 w-full border border-[#ced4da] rounded-md outline-[#86b7fe]" /></div>
      <div className="w-[90%] grow"><textarea placeholder="Message" rows={5} className="text-md py-3 px-5 w-full border border-[#ced4da] rounded-md outline-[#86b7fe]"></textarea></div>
      <button type="submit" className="font-bold rounded-full bg-[#0c10df] px-8 py-3 text-white m-auto">Send Message</button>
    </form>
    </div>
  </section>
  )
}

export default Contact