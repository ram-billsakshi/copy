import React from 'react'
import PagesHeader from '../components/PagesHeader/PagesHeader';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import InputFormTwoColumn from '../components/InputForm/InputFormTwoColumn';

const BulkAdd = () => {
    const rows = [
        {
            name: "Category",
            type: "dropdown",
            fields: ["Food", "HouseHold", "Beverages", "Mobile", "Toothbrush", "Bluetooth", "Epson l3210"],
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "Unit Description",
            type: "dropdown",
            fields:["Ltr", "ps", "ml", "g", "po", "box", "b", "cot"],
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "Sub Category",
            type: "email",
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "GST",
            type: "dropdown",
            fields:["First Slab (5%)", "Second Slab (12%)", "Third Slab (18%)", "Fourth Slab(28%)", "GST"],
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "File Upload",
            type: "file",
            isRequired: true,
            maxChar:null, 
            readonly: false
        }
    ]
   return (

    <div className='flex-1 max-h-150 border-2 border-gray shadow-1 m-4 bg-white'>
        <div className='border-b-2 border-bodydark'> <PagesHeader navigateTo={"/vendor/list"} heading={"Party Add"} button={"User List"}/></div>
        <div className='m-4'>
        <InputFormTwoColumn rows={rows}/>
        <button className='flex text-white bg-blue-600 rounded p-3 mx-auto'>Submit</button>  
        </div>
    </div>
);
}

export default BulkAdd