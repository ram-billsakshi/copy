import React, { useEffect, useState } from "react";
import PagesHeader from "../components/PagesHeader/PagesHeader";
import InputForm from "../components/InputForm/InputForm";
import { handleChange, stateData } from "../utils";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";

const SalesCustomerAdd = () => {
    const rows = [
        {
            label: "Name",
            type: "text",
            isRequired: true,
            maxChar: null,
            readonly: false,
            palceholder: "Name",
            name: "name",
        },
        {
            label: "GSTIN Number",
            type: "text",
            isRequired: true,
            maxChar: null,
            readonly: false,
            placeholder: "GSTIN Number",
            name: "gstNumber",
        },
        {
            label: "Email Id",
            type: "email",
            isRequired: true,
            maxChar: null,
            readonly: false,
            placeholder: "Email Id",
            name: "email_id",
        },
        {
            label: "Contact Number",
            type: "number",
            isRequired: true,
            maxChar: 10,
            readonly: false,
            placeholder: "Contact Number",
            name: "contact",
        },
        {
            label: "Country",
            type: "dropdown",
            fields: [
                "India (+91)",
                "United States (+1)",
                "China (+86)",
                "Indonesia (+62)",
                "Pakistan (+92)",
                "Brazil (+55)",
                "Nigeria (+234)",
                "Bangladesh (+880)",
                "Russia (+7)",
                "Mexico (+52)",
                "Japan (+81)",
                "Philippines (+63)",
                "Vietnam (+84)",
                "Ethiopia (+251)",
                "Egypt (+20)",
                "Germany (+49)",
                "Iran (+98)",
                "Turkey (+90)",
                "Democratic Republic of the Congo (+243)",
                "Thailand (+66)",
                "United Kingdom (+44)",
                "France (+33)",
                "Italy (+39)",
                "South Africa (+27)",
                "Tanzania (+255)",
                "Myanmar (+95)",
                "South Korea (+82)",
                "Colombia (+57)",
                "Kenya (+254)",
                "Spain (+34)",
                "Argentina (+54)",
                "Algeria (+213)",
                "Sudan (+249)",
                "Ukraine (+380)",
                "Uganda (+256)",
                "Iraq (+964)",
                "Poland (+48)",
                "Canada (+1)",
                "Morocco (+212)",
                "Saudi Arabia (+966)",
                "Uzbekistan (+998)",
                "Peru (+51)",
                "Malaysia (+60)",
                "Venezuela (+58)",
                "Nepal (+977)",
                "Ghana (+233)",
                "Yemen (+967)",
                "Afghanistan (+93)",
            ],
            isRequired: true,
            maxChar: null,
            readonly: false,
            placeholder: "Country",
            name: "country",
        },
        {
            label: "State",
            type: "dropdown",
            fields: [
                "Andhra Pradesh",
                "Arunachal Pradesh",
                "Assam",
                "Bihar",
                "Chhattisgarh",
                "Gujarat",
                "Haryana",
                "Himachal Pradesh",
                "Jammu and Kashmir",
                "Goa",
                "Jharkhand",
                "Karnataka",
                "Kerala",
                "Madhya Pradesh",
                "Maharashtra",
                "Manipur",
                "Meghalaya",
                "Mizoram",
                "Nagaland",
                "Odisha",
                "Punjab",
                "Rajasthan",
                "Sikkim",
                "Tamil Nadu",
                "Telangana",
                "Tripura",
                "Uttarakhand",
                "Uttar Pradesh",
                "West Bengal",
                "Andaman and Nicobar Islands",
                "Chandigarh",
                "Dadra and Nagar Haveli",
                "Daman and Diu",
                "Delhi",
                "Lakshadweep",
                "Puducherry",
            ],
            isRequired: true,
            maxChar: null,
            readonly: false,
            placeholder: "State",
            name: "state",
        },
        {
            label: "City",
            type: "text",
            isRequired: true,
            maxChar: null,
            readonly: false,
            placeholder: "City",
            name: "city",
        },
        {
            label: "Confirm Password",
            type: "password",
            isRequired: true,
            maxChar: null,
            readonly: false,
            placeholder: "Confirm Password",
            name: "confirmPassword",
        },
    ];
    const [data, setData] = useState(stateData(rows));
    const salesCustomerEdit = useSelector(state => state.saleCustomer.saleCustomerEdit) || JSON.parse(localStorage.getItem('salesCustomer'))
    const salesCustomerId = useParams()

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(data);
    };
    useEffect(()=>{
        console.log('salesCustomerEdit', salesCustomerEdit)
        if(salesCustomerId){
            setData({
                ...salesCustomerEdit
            })
        }
    }, [])

    return (
        <div className="bg-white shadow-1">
            <PagesHeader navigateTo={"/customer/list"} heading={"Customer Add"} button={"List"} />

            <form
                className="flex-1 p-3"
                onSubmit={handleSubmit}
            >
                <InputForm
                    rows={rows}
                    onChange={(e) => {
                        handleChange(e, setData);
                    }}
                    data={data}
                />
                <button
                    type="submit"
                    className="flex text-white bg-blue-600 rounded p-3 mx-auto"
                >
                    Submit
                </button>
            </form>
        </div>
    );
};

export default SalesCustomerAdd;
