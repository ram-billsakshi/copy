import React from 'react'
import DataTable from '../components/DataTable';
import { FiEdit } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { setSaleCustomerEdit } from '../redux/saleCustomerSlice';

const SalesCustomerList = () => {
    const columns = [
        { field: "id", headerName: "Sl No.", width: 80 },
        { field: "name", headerName: "Role Name", flex: 1, minWidth: 200 },
        { field: "customer_type", headerName: "Customer Type", flex: 1, minWidth: 200 },
        { field: "email_id", headerName: "Email Id", flex: 1, minWidth: 200 },
        { field: "address", headerName: "Address", flex: 1, minWidth: 200 },
        { 
          field: "status", 
          headerName: "Status", 
          flex: 1, 
          minWidth: 100,
          renderCell: (params) => (
              <button className={`${params.value?'bg-red-500':'bg-[#3b82f6]'} text-white leading-normal w-[100px] py-2 rounded-md`} onClick={() => alert(params.value)}>{params.value?'Deactivate':'Activate'}</button>
          ),
        },
        {
          field: "action",
          headerName: "Action",
          width: 100,
          renderCell: (params) => (
            <div className="flex h-full items-center">
              <FiEdit className="w-1/2 h-1/2 items-center cursor-pointer" onClick={() => handleRole(params)}/>  
              {/* <button className=" w-1/2 text-black bg-blue-400 items-center cursor-pointer" onClick={() => alert(params.id)}>Edit</button> */}
            </div>
          ),
        },
      ];
      const navigate = useNavigate()
      const dispatch = useDispatch()
      const handleRole = (sales) => {
        console.log(sales)
        localStorage.setItem('salesCustomer', JSON.stringify(sales.row) )
        navigate(`/customer/edit/${sales.id}`)
        dispatch(setSaleCustomerEdit(sales.row))
      }
    return ( 
        <div>
            <DataTable columns={columns} endpoint={"/customer"} type={"Customer"} redirect='/customer/add'/>
        </div>
      );
}

export default SalesCustomerList