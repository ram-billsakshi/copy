import React, { useEffect, useState } from "react";
import PagesHeader from "../components/PagesHeader/PagesHeader";
import InputForm from "../components/InputForm/InputForm";
import { handleChange, stateData } from "../utils";
import InputFormTwoColumn from "../components/InputForm/InputFormTwoColumn";
import { useParams } from "react-router-dom";
import { useSelector } from "react-redux";
const ExpensesDetailsAdd = () => {
  const rows = [
    {
      name: "expense_name",
      label: "Expenses Name",
      placeholder: "Expenses Name",
      type: "text",
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "paymentMode",
      label: "Payment Mode",
      placeholder: "Payment Mode",
      type: "text",
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "date",
      label: "Date",
      placeholder: "Date",
      type: "date",
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "totalExpenses",
      label: "Total Expenses",
      placeholder: "Total Expenses",
      type: "text",
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
  ];
  const rowsEdit = [{
        name: "expense_name",
        label: "Expenses Name",
        placeholder: "Expenses Name",
        type: "text",
        isRequired: true,
        maxChar: null,
        readonly: false,  
  }]
  const {expenseDetailsId} = useParams()
  const expenseEdit = useSelector(state => state.expenseDetail.expenseDetailEdit) || JSON.parse(localStorage.getItem('expenseDetails'))
  const [editPage, setEditPage] = useState(false)
  const [data, setData] = useState(stateData(rows));
  useEffect(()=>{
    console.log('expenseId', expenseDetailsId)
    console.log('expenseEdit', expenseEdit)
    if(expenseDetailsId){  
      console.log('in expense Id')
      setEditPage(true)
      setData({
        ...expenseEdit
      })
    }
  }, [])
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(data);
  };

  return (
    <div className="flex-1 border-2 border-gray shadow-1 bg-white">
      <PagesHeader
        navigateTo={"/expensesDetailsList"}
        heading={"Expense Details List"}
        button={"List"}
      />
      <form onSubmit={handleSubmit} className="p-5">
        {
          editPage === false ? <>
          <InputFormTwoColumn
          rows={rows}
          data={data}
          onChange={(e) => handleChange(e, setData)}
        />
        <button
          type="submit"
          className="flex text-white bg-blue-600 rounded p-3 mx-auto"
        >
          Submit
        </button>
          </> : <>
          <InputForm
          rows={rowsEdit}
          data={data}
          onChange={(e) => handleChange(e, setData)}
        />
        <button
          type="submit"
          className="flex text-white bg-blue-600 rounded p-3 mx-auto"
        >
          Submit
        </button>
          </>
        }
      </form>
    </div>
  );
};

export default ExpensesDetailsAdd;
