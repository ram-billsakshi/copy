import React, {useEffect, useState} from 'react'
import PagesHeader from '../components/PagesHeader/PagesHeader';
import InputForm from '../components/InputForm/InputForm';
import { handleChange, stateData } from '../utils';
import { useParams } from 'react-router-dom';

const UnitAdd = () => {
    const rows = [
        {
            label: "Unit Name",
            name: "unitName",
            placeholder: "Unit Name",
            type: "text",
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            label: "Short Name",
            name: "shortName",
            placeholder: "Short Name",
            type: "text",
            isRequired: true,
            maxChar:null, 
            readonly: false
        }
    ] 

    const [data, setData] = useState(stateData(rows))
    const unitEdit = 
    // useSelector(state => state?.vendor?.vendorEdit) || 
    JSON.parse(localStorage.unitEdit)
    
    const handleSubmit = (e) => {
        e.preventDefault()
        console.log(data);
    }
    const handleEdit = (e) => {
        e.preventDefault()
        console.log('edit')
    }
    const { unitId } = useParams()

    useEffect(()=>{
        const {unitName,shortName} = unitEdit
        if(unitId){
            setData({...data,unitName,shortName})
        }
    }, [])

   return (
            <div className='flex-1 bg-white'>
                <PagesHeader navigateTo={"/unit/list"} heading={"Gst Add"} button={"List"}/>
                <form className='p-5' onSubmit={unitId?handleEdit:handleSubmit}>
                    <InputForm rows={rows} onChange={(e)=> handleChange(e, setData)} data={data}/>
                    <button type="submit" className='flex text-white bg-blue-600 rounded p-3 mx-auto'>Submit</button>
                </form>
            </div>
);
}

export default UnitAdd