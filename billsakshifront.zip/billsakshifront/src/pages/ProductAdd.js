import React, { useEffect, useState } from "react";
import PagesHeader from "../components/PagesHeader/PagesHeader";
import Sidebar from "../components/Sidebar";
import Header from "../components/Header";
import InputForm from "../components/InputForm/InputForm";
import InputFormTwoColumn from "../components/InputForm/InputFormTwoColumn";
import { handleChange, stateData } from "../utils";
import { useParams } from "react-router-dom";
const rows = [
    {
      name: "barcode",
      label: "Barcode",
      placeholder: "Barcode",
      type: "text",
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "itemName",
      label: "Item Name",
      placeholder: "Enter Item Name",
      type: "text",
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "category",
      label: "Category",
      placeholder: "Category",
      type: "dropdown",
      fields: [
        "food",
        "household",
        "beverages",
        "mobile",
        "toothbrush",
        "bluetooth",
         "epsonL3210",
      ],
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "hsnSacCode",
      label: "HSN/SAC Code",
      placeholder: "Enter HSN/SAC Code",
      type: "text",
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "subCategory",
      label: "Sub Category",
      placeholder: "Enter Sub Category",
      type: "text",
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "buyingPrice",
      label: "Maximum Buying Price",
      placeholder: "Maximum Buying Price",
      type: "text",
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "unitDesc",
      label: "Unit Description",
      placeholder: "",
      type: "dropdown",
      fields: ["Ltr", "ps", "ml", "g", "po", "box", "b", "cot"],
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "gst",
      label: "GST",
      placeholder: "GST",
      type: "dropdown",
      fields: [
        "First Slab (5%)",
        "Second Slab (12%)",
        "Third Slab (18%)",
        "Fourth Slab(28%)",
        "GST",
      ],
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "batchNo",
      label: "Batch No.",
      placeholder: "Batch No.",
      type: "text",
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "mnfDate",
      label: "Manufacturing Date",
      placeholder: "Manufacturing Date",
      type: "date",
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "sellingPrice",
      label: "Maximum Selling Price",
      placeholder: "Maximum Selling Price",
      type: "text",
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "expDate",
      label: "Expiry Date",
      placeholder: "Expiry Date",
      type: "date",
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "desc",
      label: "Description",
      placeholder: "Description",
      type: "textArea",
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
    {
      name: "mnfBrand",
      label: "Manufacturing Brand",
      placeholder: "Manufacturing Brand",
      type: "text",
      isRequired: true,
      maxChar: null,
      readonly: false,
    },
  ];
const ProductAdd = () => {
    const [data,setData] = useState(stateData(rows))
    const productEdit = 
    // useSelector(state => state?.vendor?.vendorEdit) || 
    JSON.parse(localStorage.productEdit)
    
    const handleSubmit = (e) => {
        e.preventDefault()
        console.log(data);
    }
    const handleEdit = (e) => {
        e.preventDefault()
        console.log('edit')
    }
    const { productId } = useParams()

    useEffect(()=>{
        const {barcode,buyingPrice,category,extra,hsnSacCode,itemName,quantity,sellingPrice,subCategory,status} = productEdit

        if(productId){
            setData({...data,barcode,buyingPrice,category,extra,hsnSacCode,itemName,quantity,sellingPrice,subCategory,status:status==1?'active':'inactive'})
        }
    }, [])


  return (
    <div className="flex-1 shadow-1 bg-white" >
        <PagesHeader
          navigateTo={"/product/list"}
          heading={"Party Add"}
          button={"User List"}
        />
      <form className="p-5" onSubmit={productId?handleEdit:handleSubmit}>
        <InputFormTwoColumn rows={rows} data={data} onChange={(e) => handleChange(e,setData)} />
        <button type="submit" className="flex text-white bg-blue-600 rounded p-3 mx-auto">
          Submit
        </button>
      </form>
    </div>
  );
};

export default ProductAdd;
