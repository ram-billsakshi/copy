import React, {useState} from 'react'
import DataTable from '../components/DataTable';
import RenewPopup from '../components/Popup/RenewPopup';


const SubscriptionList = () => {
  const [popup, setPopup] = useState(false)

  const handlePopup = () => {
    setPopup(true)
    console.log('in popup')
    console.log(popup)
  }
  const columns = [
    { field: "name", headerName: "Subscription Name", flex: 1, minWidth: 200 },
    { field: "duration", headerName: "Duration", flex: 1,  minWidth: 200 },
    { field: "expiry On", headerName: "Expiry On", flex: 1, minWidth: 200 },
    { field: "status", headerName: "Status", flex: 1, minWidth: 200,
      renderCell: (params) => (
        <div className=' h-full'>
          <h1 className='inline font-bold'>Active</h1> 
          <button className='bg-blue-600 text-white rounded leading-normal ml-2 p-2' onClick={()=> handlePopup()}>Renew Now</button>
        </div>
    )
     },

  ]
    return (
        <div className=''>
          <DataTable columns={columns} endpoint={"/subscriptions"} type={"My Subscription"} isAdd={false}/>
          {popup && <RenewPopup setPopup={setPopup}>
            
          </RenewPopup> }
        </div>

      );
}

export default SubscriptionList