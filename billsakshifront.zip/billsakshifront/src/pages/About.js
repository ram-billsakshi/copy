import React from 'react'
import aboutImg from "../images/billsakshi/about.jpg"


const About = () => {
  return (
    <section id='about' className='min-h-[calc(100vh-85.63px)] px-3 lg:px-6 pt-29'>
      <h1 className="text-3xl lg:text-4xl font-medium text-center text-[#1034F1]">AB<span className="pb-5 border-b-4 border-[#FA33A0]">OUT</span> US</h1>
      <div className="w-full flex flex-wrap">
        <div className="w-[100%] lg:w-[50%] flex justify-center items-center flex-col py-10 lg:items-start lg:py-20 p-5">
          <img src={aboutImg} alt="" className="w-full" />
        </div>
        <div className="w-[100%]  lg:w-[50%] flex flex-col pt-18 p-5">
          <p className="text-justify leading-8">
            Welcome to Bill Sakshi, your trusted platform for managing your bills effortlessly. At Billsakshi, we understand the hassle and stress that comes with managing bills, whether it's for personal or business use. That's why we've created a user-friendly web application designed to simplify the billing process and streamline your financial management tasks. Our mission is to empower individuals and businesses alike to take control of their finances with ease. With Bill Sakshi, you can say goodbye to late payments, missed deadlines, and confusion over your expenses. Our intuitive interface and robust features make it simple to organize, track, and pay your bills on time, every time. Whether you're a busy professional juggling multiple accounts or a small business owner looking to optimize your financial operations, Billsakshi is here to support you every step of the way. Join our community today and experience the convenience of hassle-free bill management.
          </p>
        </div>
      </div>
    </section>
  )
}

export default About