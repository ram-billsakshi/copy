import React, { useEffect, useState } from 'react'
import PagesHeader from '../components/PagesHeader/PagesHeader';
import InputForm from '../components/InputForm/InputForm';
import { handleChange, stateData } from '../utils';
import { useParams } from 'react-router-dom';

const rows = [
    {
        name: "typeName",
        label:"Type Name",
        placeholder: "Type Name",
        type: "text",
        isRequired: true,
        maxChar:null, 
        readonly: false
    },
    {
        name: "icon",
        label:"Icon",
        placeholder: "Icon",
        type: "file",
        isRequired: true,
        maxChar:null, 
        readonly: false
    },
    {
        name: "status",
        label:"Status",
        placeholder: "Status",
        type: "radio",
        fields: [{ label: "Active", value: "active" }, { label: "Inactive", value: "inactive" }],
        isRequired: true,
        maxChar:null, 
        readonly: false
    },
    {
        name: "description",
        label:"Description",
        placeholder: "Description",
        type: "textArea",
        isRequired: true,
        maxChar:null, 
        readonly: false
    }
] 

const ProductCategoryAdd = () => {
    const [data,setData] = useState(stateData(rows))
    console.log(data,"tttt");

    const prodCategEdit = 
    // useSelector(state => state?.vendor?.vendorEdit) || 
    JSON.parse(localStorage.prodCategEdit)
    
    const handleSubmit = (e) => {
        e.preventDefault()
        console.log(data);
    }
    const handleEdit = (e) => {
        e.preventDefault()
        console.log('edit')
    }
    const { prodCategId } = useParams()

    useEffect(()=>{
        const {typeName,description,status} = prodCategEdit
        console.log(prodCategId,typeName,description,"try22");

        if(prodCategId){
            setData({...data,typeName,description,status:status==1?'active':'inactive'})
        }
    }, [])

   return (

    <div className='flex-1 shadow-1 bg-white'>
        <PagesHeader navigateTo={"/meta_type/list"} heading={"Meta Type Add"} button={"List"}/>
        <form className='p-5' onSubmit={handleSubmit}>
            <InputForm rows={rows} data={data} onChange={(e) => handleChange(e,setData)} />
            <button type="submit" className='flex text-white bg-blue-600 rounded p-3 mx-auto'>Submit</button>
        </form>
    </div>


);
}

export default ProductCategoryAdd