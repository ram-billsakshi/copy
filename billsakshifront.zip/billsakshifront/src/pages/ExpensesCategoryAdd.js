import React, { useEffect, useState } from 'react'
import PagesHeader from '../components/PagesHeader/PagesHeader';
import InputForm from '../components/InputForm/InputForm';
import { handleChange, stateData } from '../utils';
import { useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';

const ExpensesCategoryAdd = () => {
    const rows = [
        {
            name: "expense_name",
            label:"Expenses Name",
            placeholder:"Expenses Name",
            type: "text",
            isRequired: true,
            maxChar:null, 
            readonly: false
        }
    ] 
    
    const [data,setData] = useState(stateData(rows))
    const expenseCategoryEdit = useSelector(state => state.expenseCategory.expenseCategoryEdit) || JSON.parse(localStorage.getItem('expenseDetails'))
    const {expenseCategoryId} = useParams()

    const handleSubmit = (e) => {
        e.preventDefault()
        console.log(data);
    }
    useEffect(()=> {
        console.log('maanv', expenseCategoryId)
        console.log('mamamama', expenseCategoryEdit)
        if(expenseCategoryId) {
            setData({
                ...expenseCategoryEdit
            })
        }
    }, [])

   return (
            <div className='flex-1 border-2 border-gray shadow-1 m-4 bg-white'>
                <PagesHeader navigateTo={"/expensesCategoryList"} heading={expenseCategoryId ?  "Expense Name List" : "Expense Name Add"} button={"List"}/>
                <form onSubmit={handleSubmit} className='p-5'>
                    <InputForm rows={rows} data={data} onChange={(e) => handleChange(e,setData)} />
                    <button className='flex text-white bg-blue-600 rounded p-3 mx-auto'>Submit</button>
                </form>
            </div>
);
}

export default ExpensesCategoryAdd