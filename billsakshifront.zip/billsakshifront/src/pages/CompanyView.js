import React from 'react'
import ViewHeader from '../components/View/ViewHeader'
import CompanyInfoView from '../components/View/CompanyInfoView'

const CompanyView = () => {
    const buttonGroup = [
        {
            name: "Add",
            action: 'addPage',
            className: "text-white p-2 ml-3 rounded bg-red-500",
            navigate: '/company/add'
        },
        {
            name: "List",
            action: 'listPage',
            className: "text-white p-2 ml-3 rounded bg-red-500",
            navigate: '/company/list'
        },
    ]
    return (
        <div className="p-8 bg-white shadow-md rounded-lg">
            <div className='border-b pb-4 mb-4'>
                <ViewHeader buttonGroup={buttonGroup}/>
            </div>
            <CompanyInfoView/>
        </div>
    )
}

export default CompanyView