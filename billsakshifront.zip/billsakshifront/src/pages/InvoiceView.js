import React from 'react'
import ViewHeader from '../components/View/ViewHeader'
import View from '../components/View/View'

const InvoiceView = () => {
    const buttonGroup = [
        {
          name: "Add",
          action: 'addPage',
          className: "text-white p-2 ml-3 rounded bg-red-500",
          navigate: '/estimate/add'
        },
        {
          name: "Download",
          action: "download",
          className: "text-white p-2 ml-3 rounded bg-blue-500"
        },
        {
          name: "Print",
          action: "print",
          className: "text-white p-2 ml-3 rounded bg-green-500"
        },
        {
          name: "List",
          action: "ListPage",
          className: "text-white p-2 ml-3 rounded bg-yellow-500",
          navigate: "/estimate/list"
        },
        {
          name: "Thermal Print",
          action: "thermalPrint",
          className: "text-white p-2 ml-3 rounded bg-bodydark"
        }
      ]
      return (
        <div className="p-8 bg-white shadow-md rounded-lg">
          <div className='border-b pb-4 mb-4'>
            <ViewHeader heading={"Estimate Detail"} buttonGroup={buttonGroup}/>
          </div>
          <View />
        </div>
      )
}

export default InvoiceView