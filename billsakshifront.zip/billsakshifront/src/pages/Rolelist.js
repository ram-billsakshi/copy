import React from "react";
import DataTable from "../components/DataTable";
import { FiEdit } from "react-icons/fi";
import { setRole } from "../redux/roleSlice";
import { useDispatch } from "react-redux";
import { Link, useNavigate } from "react-router-dom";


const Rolelist = () => {
  const columns = [
    { field: "id", headerName: "Sl No.", width: 80 },
    { field: "name", headerName: "Role Name", flex: 1, minWidth: 200 },
    { field: "note", headerName: "Note", flex: 1, minWidth: 200 },
    { 
      field: "status", 
      headerName: "Status", 
      flex: 1, 
      minWidth: 100,
      renderCell: (params) => (
          <button className={`${params.value?'bg-red-500':'bg-[#3b82f6]'} text-white leading-normal w-[100px] py-2 rounded-md`} onClick={() => alert(params.value)}>{params.value?'Deactivate':'Activate'}</button>
      ),
    },
    {
      field: "action",
      headerName: "Action",
      width: 100,
      renderCell: (params) => (
        <div className="flex h-full items-center">
          <FiEdit className="w-1/2 h-1/2 items-center cursor-pointer" onClick={() => handleRole(params)}/>  
          {/* <button className=" w-1/2 text-black bg-blue-400 items-center cursor-pointer" onClick={() => alert(params.id)}>Edit</button> */}
        </div>
      ),
    },
  ];

  const dispatch = useDispatch()
  const navigate = useNavigate()

  const handleRole = (role) => {
    console.log('role', role)
    dispatch(setRole(role.row))
    localStorage.setItem('role', JSON.stringify(role.row))
    navigate(`/role/edit/${role.id}`)
  }
  return (
    <div className="shadow-md max-h-150 flex-1">
      <DataTable columns={columns} endpoint={"/roles"} type={"Role"} redirect='/role/add'/>
    </div>
  );
};

export default Rolelist;
