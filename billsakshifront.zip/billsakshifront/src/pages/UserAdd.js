import React, { useEffect, useState } from 'react'
import PagesHeader from '../components/PagesHeader/PagesHeader';
import InputForm from '../components/InputForm/InputForm';
import { handleChange, stateData } from '../utils';
import { useParams } from 'react-router-dom';
import { useSelector } from 'react-redux';
const rows = [
    {
        name: "name",
        label: "Name",
        placeholder:'Enter Name',
        type: "text",
        isRequired: true,
        maxChar:null, 
        readonly: false,
    },
    {
        name: "email",
        label: "EmailId",
        placeholder:'Enter Email Id',
        type: "email",
        isRequired: true,
        maxChar:null, 
        readonly: false,
    },
    {
        name: "contact",
        label: "Contact",
        placeholder:'Contact',
        type: "text",
        isRequired: true,
        maxChar:10 
    },
    {
        name: "role",
        label: "Role",
        placeholder:'',
        type: "text",
        isRequired: true,
        maxChar:null, 
        readonly: false,
    },
    {
        name: "password",
        label: "Password",
        placeholder:'Enter Password',
        type: "password",
        isRequired: true,
        maxChar:null, 
        readonly: false,
    },
    {
        name: "confirmPassword",
        label: "Confirm Password",
        placeholder:'Confirm Password',
        type: "password",
        isRequired: true,
        maxChar:null, 
        readonly: false,
    }
] 
const UserAdd = () => {

    const [data,setData] = useState(stateData(rows))
    const userEdit = 
    useSelector(state => state?.role?.roleEdit) || 
    JSON.parse(localStorage.userEdit)
    
    const handleSubmit = (e) => {
        e.preventDefault()
        console.log(data);
    }
    const handleEdit = (e) => {
        e.preventDefault()
        console.log('edit')
    }
    const { userId } = useParams()

    useEffect(()=>{
        const {name,email,contact,role,password} = userEdit
        if(userId){
            setData({...data,name, email,contact,role,password})
        }
    }, [])

   return (

            <div className='flex-1 shadow-1 bg-white'>
                <PagesHeader navigateTo={"/user/list"} heading={"Add User"} button={"User List"}/>
                <form className='p-5'  onSubmit={userId ? handleEdit : handleSubmit}>
                    <InputForm rows={rows} data={data} onChange={(e) => handleChange(e,setData)} />
                    <button type='submit' className='text-white bg-blue-600 px-4 py-2 mx-auto block mb-3'>Add</button>
                </form>
            </div>
);
}

export default UserAdd