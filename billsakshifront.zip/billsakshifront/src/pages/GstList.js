import React, { useState } from 'react'
import DataTable from '../components/DataTable'
import { FaWindowClose } from 'react-icons/fa';
import { FiEdit } from 'react-icons/fi';
import Popup from '../components/Popup';
import { useNavigate } from 'react-router-dom';

const GstList = () => {
  const [warn, setWarn] = useState(false);
  const navigate = useNavigate()

  const columns = [
    { field: "id", headerName: "Sl No.", width: 80 },
    { field: "gstName", headerName: "GST Name", flex:1 },
    { field: "gstValue", headerName: "GST Value", flex:1 },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
      minWidth: 150,
      renderCell: (params) => (
        <button
          className={`${
            params.value ? "bg-red-500" : "bg-[#3b82f6]"
          } text-white leading-normal w-[100px] py-2 rounded-md`}
          onClick={() => alert(params.value)}
        >
          {params.value ? "Deactivate" : "Activate"}
        </button>
      ),
    },
    {
      field: "action",
      headerName: "Action",
      renderCell: (params) => (
        <div className="flex gap-2 h-full items-center text-[rgba(0,0,0,0.7)]">
          <FiEdit
            size={35}
            className="cursor-pointer"
            onClick={() => handleGstEdit(params)}
          />
          <FaWindowClose className="cursor-pointer" size={35} onClick={()=>setWarn(true)} />
        </div>
      ),
    }
  ]

  const handleGstEdit = (gst) => {
    console.log("gst", gst);
    // dispatch(setVendor(vendor.row));
    localStorage.setItem("gstEdit", JSON.stringify(gst.row));
    navigate(`/gst/edit/${gst.id}`);
  }
  const handleWarn = (e) => {
    e.preventDefault();
    console.log("Submission");
    setWarn(false);
  };

  return (
    <div className='bg-white w-full'>
                <Popup
        isOpen={warn}
        setIsOpen={setWarn}
        handleSubmit={handleWarn}
        heading="Are you sure ?"
        submitText="OK"
      ></Popup>
      <DataTable endpoint={"/gst"} columns={columns} type={'GST'} redirect='/gst/add'/>
    </div>
  )
}

export default GstList