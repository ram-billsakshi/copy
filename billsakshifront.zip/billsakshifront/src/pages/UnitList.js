import React, { useState } from "react";
import Header from "../components/Header";
import Dropdown from "../components/Dropdowns/Dropdown";
import EnhancedTable from "../components/Table/FilterTable";
import SearchWithCalendar from "../components/Search/CalenderSearch";
import Sidebar from "../components/Sidebar";
import PagesHeader from "../components/PagesHeader/PagesHeader";
import Buttons from "../components/ButtonsInPages/Buttons";
import DataTable from "../components/DataTable";
import { FiEdit } from "react-icons/fi";
import { FaWindowClose } from "react-icons/fa";
import Popup from "../components/Popup";
import { useNavigate } from "react-router-dom";

const UnitList = () => {
  const [warn, setWarn] = useState(false);
  const navigate = useNavigate();

  const columns = [
    { field: "id", headerName: "Sl No.", width: 80 },
    { field: "unitName", headerName: "Unit Name", flex: 1 },
    { field: "shortName", headerName: "Short Name", flex: 1 },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
      minWidth: 150,
      renderCell: (params) => (
        <button
          className={`${
            params.value ? "bg-red-500" : "bg-[#3b82f6]"
          } text-white leading-normal w-[100px] py-2 rounded-md`}
          onClick={() => alert(params.value)}
        >
          {params.value ? "Deactivate" : "Activate"}
        </button>
      ),
    },
    {
      field: "action",
      headerName: "Action",
      renderCell: (params) => (
        <div className="flex gap-2 h-full items-center text-[rgba(0,0,0,0.7)]">
          <FiEdit
            size={35}
            className="cursor-pointer"
            onClick={() => handleUnitEdit(params)}
          />
          <FaWindowClose
            className="cursor-pointer"
            size={35}
            onClick={() => setWarn(true)}
          />
        </div>
      ),
    },
  ];

  const handleUnitEdit = (unit) => {
    console.log("gst", unit);
    // dispatch(setVendor(vendor.row));
    localStorage.setItem("unitEdit", JSON.stringify(unit.row));
    navigate(`/unit/edit/${unit.id}`);
  };
  const handleWarn = (e) => {
    e.preventDefault();
    console.log("Submission");
    setWarn(false);
  };

  return (
    <div className="w-full">
      <Popup
        isOpen={warn}
        setIsOpen={setWarn}
        handleSubmit={handleWarn}
        heading="Are you sure ?"
        submitText="OK"
      ></Popup>
      <DataTable
        columns={columns}
        endpoint={"/units"}
        type={"Unit"}
        redirect="/unit/add"
      />
    </div>
  );
};

export default UnitList;
