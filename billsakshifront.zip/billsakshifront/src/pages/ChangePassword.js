import React, { useState } from "react";
import PagesHeader from "../components/PagesHeader/PagesHeader";
import InputForm from "../components/InputForm/InputForm";
import { handleChange, stateData } from "../utils";

const rows = [
  {
    name: "oldPassword",
    label: "Old Password",
    placeholder: "Old Password",
    type: "password",
    isRequired: true,
    maxChar: null,
    readonly: false,
  },
  {
    name: "newPassword",
    label: "New Password",
    placeholder: "New Password",
    type: "password",
    isRequired: true,
    maxChar: null,
    readonly: false,
  },
  {
    name: "confirmPassword",
    label: "Confirm Password",
    placeholder: "Confirm Password",
    type: "password",
    isRequired: true,
    maxChar: null,
    readonly: false,
  },
];
const ChangePassword = () => {
  const [data, setData] = useState(stateData(rows));
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(data);
  };

  return (
    <div className="flex-1 border-2 border-gray shadow-1 bg-white">
      <PagesHeader heading={"Change Password"} />
      <form onSubmit={handleSubmit} className="p-5">
        <InputForm
          rows={rows}
          data={data}
          onChange={(e) => handleChange(e, setData)}
        />
        <button
          type="submit"
          className="flex text-white bg-blue-600 rounded p-3 mx-auto"
        >
          Submit
        </button>
      </form>
    </div>
  );
};

export default ChangePassword;
