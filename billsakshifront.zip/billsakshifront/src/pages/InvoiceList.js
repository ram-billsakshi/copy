import React from 'react'
import DataTable from '../components/DataTable'
import { FiEdit } from 'react-icons/fi'
import { MdDelete } from 'react-icons/md'
import { FaEye } from 'react-icons/fa'
import { useNavigate } from 'react-router-dom'

const InvoiceList = () => {
  const navigate = useNavigate()

  const columns = [
    { field: "id", headerName: "Sl No.", width: 80 },
    { field: "estimate_number", headerName: "Estimate Number", flex: 1, minWidth: 200 },
    { field: "issue_date", headerName: "Issue Date", flex: 1, minWidth: 200 },
    { field: "final_amount", headerName: "Final Amount", flex: 1, minWidth: 200 },
    { 
      field: "status", 
      headerName: "Status", 
      flex: 1, 
      minWidth: 100,
      renderCell: (params) => (
          <button className={`${params.value?'bg-red-500':'bg-[#3b82f6]'} text-white leading-normal w-[100px] py-2 rounded-md`} onClick={() => alert(params.value)}>{params.value?'Deactivate':'Activate'}</button>
      ),
    },
    {
      field: "action",
      headerName: "Action",
      width: 100,
      renderCell: (params) => (
        <div className="flex h-full items-center">
          <FiEdit className="w-1/2 h-1/2 items-center cursor-pointer" onClick={() => handleRole(params)}/>  
          <MdDelete className="w-1/2 h-1/2 items-center cursor-pointer" onClick={() => alert(params.id)} />
          <FaEye className="w-1/2 h-1/2 items-center cursor-pointer" onClick={() => handleEyeButton(params)} />
          {/* <button className=" w-1/2 text-black bg-blue-400 items-center cursor-pointer" onClick={() => alert(params.id)}>Edit</button> */}
        </div>
      ),
    },
  ]
  const handleRole = (estimate) => {
    console.log(estimate)
  }
  const handleEyeButton = () => {
    navigate('/invoice/view')
  }

  return (
    <div className='w-full'>
        <DataTable endpoint={'/invoice'} columns={columns} type={'Invoice'} redirect='/invoice/add' />
    </div>
  )
}

export default InvoiceList