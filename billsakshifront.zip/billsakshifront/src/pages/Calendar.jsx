import React, { useState } from "react";
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, addMonths, subMonths, addWeeks, subWeeks, addDays, subDays, eachDayOfInterval } from 'date-fns';

const Calendar = () => {
  const data = []
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState('month'); // 'month', 'week', 'day'

  const handlePrev = () => {
    if (view === 'month') {
      setCurrentDate(subMonths(currentDate, 1));
    } else if (view === 'week') {
      setCurrentDate(subWeeks(currentDate, 1));
    } else {
      setCurrentDate(subDays(currentDate, 1));
    }
  };

  const handleNext = () => {
    if (view === 'month') {
      setCurrentDate(addMonths(currentDate, 1));
    } else if (view === 'week') {
      setCurrentDate(addWeeks(currentDate, 1));
    } else {
      setCurrentDate(addDays(currentDate, 1));
    }
  };

  const renderDays = () => {
    if (view === 'month') {
      const start = startOfMonth(currentDate);
      const end = endOfMonth(currentDate);
      return eachDayOfInterval({ start, end });
    } else if (view === 'week') {
      const start = startOfWeek(currentDate, { weekStartsOn: 0 });
      const end = endOfWeek(currentDate, { weekStartsOn: 0 });
      return eachDayOfInterval({ start, end });
    } else {
      return [currentDate];
    }
  };

  const renderCells = () => {
    const days = renderDays();
    const weeks = [];

    if (view === 'month' || view === 'week') {
      for (let i = 0; i < days.length; i += 7) {
        weeks.push(days.slice(i, i + 7));
      }
    } else {
      weeks.push(days);
    }

    return weeks.map((week, weekIndex) => (
      <tr key={weekIndex} className="grid grid-cols-7">
        {week.map((day, dayIndex) => {
          const dayData = data?.find(d => format(new Date(d.date), 'yyyy-MM-dd') === format(day, 'yyyy-MM-dd'));
          return (
            <td 
              key={dayIndex} 
              className="ease relative h-16 cursor-pointer border border-stroke p-1 transition duration-500 hover:bg-gray dark:border-strokedark dark:hover:bg-meta-4 md:h-20 md:p-2 xl:h-25 xl:p-1.5"
            >
              <span className="font-medium text-black dark:text-white">{format(day, 'd')}</span>
              {dayData?.event && (
                <div className="group h-16 w-full flex-grow cursor-pointer py-1 md:h-20 xl:h-19">
                  <span className="group-hover:text-primary md:hidden">More</span>
                  <div className="event invisible absolute left-2 z-99 mb-1 flex w-[200%] flex-col rounded-sm border-l-[3px] border-primary bg-gray px-3 py-1 text-left opacity-0 group-hover:visible group-hover:opacity-100 dark:bg-meta-4 md:visible md:w-[190%] md:opacity-100">
                    <span className="event-name text-sm font-semibold text-black dark:text-white">{dayData.event.name}</span>
                    <span className="time text-sm font-medium text-black dark:text-white">{dayData.event.time}</span>
                  </div>
                </div>
              )}
            </td>
          );
        })}
      </tr>
    ));
  };

  return (
    <div className="w-full max-w-full rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark">
      <h2 className="text-center my-2 font-semibold">Sales Due Calendar</h2>
      <div className="flex justify-between items-center mb-4">
        <div>
          <button onClick={handlePrev} className="px-4 py-2 bg-primary text-white rounded">Prev</button>
          <button onClick={handleNext} className="ml-2 px-4 py-2 bg-primary text-white rounded">Next</button>
        </div>
        <div>
          <button onClick={() => setView('month')} className={`px-4 py-2 ${view === 'month' ? 'bg-primary text-white' : 'bg-gray-200 text-black'} rounded`}>Month</button>
          <button onClick={() => setView('week')} className={`ml-2 px-4 py-2 ${view === 'week' ? 'bg-primary text-white' : 'bg-gray-200 text-black'} rounded`}>Week</button>
          <button onClick={() => setView('day')} className={`ml-2 px-4 py-2 ${view === 'day' ? 'bg-primary text-white' : 'bg-gray-200 text-black'} rounded`}>Day</button>
        </div>
      </div>
      <table className="w-full">
        <thead>
          <tr className="grid grid-cols-7 rounded-t-sm bg-primary text-white">
            {['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']?.map((day, index) => (
              <th key={index} className="flex h-10 items-center justify-center p-1 text-xs font-semibold sm:text-base xl:p-1.5">
                <span className="hidden lg:block">{day}</span>
                <span className="block lg:hidden">{day.slice(0, 3)}</span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {renderCells()}
        </tbody>
      </table>
    </div>
  );
};

export default Calendar;
