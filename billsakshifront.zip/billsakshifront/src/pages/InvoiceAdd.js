import React from 'react'
import InputFormMultiple from '../components/InputForm/InputFormMultiple'
import PagesHeader from '../components/PagesHeader/PagesHeader'


const InvoiceAdd = () => {
    const rows = [
        {
            name: "Customer Name",
            type:"dropdown",
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "Estimate",
            type: "type",
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "Estimate Date",
            type: "date",
            isRequired: true,
            maxChar:null, 
            readonly: false
        }
    ]
    const itemRows = [
        {
            name: "Item",
            type: "dropdown",
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "Quantity",
            type: "text",
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "Rate",
            type: "text",
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "Sgst(%)",
            type: "text",
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "Cgst(%)",
            type: "text",
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "Stocks",
            type: "text",
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "Igst(%)",
            type: "text",
            isRequired: true,
            maxChar:null, 
            readonly: false
        },
        {
            name: "Total Amount",
            type: "text",
            isRequired: true,
            maxChar:null, 
            readonly: false
        }

    ]
  return (
    <div className='flex-1 border-gray shadow-1 bg-white'>
        <PagesHeader navigateTo={"/estimate/list"} heading={"Estimate Add"} button={"List"}/>
        <div className="p-5">
            <InputFormMultiple rows={rows} itemsRow={itemRows} addProductThroughBarCode={true} paymentTypeOptions={true} typeInvoice={true}/>
        </div>
    </div>
  )
}

export default InvoiceAdd