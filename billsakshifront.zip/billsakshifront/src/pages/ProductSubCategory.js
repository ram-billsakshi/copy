import React, { useEffect, useState } from 'react'
import PagesHeader from '../components/PagesHeader/PagesHeader';
import InputForm from '../components/InputForm/InputForm';
import { handleChange, stateData } from '../utils';
import { useParams } from 'react-router-dom';

const rows = [
    {
        name: "typeName",
        label: "Type Name",
        placeholder: "Enter Type Name",
        type: "text",
        isRequired: true,
        maxChar:null, 
        readonly: false
    },
    {
        name: "labelName",
        label: "Label Name",
        placeholder: "Enter Label Name",
        type: "text",
        isRequired: true,
        maxChar:null, 
        readonly: false
    },
    {
        name: "icon",
        label: "Icon",
        placeholder: "Icon",
        type: "file",
        isRequired: true,
        maxChar:null, 
        readonly: false
    },
    {
        name: "status",
        label: "Status",
        placeholder: "Status",
        type: "radio",
        fields: [{ label: "Active", value: "active" }, { label: "Inactive", value: "inactive" }],
        isRequired: true,
        maxChar:null, 
        readonly: false
    },
    {
        name: "description",
        label: "Description",
        placeholder: "Enter Description",
        type: "textArea",
        isRequired: true,
        maxChar:null, 
        readonly: false
    }
] 

const ProductSubCategoryAdd = () => {

    const [data,setData] = useState(stateData(rows))
    const subCategEdit = 
    // useSelector(state => state?.vendor?.vendorEdit) || 
    JSON.parse(localStorage.subCategEdit)
    
    const handleSubmit = (e) => {
        e.preventDefault()
        console.log(data);
    }
    const handleEdit = (e) => {
        e.preventDefault()
        console.log('edit')
    }
    const { subCategId } = useParams()

    useEffect(()=>{
        const {typeName,labelName,description,status} = subCategEdit
        console.log(subCategId,typeName,description,"try22");

        if(subCategId){
            setData({...data,typeName,labelName,description,status:status==1?'active':'inactive'})
        }
    }, [])

   return (
    <div className='flex-1 shadow-1 bg-white'>
            <PagesHeader navigateTo={"/sub-category/list"} heading={"Sub Category"} button={"List"}/>
        <form className='p-5' onSubmit={subCategId?handleEdit:handleSubmit}>
            <InputForm rows={rows} data={data} onChange={(e) => handleChange(e,setData)} />
            <button type='submit' className='flex text-white bg-blue-600 rounded p-3 mx-auto'>Submit</button>
        </form>
    </div>
);
}

export default ProductSubCategoryAdd