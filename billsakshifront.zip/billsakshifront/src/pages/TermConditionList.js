import React from 'react'
import DataTable from '../components/DataTable'
import { FiEdit } from 'react-icons/fi'; 
import { MdOutlineDelete } from "react-icons/md";
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { setTerms } from '../redux/termsSlice';

const TermConditionList = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const columns = [
    { field: "id", headerName: "Sl No.", width: 80, flex: 1 },
    { field: "messages", headerName: "Messages", flex: 1, 
      renderCell: (params) => ( 
        <div className='whitespace-normal break-words w-full'>
            {params.value}
        </div>
      )},
    { 
      field: "status", 
      headerName: "Status", 
      flex: 1, 
      minWidth: 100,
      renderCell: (params) => (
          <button className={`${params.value?'bg-red-500':'bg-[#3b82f6]'} text-white leading-normal w-[100px] py-2 rounded-md`} onClick={() => alert(params.value)}>{params.value?'Deactivate':'Activate'}</button>
      ),
    },
    {
      field: "action",
      headerName: "Action",
      width: 100,
      renderCell: (params) => (
        <div className="flex h-full items-center">
          <FiEdit className="w-1/2 h-1/2 items-center cursor-pointer" onClick={() => handleRole(params)}/>
          <MdOutlineDelete className="w-1/2 h-1/2 items-center cursor-pointer" onClick={() => handleRole(params)}/>
        </div>
      ),
    },
  ]
  const handleRole = (terms) => {
    console.log('roleUpdates', terms)
    localStorage.setItem('termsAndCondition', JSON.stringify(terms.row))
    dispatch(setTerms(terms.row))
    navigate(`/term-condition/edit/${terms.id}`)
  }
  
  return (
    <div className='w-full'>
        <DataTable columns={columns} endpoint={"/terms_condition"} type={"Term Condition"} redirect='/term-condition/add' isHead={false}/>
    </div>
  )
}

export default TermConditionList