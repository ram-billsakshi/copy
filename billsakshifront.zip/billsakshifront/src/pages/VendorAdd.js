import React, { useEffect, useState } from 'react';
import PagesHeader from '../components/PagesHeader/PagesHeader';
import InputFormTwoColumn from '../components/InputForm/InputFormTwoColumn';
import { handleChange, stateData } from '../utils';
import { useParams } from 'react-router-dom';

const VendorAdd = () => {
    const rows = [
        {
            label: "Name",
            type: "text",
            isRequired: true,
            placeholder: "Name",
            maxChar: null,
            readOnly: false,
            name: "name"
        },
        {
            label: "Contact Number",
            type: "number",
            isRequired: true,
            placeholder: "Contact Number",
            maxChar: 10,
            readOnly: false,
            name: "contact"
        },
        {
            label: "Email Id",
            type: "email",
            isRequired: true,
            placeholder: "Email Id",
            maxChar: null,
            readOnly: false,
            name: "email"
        },
        {
            label: "GST No",
            type: "text",
            isRequired: true,
            placeholder: "GST No.",
            maxChar: null,
            readOnly: false,
            name: "gst"
        },
        {
            label: "IFSC",
            type: "text",
            isRequired: true,
            placeholder: "IFSC",
            maxChar: null,
            readOnly: false,
            name: "ifsc"
        },
        {
            label: "Account No",
            type: "text",
            isRequired: true,
            placeholder: "Account No.",
            maxChar: null,
            readOnly: false,
            name: "account"
        },
        {
            label: "Address",
            type: "textArea",
            isRequired: true,
            placeholder: "Address",
            maxChar: null,
            readOnly: false,
            name: "address"
        },
        {
            label: "Status",
            type: "radio",
            fields: [{ label: "Active", value: "active" }, { label: "Inactive", value: "inactive" }],
            isRequired: true,
            placeholder: "Status",
            maxChar: null,
            readOnly: false,
            name: "status"
        }
    ];
    const [data, setData] = useState(stateData(rows));

    console.log(data,"check101");

    const vendorEdit = 
    // useSelector(state => state?.vendor?.vendorEdit) || 
    JSON.parse(localStorage.vendorEdit)
    
    const handleSubmit = (e) => {
        e.preventDefault()
        console.log(data);
    }
    const handleEdit = (e) => {
        e.preventDefault()
        console.log('edit')
    }
    const { vendorId } = useParams()

    useEffect(()=>{
        const {name,email,contact,gst,ifsc,address,account,status} = vendorEdit
        if(vendorId){
            setData({...data,name, email,contact,gst,ifsc,address,account,status:status==1?'active':'inactive'})
        }
    }, [])

    return (
        <div className='flex-1 shadow-1 bg-white'>
            <PagesHeader navigateTo={"/vendor/list"} heading={"Party Add"} button={"User List"} />
            <form className='p-5' onSubmit={vendorId ? handleEdit : handleSubmit}>
                <InputFormTwoColumn rows={rows} onChange={(e) => handleChange(e, setData)} data={data} />
                <button className='flex text-white bg-blue-600 rounded p-3 mx-auto'>Submit</button>
            </form>
        </div>
    );
};

export default VendorAdd;
