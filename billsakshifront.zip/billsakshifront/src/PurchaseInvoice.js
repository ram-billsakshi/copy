import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import BtnPrimary from "./components/BtnPrimary";
import { RiDeleteBinLine } from "react-icons/ri";
import useGetData from "./hooks/useGetData";
const pData = [
  {
    id: 1,
    itemDetails: "Wheat",
    quantity: 2,
    showQty: 1,
    unit: "kg",
    stock: 8,
    sellingPrice: 150,
    basePrice: 100,
    gst: 5,
    checked: false,
  },
  {
    id: 2,
    itemDetails: "sugar",
    quantity: 2,
    showQty: 1,
    unit: "kg",
    stock: 10,
    sellingPrice: 150,
    basePrice: 100,
    gst: 5,
    checked: false,
  },
];
const PurchaseInvoice = () => {
  const [data, setdata] = useState(pData);
  const [invoiceNumber, setInvoiceNumber] = useState("PNV26620243872");
  const [data2, setData2] = useState([]);
  const [billData, setBillData] = useState({
    subtotal: 0,
    gstAmount: 0,
    totalAmount: 0,
  });
  const { data: vendors } = useGetData("vendors");
  const [vendor, setVendor] = useState({});
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [duedate, setDuedate] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  const handleVendorChange = (e) => {
    const vendor = JSON.parse(e.target.value);
    setVendor(vendor);
  };

  const handleItemSelect = () => {
    const toBeSelectedData = data.filter((item) => item.checked);
    setData2(toBeSelectedData);
    const temBillData = toBeSelectedData.reduce(
      (acc, item) => {
        const showQty = parseInt(item.showQty, 10);
        const actualPrice = item.basePrice / (1 + item.gst / 100);
        const subtotal = actualPrice * showQty;
        const gstAmount = subtotal * (item.gst / 100);
        const totalAmount = subtotal + gstAmount;
        acc.subtotal += subtotal;
        acc.gstAmount += gstAmount;
        acc.totalAmount += totalAmount;

        return acc;
      },
      { subtotal: 0, gstAmount: 0, totalAmount: 0 }
    );

    setBillData(temBillData);
    setIsOpen(false)
  };

  const handleRemove = (id) => {
    if (data2.length == 1) {
      setBillData({ subtotal: 0, gstAmount: 0, totalAmount: 0 });
    }
    setData2(data2?.filter((item) => item.id != id));
  };

  const handleCheck = (id) => {
    const temp = [...data];
    const modifiedData = temp.map((item) => {
      if (item.id == id) {
        return { ...item, checked: !item.checked };
      }
      return item;
    });
    setdata(modifiedData);
  };
  const handleQtyChange = (e, id) => {
    const temp = [...data];
    const modifiedData = temp.map((item) => {
      if (item.id == id) {
        return { ...item, showQty: e.target.value };
      }
      return item;
    });
    setdata(modifiedData);
  };

  const handleSearch = (e) => {
    const searchTerm = e.target.value;
    if (searchTerm) {
      setdata(
        data.filter((item) =>
          item.itemDetails.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
    } else {
      setdata(pData);
    }
  };
  
  return (
    <div className="flex-1 shadow-1 bg-white">
      <div className="flex justify-between p-4 pb-3 border-b border-[rgba(0,0,0,0.1)]">
        <h2>Purchase Invoice Add</h2>
        <BtnPrimary text={"List"} route={'/purchase-invoice/list'} />
      </div>
      <div className="p-4 border-b border-[rgba(0,0,0,0.1)]">
        <div className="flex flex-wrap gap-2">
          <div className="w-full lg:w-[45%] grow flex flex-col gap-3">
            <div className="flex flex-col gap-1">
              <label className="text-sm">Vendor</label>
              <select
                onChange={handleVendorChange}
                className="w-full max-w-[500px] text-sm outline-none border border-[rgba(0,0,0,0.1)] bg-white px-1 py-2.5 rounded-md"
              >
                <option value={"{}"}>select</option>
                {vendors?.map((item, index) => (
                  <option key={index} value={JSON.stringify(item)}>
                    {item.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm">Invoice</label>
              <input
                value={invoiceNumber}
                onChange={(e) => setInvoiceNumber(e.target.value)}
                type="text"
                className="w-full max-w-[500px] text-sm outline-none border border-[rgba(0,0,0,0.1)] bg-white px-1 py-2.5 rounded-md"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm">Invoice Date</label>
              <input
                onChange={(e) => {
                  setDate(e.target.value);
                }}
                value={date}
                type="date"
                className="w-full max-w-[500px] text-sm outline-none border border-[rgba(0,0,0,0.1)] bg-white px-1 py-2.5 rounded-md"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm">Due Date</label>
              <input
                value={duedate}
                onChange={(e) => {
                  setDuedate(e.target.value);
                }}
                type="date"
                className="w-full max-w-[500px] text-sm outline-none border border-[rgba(0,0,0,0.1)] bg-white px-1 py-2.5 rounded-md"
              />
            </div>
          </div>
          <div className="w-full lg:w-[45%] grow min-h-[100px]">
            {vendor.id && (
              <div className="w-[100%] grow  border border-[rgba(0,0,0,0.1)]">
                <div className="w-full text-sm font-bold py-4 px-3 border-b border-[rgba(0,0,0,0.1)]">
                  Vendor Details preview
                </div>
                <div className="w-full flex text-sm border-b border-[rgba(0,0,0,0.1)]">
                  <div className="w-[30%] py-4 px-3 min-w-[100px] border-r border-[rgba(0,0,0,0.1)]">
                    Name
                  </div>
                  <div className="grow py-4 min-w-[100px] px-3">
                    {vendor.name}
                  </div>
                </div>
                <div className="w-full flex text-sm border-b border-[rgba(0,0,0,0.1)]">
                  <div className="w-[30%] py-4 px-3 min-w-[100px] border-r border-[rgba(0,0,0,0.1)]">
                    Phone
                  </div>
                  <div className="grow py-4 min-w-[100px] px-3">
                    {vendor.contact_no}
                  </div>
                </div>
                <div className="w-full flex text-sm border-b border-[rgba(0,0,0,0.1)]">
                  <div className="w-[30%] py-4 px-3 min-w-[100px] border-r border-[rgba(0,0,0,0.1)]">
                    Email
                  </div>
                  <div className="grow py-4 min-w-[100px] px-3">
                    {vendor.email_id}
                  </div>
                </div>
                <div className="w-full flex text-sm">
                  <div className="w-[30%] py-4 px-3 min-w-[100px] border-r border-[rgba(0,0,0,0.1)]">
                    Address
                  </div>
                  <div className="grow py-4 min-w-[100px] px-3">
                    {vendor.address}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      <div className="p-3 flex justify-between w-full lg:w-[75%] m-auto mt-4 flex-wrap">
        <button
          onClick={() => {
            setIsOpen(true);
          }}
          className="border border-[#007bff] text-[#007bff] hover:bg-[#007bff] hover:text-white rounded-md p-3 mb-3 w-[100%] md:w-[48%] md:mb-0 lg:w-[40%]"
        >
          Add Item
        </button>
        <button className="border border-[#007bff] text-[#007bff] hover:bg-[#007bff] hover:text-white rounded-md p-3 w-[100%] md:w-[48%] md:mb-0 lg:w-[40%]">
          Add Product Through Barcode
        </button>
      </div>
      <div className="flex justify-between w-full lg:w-[75%] m-auto mt-4 overflow-auto">
        <div className="w-[90%] grow p-2 min-w-[725px]">
          {data2.length > 0 && (
            <>
              <div className="flex w-full gap-3 font-bold border-b-2 border-[rgba(0,0,0,0.2)] justify-between">
                <span className="p-3 w-[80px]">SL No</span>
                <span className="p-3 w-[150px]">Items Details</span>
                <span className="p-3 w-[150px]">Quantity</span>
                <span className="p-3 w-[150px]">Selling Price</span>
                <span className="p-3 w-[150px]">Base Price</span>
                <span className="p-3 w-[150px]">GST(%)</span>
                <span className="p-3 w-[150px]">Total Amount</span>
                <span className="p-3 w-[150px]">Action</span>
              </div>
              {data2.map((item, index) => (
                <div
                  key={index}
                  className={`flex w-full gap-3 justify-between ${
                    index % 2 == 1 && "bg-[rgba(0,0,0,0.05)]"
                  } ${
                    index !== data2.length - 1 &&
                    "border-b border-[rgba(0,0,0,0.2)]"
                  }`}
                >
                  <span className="p-3 w-[80px]">{item.id}</span>
                  <span className="p-3 w-[150px]">{item.itemDetails}</span>
                  <span className="p-3 w-[150px]">
                    {item.quantity} {item.unit}
                  </span>
                  <span className="p-3 w-[150px]">{item.sellingPrice}</span>
                  <span className="p-3 w-[150px]">{item.basePrice}</span>
                  <span className="p-3 w-[150px]">{item.gst}</span>
                  <span className="p-3 w-[150px]">
                    {item.showQty * item.basePrice}
                  </span>
                  <span className="p-3 w-[150px] text-2xl">
                    <span className="cursor-pointer text-[#007bff]">
                      <RiDeleteBinLine
                        onClick={() => {
                          handleRemove(item.id);
                        }}
                      />
                    </span>
                  </span>
                </div>
              ))}
            </>
          )}
        </div>
      </div>

      <div className="p-3 flex justify-between w-full lg:w-[75%] m-auto mt-4 flex-wrap">
        <div className="p-3 mb-3 w-[100%] md:w-[48%] md:mb-0 lg:w-[40%]">
          You are Getting 20% Off on this Purchase.
        </div>
        <div className="p-3 w-[100%] md:w-[48%] md:mb-0 lg:w-[40%] text-sm">
          <div className="flex py-3 border-t border-[rgba(0,0,0,0.2)] justify-between">
            <span className="w-1/2 font-bold">Subtotal:</span>
            <span>₹</span>
            <span className="w-20 text-right">
              {billData.subtotal > 0 && billData.subtotal.toFixed(2)}
            </span>
          </div>
          <div className="flex py-3 border-t border-[rgba(0,0,0,0.2)] justify-between">
            <span className="w-1/2 font-bold">GST:</span>
            <span>₹</span>
            <span className="w-20 text-right">
              {billData.gstAmount > 0 && billData.gstAmount.toFixed(2)}
            </span>
          </div>
          <div className="flex py-3 border-t border-[rgba(0,0,0,0.2)] justify-between">
            <span className="w-1/2 font-bold">Total:</span>
            <span>₹</span>
            <span className="w-20 text-right">
              {billData.totalAmount > 0 && billData.totalAmount.toFixed(2)}
            </span>
          </div>
          <div className="flex py-3 border-t border-[rgba(0,0,0,0.2)] justify-between">
            <div className="flex flex-col gap-1 w-full">
              <label className="text-sm">Payment Type</label>
              <select className="w-full max-w-[500px] text-sm outline-none border border-[#007bff] bg-white px-1 py-2.5 rounded-md">
                <option value="">select</option>
                <option value="a">One Time</option>
                <option value="a">Credit</option>
                <option value="a">Partia Credit</option>
              </select>
              <div className="w-full flex flex-row-reverse gap-2 mt-1">
                <button className="px-4 py-2 text-white bg-green-500 rounded-md">
                  Save
                </button>
                <button className="px-4 py-2 text-white bg-red-500 rounded-md">
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        className={`w-full h-screen bg-[rgba(0,0,0,0.5)] flex justify-center fixed top-0 left-0 z-20 transition-all duration-300 ${
          !isOpen ? "opacity-0 pointer-events-none" : "opacity-100"
        }`}
        onClick={() => setIsOpen(false)}
      >
        <div
          className={`h-min mt-5 rounded-md overflow-hidden shadow-md bg-white transition-all duration-300 transform ${
            isOpen ? "translate-y-0 opacity-100" : "-translate-y-full opacity-0"
          }`}
          onClick={(e) => e.stopPropagation()}
        >
          <h2 className="text-lg p-5 border-b border-[rgba(0,0,0,0.1)] bg-blue-500 text-white">
            {"Add Item"}
          </h2>
          <div className="">
            <div className="w-full flex gap-3 p-4 border-b border-[rgba(0,0,0,0.1)] justify-center">
              <input
                onChange={handleSearch}
                type="search"
                placeholder="Search By Name"
                className="w-1/2 text-sm outline-none border border-[rgba(0,0,0,0.1)] bg-white px-2 py-2.5 rounded-[4px]"
              />
              <button
                type="button"
                className="bg-blue-500 text-white px-4 rounded-[4px]"
              >
                Search
              </button>
            </div>
            <div className="w-full grow p-2">
              <div className="flex w-full gap-3 font-bold border-b-2 border-[rgba(0,0,0,0.2)] justify-between">
                <span className="p-3 w-[80px]">#</span>
                <span className="p-3 w-[150px]">Items</span>
                <span className="p-3 w-[150px]">Sales Price</span>
                <span className="p-3 w-[150px]">Base Price</span>
                <span className="p-3 w-[150px]">GST(%)</span>
                <span className="p-3 w-[150px]">Stocks</span>
                <span className="p-3 w-[150px]">Quantity</span>
              </div>

              {data.map((item, index) => (
                <div
                  key={index}
                  className={`flex w-full gap-3 justify-between ${
                    index % 2 == 1 && "bg-[rgba(0,0,0,0.05)]"
                  } ${
                    index !== data2.length - 1 &&
                    "border-b border-[rgba(0,0,0,0.2)]"
                  }`}
                >
                  <span className="p-3 w-[80px]">
                    <input
                      type="checkbox"
                      checked={item.checked}
                      onChange={() => handleCheck(item.id)}
                    />
                  </span>
                  <span className="p-3 w-[150px]">{item.itemDetails}</span>
                  <span className="p-3 w-[150px]">{item.sellingPrice}</span>
                  <span className="p-3 w-[150px]">{item.basePrice}</span>
                  <span className="p-3 w-[150px]">{item.gst}</span>
                  <span className="p-3 w-[150px]">{item.stock}</span>
                  <span className="p-3 w-[150px] text-2xl">
                    <span className="cursor-pointer text-[#007bff]">
                      {item.checked ? (
                        <input
                          onChange={(e) => handleQtyChange(e, item.id)}
                          type="number"
                          value={item.showQty}
                          className="h-10 w-15 text-[18px] px-1 outline-none border border-[rgba(0,0,0,0.1)] bg-white  rounded-[4px]"
                        />
                      ) : (
                        <button
                          onClick={() => handleCheck(item.id)}
                          type="button"
                          className="h-10 w-15 text-sm border border-[rgba(0,0,0,0.1)] text-[15px] rounded-[4px] font-bold"
                        >
                          <span className="text-[20px]">+</span> Add
                        </button>
                      )}
                    </span>
                  </span>
                </div>
              ))}
            </div>
          </div>
          <div className="border-t border-[rgba(0,0,0,0.1)] flex flex-row-reverse gap-2 p-5">
            <button
              type="button"
              className="px-5 py-1.5 border border-[rgba(0,0,0,0.2)] rounded-[4px]"
              onClick={() => setIsOpen(false)}
            >
              Close
            </button>
            <button
              onClick={handleItemSelect}
              type="button"
              className="px-4 py-1.5 bg-[#28a745] rounded-[4px] text-white"
            >
              {"Submit"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PurchaseInvoice;
