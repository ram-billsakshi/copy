import { configureStore } from "@reduxjs/toolkit";
import authReducer from "../redux/authSlice"
import subscriptionReducer from "../redux/subscriptionSlice"
import pageReducer from "./pageSlice"
import roleReducer from './roleSlice'
import permissionReducer from "./permissionSlice"
import companyReducer from "./companySlice"
import termReducer from './termsSlice'
import expenseDetailReducer from './expenseDetailSlice'
import expenseCategoryReducer from './expenseCategorySlice'
import saleCustomerReducer from './saleCustomerSlice'
import estimateReducer from './estimateSlice'
import userReducer from "./userSlice"

const store = configureStore({
    reducer : {
        auth: authReducer,
        subscription : subscriptionReducer,
        page : pageReducer,
        role: roleReducer,
        permission: permissionReducer,
        company: companyReducer,
        term: termReducer,
        expenseDetail: expenseDetailReducer,
        expenseCategory: expenseCategoryReducer,
        saleCustomer: saleCustomerReducer,
        estimate: estimateReducer,
        user: userReducer
    }
})

export default store