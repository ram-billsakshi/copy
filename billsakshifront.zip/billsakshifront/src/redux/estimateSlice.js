import { createSlice } from "@reduxjs/toolkit";

const estimateSlice = createSlice({
    name: 'estimate',
    initialState:{
        estimateEdit: null
    },
    reducers: {
        setEstimate: (state, action) => {
            state.estimateEdit = action.payload
        }
    }
})

export const { setEstimate } = estimateSlice.actions
export default estimateSlice.reducer