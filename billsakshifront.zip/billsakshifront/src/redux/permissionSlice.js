import { createSlice } from "@reduxjs/toolkit";

const permissionSlice = createSlice({
    name: 'permission',
    initialState: {
        editData : {}
    },
    reducers : {
        getEditData: (state,action)=>{
            state.editData = action.payload
        },
    }
})

export const {getEditData} = permissionSlice.actions
export default permissionSlice.reducer