import { createSlice } from "@reduxjs/toolkit";

const companySlice = createSlice({
    name: 'company',
    initialState: {
        editCompany: null
    },
    reducers:{
        setCompany: (state, action) => {
            state.editCompany = action.payload
        }
    }
})


export const {setCompany} = companySlice.actions
export default companySlice.reducer