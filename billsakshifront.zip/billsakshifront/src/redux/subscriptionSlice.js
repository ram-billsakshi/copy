import { createSlice } from "@reduxjs/toolkit";
import { subscriptionData } from "../data/data";

const authSlice = createSlice({
    name: 'subscription',
    initialState: {
        current : "trial",
        data : subscriptionData
    },
    reducers : {
        setCurrent: (state,action)=>{
            state.current = action.payload
        },
    }
})

export const {setCurrent} = authSlice.actions
export default authSlice.reducer