import { createSlice } from "@reduxjs/toolkit";

const termsSlice = createSlice({
    name: 'terms', 
    initialState: {
        termsAndCondition: null,
    },
    reducers:{
        setTerms:(state, action) => {
            state.termsAndCondition = action.payload
        }
    }
})

export const {setTerms} = termsSlice.actions
export default termsSlice.reducer