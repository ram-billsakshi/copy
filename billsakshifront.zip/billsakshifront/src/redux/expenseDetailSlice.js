import { createSlice } from "@reduxjs/toolkit";

const expenseDetail = createSlice({
    name: 'expenseDetail',
    initialState: {
        expenseDetailEdit: null
    },
    reducers: {
        setExpenseDetail:(state, action)=>{
            state.expenseDetailEdit = action.payload
        }
    }
})

export const {setExpenseDetail} = expenseDetail.actions
export default expenseDetail.reducer