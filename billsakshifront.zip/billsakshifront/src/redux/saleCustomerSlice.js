import { createSlice } from "@reduxjs/toolkit";

const saleCustomer = createSlice({
    name: 'saleCustomer',
    initialState: {
        saleCustomerEdit: null
    },
    reducers: {
        setSaleCustomerEdit: (state, action) => {
            state.saleCustomerEdit = action.payload
        }
    }
})

export const {setSaleCustomerEdit} = saleCustomer.actions
export default saleCustomer.reducer 