import { createSlice } from "@reduxjs/toolkit";

const expenseCategory = createSlice({
    name: 'expenseCategory',
    initialState: {
        expenseCategoryEdit: null
    },
    reducers: {
        setExpenseCategory:(state, action)=>{
            state.expenseCategoryEdit = action.payload
        }
    }
})

export const {setExpenseCategory} = expenseCategory.actions
export default expenseCategory.reducer