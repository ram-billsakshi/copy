import { createSlice } from "@reduxjs/toolkit";

const authSlice = createSlice({
    name: 'auth',
    initialState: {
        isAUthenticated: !localStorage.token ? false : true,
        user: localStorage.user ? JSON.parse(localStorage.user) : null,
        error: null
    },
    reducers : {
        loginSuccess: (state,action)=>{
            state.isAUthenticated = true
            state.user = action.payload
            state.error = null
            localStorage.setItem("token",action.payload.token)
            localStorage.setItem("user",JSON.stringify(action.payload))
        },
        loginFailure: (state,action)=>{
            state.isAUthenticated = false
            state.user = null
            state.error = action.payload
        },
        logout: (state,action)=>{
            state.isAUthenticated = null
            state.user = null
            state.error = null

        }
    }
})

export const {loginSuccess,loginFailure,logout} = authSlice.actions
export default authSlice.reducer